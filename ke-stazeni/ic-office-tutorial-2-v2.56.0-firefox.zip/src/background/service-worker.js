// IC Office Tutoriál 2 — service worker
//
// Ve výchozím stavu nedělá NIC a neprovádí žádnou síťovou komunikaci.
//
// Jedinou výjimkou je odeslání žádosti o pomoc na hotline, a to jen tehdy,
// když je v src/content/tours.js vyplněný `PODPORA.endpoint`. Dokud je prázdný,
// obsluha níže se nikdy nespustí — content skript místo toho otevře
// předvyplněný e-mail. Odesílání běží tady (ne v content skriptu), aby bylo
// oprávnění k cizí adrese vidět v manifestu.
//
// Až endpoint budete mít, přidejte jeho původ do "host_permissions"
// v manifest.json — jinak fetch skončí chybou a průvodce se vrátí k e-mailu.
chrome.runtime.onInstalled.addListener(() => {
  // nic — veškerá logika běží v content skriptu, data v chrome.storage.local
});

// Stažení obsahu ze serveru (viz FORMAT.md §12). Vypnuté, dokud není v
// `tours.js` vyplněná `obsahUrl` a její původ v "host_permissions".
//
// Stahují se JEN DATA. Vzdálený kód je v Manifestu V3 zakázaný a v Chrome Web
// Store důvod k zamítnutí — formát obsahu je proto deklarativní.
//
// Stažený obsah se ukládá do cache a průvodce ji použije při dalším načtení
// stránky. Bez cache by průvodce nefungoval offline nebo když server mlčí.
const OBSAH_KEY = 'icop2:obsah';
const OBSAH_META = 'icop2:obsahMeta';
const OBSAH_FORMAT = 1;
const OBSAH_INTERVAL = 60 * 60 * 1000;   // nejvýš jednou za hodinu

function obsahPouzitelny(d) {
  return !!(d && typeof d === 'object' && d.format === OBSAH_FORMAT
    && Array.isArray(d.scenarios) && d.scenarios.length);
}

async function stahniObsah(url, vynutit) {
  if (!url) return { ok: false, duvod: 'adresa obsahu není nastavená' };
  const ulozeno = await chrome.storage.local.get([OBSAH_META]);
  const meta = ulozeno[OBSAH_META] || {};
  if (!vynutit && meta.kdy && Date.now() - meta.kdy < OBSAH_INTERVAL) {
    return { ok: true, zmena: false, duvod: 'čerstvé' };
  }
  const hlavicky = {};
  if (meta.etag) hlavicky['If-None-Match'] = meta.etag;
  const r = await fetch(url, { headers: hlavicky, cache: 'no-cache' });
  if (r.status === 304) {
    await chrome.storage.local.set({ [OBSAH_META]: Object.assign({}, meta, { kdy: Date.now() }) });
    return { ok: true, zmena: false, duvod: 'beze změny' };
  }
  if (!r.ok) return { ok: false, duvod: 'server odpověděl ' + r.status };
  const d = await r.json();
  if (!obsahPouzitelny(d)) return { ok: false, duvod: 'stažený obsah neodpovídá formátu ' + OBSAH_FORMAT };
  await chrome.storage.local.set({
    [OBSAH_KEY]: d,
    [OBSAH_META]: { kdy: Date.now(), etag: r.headers.get('ETag') || '', verze: d.version || '' }
  });
  return { ok: true, zmena: true, verze: d.version || '' };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.ns === 'icop2' && msg.action === 'obsah') {
    stahniObsah(msg.url, !!msg.vynutit)
      .then((v) => sendResponse(v))
      .catch((e) => sendResponse({ ok: false, duvod: String(e && e.message) }));
    return true;
  }
  if (!msg || msg.ns !== 'icop2' || msg.action !== 'sos') return;
  if (!msg.endpoint) { sendResponse({ ok: false, duvod: 'endpoint není nastaven' }); return true; }
  fetch(msg.endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(msg.payload || {})
  })
    .then((r) => sendResponse({ ok: r.ok, status: r.status }))
    .catch((e) => sendResponse({ ok: false, duvod: String(e && e.message) }));
  return true;   // odpověď přijde asynchronně
});
