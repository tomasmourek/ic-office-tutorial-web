// ============================================================================
// IC Office Tutoriál 2 — ENGINE
// ----------------------------------------------------------------------------
// Princip: SPOTLIGHT. Stránka se ztmaví a kolem cílových prvků se „vysvítí"
// otvory s barevným rámečkem a štítkem. Karta nápovědy se umístí AUTOMATICKY
// vedle prvku (vpravo → vlevo → pod → nad). Žádné ruční souřadnice.
//
// Barevná konvence (Tom): barva oblasti (víno) = povinný krok, žlutá = doporučení.
// Vše běží v Shadow DOM (izolace od Bootstrapu), pouze chrome.storage.local.
// ============================================================================
(() => {
  'use strict';
  if (window.__icop2Booted) return;
  window.__icop2Booted = true;

  // Obsah může přijít ZVENČÍ (z editoru přes úložiště) — proto let a jedna
  // funkce, která z něj odvodí všechno ostatní. Viz pouzijObsah() a FORMAT.md.
  const OBSAH_ZABUDOVANY = window.ICOP2_DATA || { scenarios: [] };
  let DATA = OBSAH_ZABUDOVANY;
  let OBSAH_ZDROJ = 'zabudovaný';
  // Barva vysvícení je jen druh (povinný krok / doporučení); odstín dává
  // CSS z tokenů Atomys (--icop2-povinne, --icop2-doporuceni ve stylu níže).
  const RED = 'red';
  const YELLOW = 'yellow';
  const STORE_KEY = 'icop2:state';
  const HEALTH_KEY = 'icop2:health';   // hlášení o nenalezených selektorech (viz health-check)
  const HEALTH_MAX = 80;
  const STATE_SCHEMA_VERSION = 2;
  const TICK_MS = 350;
  const SVGNS = 'http://www.w3.org/2000/svg';
  // Verze pro UI se odvozuje z obsahu — žádné napevno psané „2.0“, které
  // po bumpu verze začne odporovat číslu v popupu.
  let UI_VERSION = String(DATA.version || '2').split('.').slice(0, 2).join('.');
  // Identita zapisovatele — echo-guard pro storage.onChanged. Spolehlivější než
  // porovnávání JSON řetězců (to mlčky předpokládalo zachované pořadí klíčů).
  const INSTANCE = 'e' + Math.random().toString(36).slice(2, 10);

  // ---- prezentace (ukázkový režim) ----
  // Pauza mezi kroky je hlavní ovládací prvek prezentace: přednášející podle ní
  // ladí tempo pro publikum. Drží se v sekundách ve stavu, aby ji šlo měnit
  // před spuštěním i za běhu, a je vidět v kartě, ať je co ladit.
  const DEMO_PAUZA_DEF = 15;    // s — výchozí, doladí se podle publika
  const DEMO_PAUZA_MIN = 2;
  const DEMO_PAUZA_MAX = 90;
  const DEMO_PSANI_MS = 70;     // ms na znak — psaní má být čitelné, ne rychlé
  const DEMO_KLIK_MS = 1200;    // prodleva mezi vyplněním a kliknutím
  // Délka textu kroku, podle které se pauza přizpůsobuje. Zjištěno z obsahu:
  // průměrný krok má kolem 300 znaků, nejdelší přes 700.
  const DEMO_PRUMER_ZNAKU = 300;
  let UKAZKA = DATA.ukazka || {};
  // Prezentace patří JEN té kartě, ve které ji uživatel potvrdil. Stav se sice
  // ukládá (kroky navigují mezi stránkami), ale bez téhle značky se neobnoví —
  // jinak by se rozjela i v ostatních kartách, na druhém počítači přes sync
  // nebo druhý den po otevření IC Office, a to všechno bez potvrzení.
  // sessionStorage přesně sedí: přežije načtení stránky, ne novou kartu.
  const DEMO_KLIC = 'icop2:demo';
  const demoZnackaPlati = () => {
    try { return sessionStorage.getItem(DEMO_KLIC) === '1'; } catch (e) { return false; }
  };
  const demoZnacka = (zapnout) => {
    try {
      if (zapnout) sessionStorage.setItem(DEMO_KLIC, '1');
      else sessionStorage.removeItem(DEMO_KLIC);
    } catch (e) { /* */ }
  };
  // Scénáře, které se dají předvést. Seznam je záměrně užší než seznam všech
  // scénářů — viz PREZENTACE v tours.js.
  let PREZENTACE = (Array.isArray(DATA.prezentace) ? DATA.prezentace : [])
    .filter((p) => p && p.scenar);
  const demoScenar = (id) => PREZENTACE.find((p) => p.scenar === id) || PREZENTACE[0] || null;

  // ------------------------------------------------------------------ utils
  const colorOf = (n) => (n === 'yellow' ? YELLOW : RED);

  function escRx(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  function matchPattern(pattern, path) {
    if (!pattern || pattern === '*') return true;
    const rx = new RegExp('^' + pattern.split('*').map(escRx).join('.*') + '$');
    return rx.test(path);
  }

  // __icop2TestPath: háček pro testovací harness (test/test.html) — v produkci se nepoužije
  function currentPath() { return window.__icop2TestPath || (location.pathname + location.search); }

  function stepMatchesUrl(step) {
    const path = currentPath();
    const urls = step.url && step.url.length ? step.url : ['*'];
    if (!urls.some((p) => matchPattern(p, path))) return false;
    if ((step.urlNot || []).some((p) => matchPattern(p, path))) return false;
    return true;
  }

  // ------------------------------------------------- veřejná část webu
  // Doplněk běží na CELÉ doméně ic-office.eu — tedy i na prezentačním webu
  // a na přihlašovacím formuláři. Tam se průvodce ukázat nesmí: první krok
  // posílá uživatele do menu Klienti, které bez přihlášení neexistuje, a
  // uvítací okno by se navíc „odbylo" (introShown) dřív, než se uživatel do
  // systému vůbec dostane. Ten pak po přihlášení nedostane nic.
  //
  // Přihlášení nejde poznat z cookie (session je HttpOnly), poznáváme proto
  // OPAČNĚ — stránky, které prokazatelně patří veřejné části:
  //   • přihlášení / registrace / obnova hesla: <html id="extr-page">,
  //     <body id="login">, formulář #frm-loginForm,
  //   • prezentační web: <body id="page-top"> s odkazem Přihlásit,
  //   • cokoli pod /web/ — aplikace tam nemá jedinou stránku (login, register,
  //     resetpassword, training, eet, termsconditions).
  // Když si jistí nejsme, průvodce běží. Falešné „nepřihlášen" by ho vyplo
  // úplně; falešné „přihlášen" jen zopakuje dosavadní stav na jedné stránce.
  //
  // __icop2TestVerejna: háček pro testovací harness — v produkci se nepoužije
  function verejnaStranka() {
    if (typeof window.__icop2TestVerejna === 'boolean') return window.__icop2TestVerejna;
    if (document.documentElement.id === 'extr-page') return true;
    const b = document.body;
    if (b && b.id === 'login') return true;
    if (document.querySelector("#frm-loginForm, form[action*='/web/login'] input[type='password']")) return true;
    if (b && b.id === 'page-top' && document.querySelector("a[href*='/web/login']")) return true;
    return matchPattern('/web/*', currentPath());
  }

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 && r.height < 2) return false;
    const st = getComputedStyle(el);
    if (st.visibility === 'hidden' || st.display === 'none' || +st.opacity === 0) return false;
    return true;
  }

  // isVisible se ptá jen CSS. Jenže prvek může být podle CSS naprosto v pořádku
  // a uživatel ho přesto nevidí: odroloval ho z okna, nebo mu ho zakryla lepivá
  // hlavička stránky. Rámeček pak zůstal viset přes menu a ukazoval na úplně
  // jinou věc (nález z provozu — uživatel odroloval formulář a průvodce
  // vysvěcoval položky horního menu).
  //
  // Pozná se to zásahovým testem: kdyby uživatel na prvek kliknul, trefil by
  // ho? Zkouší se střed a čtyři rohy, protože stačí, aby byl vidět kus.
  function vidiUzivatel(el) {
    if (!el) return false;
    const vw = innerWidth, vh = innerHeight;
    // Skryté okno hlásí nulové rozměry. Tam se neměří — jinak by se průvodce
    // schoval sám od sebe (stejná past jako u rozmisťování štítků).
    if (!vw || !vh) return true;
    const r = el.getBoundingClientRect();
    if (r.bottom <= 0 || r.top >= vh || r.right <= 0 || r.left >= vw) return false;
    const body = [
      [r.left + r.width / 2, r.top + r.height / 2],
      [r.left + 4, r.top + 4],
      [r.right - 4, r.top + 4],
      [r.left + 4, r.bottom - 4],
      [r.right - 4, r.bottom - 4]
    ];
    for (const [x, y] of body) {
      if (x < 0 || y < 0 || x >= vw || y >= vh) continue;
      let stack = null;
      try { stack = document.elementsFromPoint(x, y); } catch (e) { return true; }
      // Vlastní vrstvu průvodce z hromádky vyhodíme a ptáme se, co je pod ní.
      // Karta cíl občas překrývá a rozhodovat se podle ní by byla smyčka:
      // schoval bych se proto, že si sám stojím v cestě.
      const hit = (stack || []).find((n) => n !== host);
      if (!hit) continue;
      // Předek se bere jako „vidím" schválně: když prvek ořízne rolovací
      // kontejner, vrátí se ten kontejner — a schovat průvodce kvůli nejistotě
      // je horší než ho nechat. Lepivá hlavička předek cíle není, takže ta
      // se pozná spolehlivě.
      if (hit === el || el.contains(hit) || hit.contains(el)) return true;
    }
    return false;
  }

  // Najde prvek dle selektoru / pole selektorů. Preferuje VIDITELNÝ.
  function findEl(spec) {
    if (!spec) return null;
    const sels = Array.isArray(spec) ? spec : [spec];
    let hidden = null;
    for (const s of sels) {
      let els = [];
      try { els = document.querySelectorAll(s); } catch (e) { /* neplatný selektor */ }
      for (const el of els) {
        if (isVisible(el)) return el;
        if (!hidden) hidden = el;
      }
    }
    return hidden;
  }

  function findVisible(spec) {
    const el = findEl(spec);
    return el && isVisible(el) ? el : null;
  }

  // Má pole/skupina selektorů vyplněnou hodnotu?
  // Projde VŠECHNY výskyty a preferuje viditelné — skrytý duplikát (např. pole
  // ve schovaném modalu se stejným placeholderem) nesmí zablokovat odemknutí.
  //
  // `nenulove`: nula se počítá jako prázdná hodnota. IC Office předvyplňuje
  // cenová pole „0.00“ a brána, která hlídá jen neprázdnost, byla odemčená
  // dřív, než uživatel cokoli zadal (SK-K10). Jen pro kroky, které si o to
  // řeknou — jinde může být nula záměrná (sleva, práce zdarma).
  const jeNula = (v) => /^\s*-?[\d\s]*([.,]\d*)?\s*$/.test(v) && /\d/.test(v)
    && Number(v.replace(/\s/g, '').replace(',', '.')) === 0;
  function groupHasValue(group, nenulove) {
    const els = [];
    for (const s of group) {
      try { document.querySelectorAll(s).forEach((el) => els.push(el)); } catch (e) { /* */ }
    }
    if (!els.length) return false;
    const visible = els.filter(isVisible);
    const list = visible.length ? visible : els;
    return list.some((el) => {
      if (el.type === 'checkbox' || el.type === 'radio') return el.checked;
      const v = ((el.value || '') + '').trim();
      return v.length > 0 && !(nenulove && jeNula(v));
    });
  }

  function pad(r, px, py) {
    const y = py === undefined ? px : py;
    return { left: r.left - px, top: r.top - y, width: r.width + 2 * px, height: r.height + 2 * y };
  }

  // Rámeček se kolem prvku kreslí s odstupem, aby prvek „dýchal". Jenže dvě
  // políčka formuláře dělí jen pár pixelů — čáry sousedních rámečků se pak
  // překryly a splynuly v jednu čmouhu; nebylo poznat, kde jeden prvek končí
  // a druhý začíná. Stalo se to v obou směrech: u polí pod sebou (Telefon
  // a E-mail) i u prvků vedle sebe (pole IČO a tlačítko Vyplnit).
  //
  // Odstup proto počítáme podle nejtěsnější dvojice vysvícených prvků, zvlášť
  // pro každý směr: rámečky se semknou k prvkům tak, aby mezi jejich čarami
  // zůstala viditelná mezera. V rámci směru je odstup pro všechny rámečky ve
  // výřezu stejný, aby nevypadaly různě tlusté.
  const RAMECEK_ODSTUP = 8;   // co nejraději, když je kolem místo
  const RAMECEK_MEZERA = 8;   // kolik nechat mezi dvěma rámečky (včetně čar)
  function odstupRamecku(rects) {
    let px = RAMECEK_ODSTUP;
    let py = RAMECEK_ODSTUP;
    const zuz = (mezera) => Math.floor((mezera - RAMECEK_MEZERA) / 2);
    for (let i = 0; i < rects.length; i++) {
      for (let j = i + 1; j < rects.length; j++) {
        const a = rects[i];
        const b = rects[j];
        // Prvky nad sebou (vodorovně se překrývají) → řeší svislý odstup.
        if (!(a.left + a.width <= b.left || b.left + b.width <= a.left)) {
          const m = a.top < b.top
            ? b.top - (a.top + a.height)
            : a.top - (b.top + b.height);
          py = Math.min(py, zuz(m));
        }
        // Prvky vedle sebe (svisle se překrývají) → řeší vodorovný odstup.
        if (!(a.top + a.height <= b.top || b.top + b.height <= a.top)) {
          const m = a.left < b.left
            ? b.left - (a.left + a.width)
            : a.left - (b.left + b.width);
          px = Math.min(px, zuz(m));
        }
        // Záporná mezera = prvky se překrývají nebo je jeden uvnitř druhého
        // (tlačítko Vyplnit sedí na poli IČO). Odstup spadne na nulu, rámečky
        // si sednou přesně na prvky a čáry vedou po skutečných hranách místo
        // aby si osm pixelů zajížděly do sebe. Víc než „dotýkat se" u takové
        // dvojice udělat nejde.
      }
    }
    return { x: Math.max(0, px), y: Math.max(0, py) };
  }

  // ------------------------------------------------------------------ stav
  const defaultState = () => ({
    schemaVersion: STATE_SCHEMA_VERSION,
    contentVersion: DATA.version || '',
    writer: '',            // kdo naposledy zapsal (echo-guard, viz INSTANCE)
    enabled: true,
    introShown: false,
    active: null,          // { scenarioId, step, stepId, paused }
    done: {},              // { scenarioId: true }
    fab: null,             // { x, y }
    contactAsked: false,   // úvodní dotaz na kontakt už proběhl
    contact: null,         // { icZakaznik, jmeno, tel, email } — komu volat zpět
    cvHotova: {},          // { idCviceni: { napoved, sekundy, chyby, kdy } }
    plan: null,            // { od, cviceni: [id] } — co zadal mistr
    demo: null             // { bezi, auto, pauza, dleTextu, hlas } — prezentace
  });
  const state = defaultState();

  function resolvedStepIndex(sc, active, isLegacy) {
    if (!sc || !active) return 0;
    if (active.stepId) {
      const byId = sc.steps.findIndex((step) => step.id === active.stepId);
      if (byId >= 0) return byId;
    }

    let idx = Number.isInteger(active.step) ? active.step : 0;
    // v2.2 vložila mezi původní f01–f03 samostatný podpis a tisk. Starý číselný
    // stav proto jednorázově převedeme na odpovídající id místo posunu jinam.
    if (isLegacy && (sc.id === 'novy-zakaznik-osobne' || sc.id === 'novy-zakaznik-telefon')) {
      const f01 = sc.steps.findIndex((step) => step.id === 'f01');
      if (f01 >= 0 && idx > f01) {
        let wantedId = null;
        if (idx === f01 + 1) wantedId = 'f03';       // původní „Otevřete fakturaci“
        else if (idx === f01 + 2) wantedId = 'f04';  // původní „Vystavení faktury“
        else wantedId = sc.steps[sc.steps.length - 1]?.id;
        const migrated = sc.steps.findIndex((step) => step.id === wantedId);
        if (migrated >= 0) idx = migrated;
      }
    }
    return Math.min(Math.max(idx, 0), Math.max(0, sc.steps.length - 1));
  }

  function normalizeState(raw) {
    const source = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
    const next = defaultState();
    next.enabled = source.enabled !== false;
    next.introShown = !!source.introShown;
    next.writer = typeof source.writer === 'string' ? source.writer : '';
    if (source.done && typeof source.done === 'object' && !Array.isArray(source.done)) {
      for (const [id, done] of Object.entries(source.done)) if (done === true) next.done[id] = true;
    }
    if (source.fab && Number.isFinite(source.fab.x) && Number.isFinite(source.fab.y)) {
      next.fab = { x: source.fab.x, y: source.fab.y };
    }
    next.contactAsked = !!source.contactAsked;
    if (source.plan && typeof source.plan === 'object' && Array.isArray(source.plan.cviceni)) {
      const ids = source.plan.cviceni.filter((x) => typeof x === 'string').slice(0, 60);
      if (ids.length) {
        next.plan = { od: typeof source.plan.od === 'string' ? source.plan.od.slice(0, 80) : '', cviceni: ids };
      }
    }
    if (source.cvHotova && typeof source.cvHotova === 'object' && !Array.isArray(source.cvHotova)) {
      for (const [id, v] of Object.entries(source.cvHotova)) {
        if (v && typeof v === 'object' && Number.isFinite(v.napoved)) {
          next.cvHotova[id] = { napoved: Math.max(0, v.napoved | 0), sekundy: Math.max(0, (v.sekundy | 0)),
            chyby: Math.max(0, v.chyby | 0), kdy: Number.isFinite(v.kdy) ? v.kdy : 0 };
        }
      }
    }
    if (source.contact && typeof source.contact === 'object') {
      const str = (v) => (typeof v === 'string' ? v.trim().slice(0, 120) : '');
      const c = {
        icZakaznik: str(source.contact.icZakaznik),
        jmeno: str(source.contact.jmeno),
        tel: str(source.contact.tel),
        email: str(source.contact.email),
        // zvolený obchodní specialista — jméno ze seznamu v obsahu ("—" = neví)
        specialista: str(source.contact.specialista)
      };
      if (c.icZakaznik || c.jmeno || c.tel || c.email || c.specialista) next.contact = c;
    }
    // Prezentace přežívá načtení stránky (kroky navigují), proto je ve stavu.
    // Obnoví se ale JEN v kartě, kde ji uživatel potvrdil — viz DEMO_KLIC.
    if (source.demo && typeof source.demo === 'object' && source.demo.bezi === true && demoZnackaPlati()) {
      next.demo = {
        bezi: true,
        auto: source.demo.auto !== false,
        pauza: demoPauzaPlatna(source.demo.pauza),
        dleTextu: source.demo.dleTextu !== false,
        hlas: source.demo.hlas === true,
        ceka: typeof source.demo.ceka === 'string' ? source.demo.ceka.slice(0, 300) : '',
        scenar: typeof source.demo.scenar === 'string' ? source.demo.scenar : ''
      };
    }
    if (source.active && typeof source.active.scenarioId === 'string') {
      const sc = DATA.scenarios.find((scenario) => scenario.id === source.active.scenarioId);
      if (sc && sc.available && sc.steps.length) {
        const idx = resolvedStepIndex(sc, source.active, source.schemaVersion !== STATE_SCHEMA_VERSION);
        next.active = {
          scenarioId: sc.id,
          step: idx,
          stepId: sc.steps[idx].id,
          paused: !!source.active.paused
        };
      }
    }
    return next;
  }

  function applyState(raw) {
    const normalized = normalizeState(raw);
    for (const key of Object.keys(state)) delete state[key];
    Object.assign(state, normalized);
  }

  function syncActiveStepId() {
    state.schemaVersion = STATE_SCHEMA_VERSION;
    state.contentVersion = DATA.version || '';
    if (!state.active) return;
    const sc = DATA.scenarios.find((scenario) => scenario.id === state.active.scenarioId);
    const step = sc && sc.steps[state.active.step];
    state.active.stepId = step ? step.id : null;
  }
  let lastSavedJson = '';

  // Postup ukládáme do `sync`, aby šel s přihlášeným profilem Chrome — v servisu
  // se běžně střídá přijímací a dílenský počítač. Stav má pár set bajtů, kvóta
  // sync (8 kB na položku) stačí s velkou rezervou. Hlášení health-checku
  // zůstávají v `local` — jsou objemnější a vážou se ke konkrétnímu stroji.
  // Když sync není k dispozici (firemní politika), spadneme zpět na local.
  // KONTAKT SE NESYNCHRONIZUJE. Jméno, telefon, e-mail a zákaznické číslo
  // jsou osobní údaje; postup scénářem a nastavení nejsou. Kdyby byl kontakt
  // součástí synchronizovaného stavu, putoval by do účtu Google a na všechny
  // přihlášené počítače — což je něco jiného, než k čemu ho uživatel vyplnil.
  const KONTAKT_KEY = 'icop2:kontakt';

  let stateArea = null;
  function stateStore() {
    if (stateArea) return stateArea;
    try {
      stateArea = (chrome.storage && chrome.storage.sync) ? chrome.storage.sync : chrome.storage.local;
    } catch (e) { stateArea = chrome.storage.local; }
    return stateArea;
  }

  // `hotovo` zavoláme, až je stav opravdu zapsaný — potřebné tam, kde hned
  // po uložení odcházíme na jinou adresu (spuštění prezentace).
  function saveState(hotovo) {
    syncActiveStepId();
    state.writer = INSTANCE;   // echo-guard: vlastní zápis poznáme podle značky
    lastSavedJson = JSON.stringify(state);
    const data = JSON.parse(lastSavedJson);
    // Kontakt jde jinam než zbytek stavu — a ze synchronizovaného záznamu se
    // odstraní i tehdy, když tam zbyl po starší verzi doplňku.
    const kontakt = data.contact || null;
    delete data.contact;
    try {
      chrome.storage.local.set(kontakt ? { [KONTAKT_KEY]: kontakt } : { [KONTAKT_KEY]: null });
    } catch (e) { /* bez kontaktu se průvodce obejde */ }
    try {
      stateStore().set({ [STORE_KEY]: data }, () => {
        // kvóta / vypnutý sync → tiše na local, ať uživatel o postup nepřijde
        if (chrome.runtime.lastError && stateArea !== chrome.storage.local) {
          stateArea = chrome.storage.local;
          try { chrome.storage.local.set({ [STORE_KEY]: data }, () => { if (hotovo) hotovo(); }); return; } catch (e2) { /* */ }
        }
        if (hotovo) hotovo();
      });
    } catch (e) { if (hotovo) hotovo(); }
  }

  // ------------------------------------------------------------------ UI kostra
  const host = document.createElement('div');
  host.id = 'icop2-root';
  host.style.cssText = 'position:fixed;top:0;left:0;width:0;height:0;z-index:2147483600;';
  const root = host.attachShadow({ mode: 'open' });

  // Styl Atomys 2.0 (docs/PREVZETI.md, oddíl Doplňky prohlížeče a Shadow DOM):
  // tokeny sedí na :host a přicházejí z vygenerovaného atomys.js. Vzhled nad
  // IC Office je pevný — Tiskopis, světlý motiv, oblast crm (README, Vzhled).
  // Níže jen vlastní skladba průvodce; barvy, písma a rozměry výhradně z --at-*.
  const ATOMYS = window.ICOP2_ATOMYS || { css: '', pisma: [] };
  const ik = (jmeno) => `<span class="at-i at-i-${jmeno}" aria-hidden="true"></span>`;

  // @font-face uvnitř shadow rootu prohlížeče ignorují, písma se proto
  // registrují do dokumentu přes FontFace API. Načtou se, až je karta použije;
  // když se to nepovede, zůstane záložní systémové písmo z tokenu.
  (function nactiPisma() {
    try {
      if (!document.fonts || typeof FontFace !== 'function' || !chrome.runtime || !chrome.runtime.getURL) return;
      for (const p of ATOMYS.pisma || []) {
        const f = new FontFace(p.rodina, `url("${chrome.runtime.getURL(p.soubor)}") format("woff2")`, p.popis);
        document.fonts.add(f);
      }
    } catch (e) { /* písmo je vzhled, ne funkce */ }
  })();

  const style = document.createElement('style');
  style.textContent = `
    :host { all: initial; }
    ${ATOMYS.css}
    /* Alias vrstva průvodce. Konvence z obsahu: povinný krok = barva oblasti
       (víno), doporučení = žlutá. Obě jen rámují místo, stav nenesou. */
    :host {
      --icop2-povinne: var(--at-accent);
      --icop2-na-povinnem: var(--at-on-accent);
      --icop2-doporuceni: var(--at-focus-halo);
      --icop2-na-doporuceni: var(--at-ink);
      color: var(--at-ink);
      font-family: var(--at-font-ui);
      font-size: var(--at-font-size-text);
      line-height: var(--at-line-height-body);
    }
    *, *::before, *::after { box-sizing: border-box; }
    * { font-family: inherit; }
    :focus-visible { outline: var(--at-border-focus) solid var(--at-focus); outline-offset: var(--at-border-focus);
                     box-shadow: 0 0 0 var(--at-border-focus) var(--at-focus-halo); }
    @media (forced-colors: active) { :focus-visible { outline-color: Highlight; } }
    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after { transition: none !important; animation: none !important; }
    }
    strong { font-weight: var(--at-font-weight-semibold); }
    .at-i { flex: none; }

    /* ---------- tlačítka (vzor .at-btn) ---------- */
    .b, .helpp .acts button, .warn button, .fold .foldc button, .db, .edit .eacts button,
    .cvplan button, .scen-znovu, .dvol, .spvol {
      display: inline-flex; align-items: center; justify-content: center; gap: var(--at-space-2);
      min-height: 32px; margin: 0; padding: 4px 12px;
      border: var(--at-border-rule) solid var(--at-field-border); border-radius: var(--at-radius-control);
      background: var(--at-surface-1); color: var(--at-ink);
      font-size: var(--at-font-size-small); font-weight: var(--at-font-weight-medium); line-height: var(--at-line-height-tight);
      text-align: center; cursor: pointer; }
    .b:hover, .helpp .acts button:hover, .warn button:hover, .fold .foldc button:hover, .db:hover,
    .edit .eacts button:hover, .cvplan button:hover, .scen-znovu:hover, .dvol:hover, .spvol:hover {
      background: var(--at-surface-2); }
    .b { min-height: var(--at-control-height); padding: 4px 14px; font-size: var(--at-font-size-table); }
    .b.main, .helpp .acts button.prim, .edit .eacts button.prim {
      border-color: var(--at-accent); background: var(--at-accent); color: var(--at-on-accent);
      font-weight: var(--at-font-weight-semibold); }
    .b.main:hover, .helpp .acts button.prim:hover, .edit .eacts button.prim:hover {
      border-color: var(--at-accent-hover); background: var(--at-accent-hover); }
    .b.main[disabled] { border-color: var(--at-rule); background: var(--at-surface-2); color: var(--at-muted); cursor: not-allowed; }
    .b.mini { min-height: 28px; padding: 4px 8px; border-color: transparent; background: transparent;
              color: var(--at-ink-soft); font-size: var(--at-font-size-small); }
    .b.mini:hover { background: var(--at-surface-2); color: var(--at-ink); }
    /* Volba z několika (scénář prezentace, specialista): výběr nese rám v barvě
       odkazu, ne výplň akcentem. */
    .dvol.on, .spvol.on, .db.on { border-color: var(--at-accent-text); background: var(--at-accent-soft);
      color: var(--at-accent-text); font-weight: var(--at-font-weight-semibold); box-shadow: inset 0 0 0 1px var(--at-accent-text); }
    .x { display: inline-flex; align-items: center; justify-content: center; flex: none; width: 32px; height: 32px;
         padding: 0; border: 0; border-radius: var(--at-radius-control); background: transparent; color: var(--at-ink-soft); cursor: pointer; }
    .x:hover { background: var(--at-surface-2); color: var(--at-ink); }
    .x .at-i { width: 20px; height: 20px; }
    input[type="checkbox"], input[type="range"] { accent-color: var(--at-accent); }

    /* ---------- pole (vzor .at-input) ---------- */
    .wsearch input, .wform input, .edit input[type="text"], .edit input[type="number"], .edit textarea, .edit select, .dsp select {
      width: 100%; min-height: var(--at-control-height); margin-top: 4px; padding: 0 var(--at-space-3);
      border: var(--at-border-rule) solid var(--at-field-border); border-radius: var(--at-radius-control);
      background: var(--at-surface-1); color: var(--at-ink); font-size: var(--at-font-size-text); line-height: var(--at-line-height-heading); }
    .wsearch input::placeholder, .wform input::placeholder { color: var(--at-muted); opacity: 1; }
    .wsearch input:hover, .wform input:hover:not([readonly]), .edit input:hover, .edit textarea:hover { border-color: var(--at-ink-soft); }

    /* ---------- spotlight ---------- */
    .spot { position: fixed; inset: 0; width: 100vw; height: 100vh; pointer-events: none; z-index: 10; }
    .spot .shade { fill: var(--at-overlay); }
    .spot rect.hole, .spot rect.ring, .spot rect.lem { transition: x var(--at-motion-slow) var(--at-motion-ease), y var(--at-motion-slow) var(--at-motion-ease),
      width var(--at-motion-slow) var(--at-motion-ease), height var(--at-motion-slow) var(--at-motion-ease); }
    .spot rect.ring { fill: none; stroke-width: 3; stroke: var(--icop2-povinne); }
    .spot rect.ring.yellow { stroke: var(--icop2-doporuceni); }
    .spot rect.lem { fill: none; stroke-width: 2; stroke: var(--at-surface-1); }

    /* ---------- štítky ---------- */
    .labels { position: fixed; inset: 0; pointer-events: none; z-index: 11; }
    .lbl { position: fixed; display: inline-flex; align-items: center; gap: 6px;
           padding: 2px 8px; border-radius: var(--at-radius-control); font-size: var(--at-font-size-small);
           font-weight: var(--at-font-weight-semibold); line-height: var(--at-line-height-label);
           white-space: nowrap; box-shadow: var(--at-shadow-layer);
           transition: top var(--at-motion-slow) var(--at-motion-ease), left var(--at-motion-slow) var(--at-motion-ease); }
    .lbl.red { background: var(--icop2-povinne); color: var(--icop2-na-povinnem); }
    .lbl.yellow { background: var(--icop2-doporuceni); color: var(--icop2-na-doporuceni); }

    /* ---------- karta ---------- */
    /* 420 px, ne 380: číslovaný bod si ubírá sloupec na číslo a v úzké kartě
       se text lámal po dvou slovech. Karta je o kus širší, ale výrazně nižší —
       a nižší karta zakryje míň formuláře než vysoká. */
    .card { --_barva: var(--icop2-povinne);
            position: fixed; width: 420px; max-width: calc(100vw - 24px); max-height: calc(100vh - 20px);
            background: var(--at-surface-1); color: var(--at-ink);
            border: var(--at-border-rule) solid var(--at-rule-strong); border-radius: var(--at-radius-dialog);
            box-shadow: var(--at-shadow-layer); z-index: 20; pointer-events: auto; overflow: hidden auto;
            transition: top var(--at-motion-base) var(--at-motion-ease), left var(--at-motion-base) var(--at-motion-ease); }
    .card[data-color="yellow"] { --_barva: var(--icop2-doporuceni); }
    .card.center { width: 440px; }
    /* Kartu jde přetáhnout za hlavičku — přechod polohy by tažení „gumoval". */
    .card.tazena { transition: none; }
    /* Hlavička jako lišta aplikace: hrana v barvě kroku je dole. */
    .card .head { display: flex; align-items: center; gap: var(--at-space-2); min-height: 40px; padding: 4px 4px 4px 16px;
                  border-bottom: var(--at-bar-edge) solid var(--_barva); color: var(--at-ink-soft);
                  cursor: grab; user-select: none; touch-action: none; }
    .card .head:active { cursor: grabbing; }
    .card .head .scen { flex: 1; min-width: 0; font-size: var(--at-font-size-small); font-weight: var(--at-font-weight-semibold);
                        overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    /* ---------- ukazatel průběhu ----------
       Prošel třemi podobami. Nejdřív 5px pruh přes celou šířku s ostrými rohy
       — u třetího kroku z něj byl červený špalík v rohu, vypadal jako artefakt.
       Pak odsazená dráha s řádkem „Krok 3 z 31 … 10 %“. Ten jsem při
       zeštíhlování karty vyhodil a nahradil vláskovou linkou, jenže kolikátý
       krok z kolika je právě běží, je při učení podstatný údaj — vrácen zpátky,
       jen kompaktněji. Průběh je stav „probíhá“, proto barvou info (vzor .at-prubeh). */
    .pmeta { display: flex; align-items: baseline; gap: 10px; padding: 10px 16px 0; }
    .pmeta .pstep { font-size: var(--at-font-size-small); font-weight: var(--at-font-weight-medium); color: var(--at-muted); }
    .pmeta .ppct { margin-left: auto; font-size: var(--at-font-size-small); font-weight: var(--at-font-weight-semibold);
                   color: var(--at-ink-soft); font-variant-numeric: tabular-nums; }
    .track { height: 4px; margin: 6px 16px 0; background: var(--at-surface-2); overflow: hidden; }
    .track .bar { height: 100%; min-width: 4px; background: var(--at-info);
                  transition: width var(--at-motion-slow) var(--at-motion-ease); }

    /* ---------- pomoc ---------- */
    .helpp { margin: 12px 16px 0; padding: 12px; font-size: var(--at-font-size-small); line-height: var(--at-line-height-body);
             color: var(--at-ink); background: var(--at-canvas); border: var(--at-border-rule) solid var(--at-rule);
             border-radius: var(--at-radius-control); }
    /* Kód kroku pro hotlinku: strojový údaj, proto Plex Mono (vzor .at-kod-obrazovky). */
    .helpp .bigcode { display: block; width: fit-content; margin-bottom: 8px; padding: 2px 10px;
                      font-family: var(--at-font-data); font-size: 22px; font-weight: var(--at-font-weight-medium);
                      letter-spacing: .04em; color: var(--at-ink); background: var(--at-surface-1);
                      border: var(--at-border-rule) solid var(--at-rule-strong); border-radius: var(--at-radius-control); user-select: all; }
    .helpp .row { margin-top: 10px; }
    .helpp a, .more a, .wform .hint a { color: var(--at-accent-text); font-weight: var(--at-font-weight-medium);
                                         text-underline-offset: .2em; }
    .helpp .acts { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 12px; }
    .helpp.sos { background: var(--at-surface-1); border-color: var(--at-rule-strong); }
    .helpp .tip { margin-top: 10px; font-size: var(--at-font-size-small); color: var(--at-muted); }
    .ok { color: var(--at-success); font-weight: var(--at-font-weight-semibold); }
    .card h3 { margin: 12px 16px 0; font-size: var(--at-font-size-h3); font-weight: var(--at-heading-weight);
               line-height: var(--at-line-height-heading); color: var(--at-ink); text-wrap: pretty; }
    .card h3.strucne { font-size: 20px; }
    .txt { margin: 8px 16px 0; font-size: var(--at-font-size-text); line-height: var(--at-line-height-body); color: var(--at-ink);
           max-height: 40vh; overflow: auto; text-wrap: pretty; }
    /* ---------- číslovaný bod ----------
       Číslo v rámečku místo znaku ①. Bod je vlastní blok, takže zalomený
       text pokračuje pod textem, ne pod číslem, a mezi body je vidět mezera. */
    /* text-indent: 0 — visící odsazení bodu se dědí i dovnitř rámečku a
       vystrčilo by číslici mimo něj. */
    .cis { display: inline-flex; align-items: center; justify-content: center; box-sizing: border-box;
           text-indent: 0; min-width: 18px; height: 18px; padding: 0 4px; border-radius: var(--at-radius-control);
           background: var(--icop2-povinne); color: var(--icop2-na-povinnem); font-size: 12px;
           font-weight: var(--at-font-weight-semibold); line-height: 1; font-variant-numeric: tabular-nums; }
    .card[data-color="yellow"] .cis { background: var(--icop2-doporuceni); color: var(--icop2-na-doporuceni); }
    /* Visící odsazení, NE flex/grid. Flex z každého <strong> uvnitř věty udělá
       samostatnou buňku a věta se rozsype do sloupců („zadejte“ pod „FIRMA“,
       „klikněte“ pod „IČO“). Odsazení nechá text běžet normálně a jen zalomený
       řádek srovná pod text místo pod číslo. */
    .txt .bod, .then-txt .bod { display: block; margin-top: 6px; padding-left: 25px; text-indent: -25px; }
    .txt .bod > .cis, .then-txt .bod > .cis { margin-right: 7px; vertical-align: -4px; }
    .lbl .cis { min-width: 17px; height: 17px; }
    .lbl.red .cis { background: var(--at-surface-1); color: var(--icop2-povinne); }
    .lbl.yellow .cis { background: var(--at-ink); color: var(--icop2-doporuceni); }
    /* Legenda v textu: podtržení barvou rámečku, text zůstává čitelný. */
    .txt .lg-red, .txt .lg-yellow { font-weight: var(--at-font-weight-semibold); text-decoration-line: underline;
      text-decoration-thickness: 3px; text-underline-offset: 3px; text-decoration-skip-ink: none; }
    .txt .lg-red { text-decoration-color: var(--icop2-povinne); }
    .txt .lg-yellow { text-decoration-color: var(--icop2-doporuceni); }
    .then-txt { margin: 8px 16px 0; padding: 8px 10px; font-size: var(--at-font-size-text); line-height: 1.45; color: var(--at-ink);
                background: var(--at-canvas); border: var(--at-border-rule) solid var(--at-rule); border-radius: var(--at-radius-control); }
    /* Proč je „Pokračovat“ zatmavené. Jeden řádek stačí — dřív to byl rámeček
       přes celou šířku a v kartě působil jako další odstavec k přečtení. */
    .gate { display: flex; align-items: flex-start; gap: var(--at-space-2); margin: 10px 16px 0; padding: 6px 10px;
            font-size: var(--at-font-size-small); line-height: 1.45; color: var(--at-ink);
            background: var(--at-warning-soft); border-radius: var(--at-radius-control); }
    .gate .at-i, .warn .at-i, .wdemoask p.pozor .at-i { color: var(--at-warning); }
    /* cíl kroku na stránce chybí — nejčastěji se zavřelo okno, se kterým krok počítá */
    .warn { margin: 10px 16px 0; padding: 10px 12px; font-size: var(--at-font-size-small); line-height: 1.45; color: var(--at-ink);
            background: var(--at-warning-soft); border-radius: var(--at-radius-control); }
    .warn button { margin-top: 8px; }

    /* Upozornění, že zobrazený krok neodpovídá uloženému postupu. Sbalené —
       je to poznámka na okraj, ne instrukce, a rozbalené zabíralo v kartě
       čtyři řádky a tlačítko. Kdo to potřebuje, rozklikne. */
    .fold { margin: 10px 16px 0; border-radius: var(--at-radius-control); font-size: var(--at-font-size-small); line-height: 1.45; }
    .fold > summary { display: flex; align-items: center; gap: 6px; min-height: 32px; padding: 6px 10px; cursor: pointer;
                      font-weight: var(--at-font-weight-semibold); list-style: none; }
    .fold > summary::-webkit-details-marker { display: none; }
    .fold > summary::after { content: ""; margin-left: auto; width: 7px; height: 7px; border: solid currentColor;
                             border-width: 0 2px 2px 0; transform: rotate(45deg) translate(-2px, -2px);
                             transition: transform var(--at-motion-fast) var(--at-motion-ease); }
    .fold[open] > summary::after { transform: rotate(225deg) translate(-2px, -2px); }
    .fold .foldc { padding: 0 10px 10px; }
    .fold .foldc button { margin-top: 8px; }
    .jump { background: var(--at-info-soft); color: var(--at-ink); }
    .more { margin: 8px 16px 0; padding: 10px 12px; font-size: var(--at-font-size-small); line-height: 1.5; color: var(--at-ink);
            background: var(--at-canvas); border: var(--at-border-rule) solid var(--at-rule); border-radius: var(--at-radius-control); }
    .more p { margin: 0 0 6px; } .more p:last-child { margin: 0; }
    /* výňatek z oficiální nápovědy IC Office k tématu daného kroku */
    .more .manual { margin-top: 10px; padding-top: 10px; border-top: var(--at-border-rule) solid var(--at-rule); }
    .more .manual .mh { display: flex; align-items: center; gap: 6px; font-size: var(--at-font-size-small);
                        font-weight: var(--at-font-weight-semibold); color: var(--at-ink-soft); margin-bottom: 4px; }
    .more .manual a { display: inline-flex; align-items: center; gap: 4px; margin-top: 6px; }
    .vid { margin: 8px 16px 0; }
    .vid video { display: block; width: 100%; border-radius: var(--at-radius-control); background: var(--at-ink); }
    .vid .vid-err, .wvideo .vid-err { padding: 10px 12px; font-size: var(--at-font-size-small); color: var(--at-ink);
                                      background: var(--at-warning-soft); border-radius: var(--at-radius-control); }
    /* Pět stejně těžkých tlačítek v jedné řadě vypadalo jako ovládací panel.
       Rozdělené na dvě patra: dole hlavní postup vpravo, nad ním tenký proužek
       s pomocnými odkazy. Ty se tím vizuálně stáhnou do pozadí, kam patří. */
    .btns { display: flex; flex-wrap: wrap; align-items: center; gap: var(--at-space-2); padding: 12px 16px 14px; }
    .btns .sp { flex: 1 1 0; min-width: 0; }
    .tools { display: flex; flex-wrap: wrap; align-items: center; gap: 2px;
             margin: 12px 10px 0; padding-top: 8px; border-top: var(--at-border-rule) solid var(--at-rule); }
    .tools + .btns { padding-top: 4px; }
    .tools .codeq { margin-left: auto; padding: 1px 6px; border: var(--at-border-rule) solid var(--at-rule-strong);
                    border-radius: var(--at-radius-control); background: var(--at-surface-1); color: var(--at-ink-soft);
                    font-family: var(--at-font-data); font-size: 12px; font-weight: var(--at-font-weight-medium); cursor: pointer; }
    .tools .codeq:hover { border-color: var(--at-ink-soft); color: var(--at-ink); }

    /* ---------- ovládání prezentace ---------- */
    .demo { margin: 10px 16px 0; padding: 10px; background: var(--at-info-soft); border-radius: var(--at-radius-control); }
    .demo .dhead { font-size: var(--at-font-size-small); font-weight: var(--at-font-weight-semibold); color: var(--at-ink); }
    .demo .dwait { margin-top: 6px; padding: 6px 8px; font-size: var(--at-font-size-small); line-height: 1.4; color: var(--at-ink);
                   background: var(--at-warning-soft); border-radius: var(--at-radius-control); }
    .demo .drow { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; margin-top: 8px; }
    .demo .sp { flex: 1 1 0; min-width: 0; }
    .db.stop { color: var(--at-danger); }
    .dsp { display: inline-flex; align-items: center; gap: 6px; font-size: var(--at-font-size-small); color: var(--at-ink-soft); }
    .dsp select { width: auto; min-height: 28px; margin: 0; padding: 0 6px; font-size: var(--at-font-size-small); }
    /* pauza mezi kroky — hlavní ovládání tempa, proto vlastní řádek */
    .demo .dpauza { border-top: var(--at-border-rule) solid var(--at-rule); margin-top: 8px; padding-top: 8px; }
    .db.kr { min-width: 32px; padding: 2px 8px; font-size: 16px; line-height: 1; }
    .dcas { font-size: var(--at-font-size-small); color: var(--at-ink-soft); font-variant-numeric: tabular-nums; }
    .dcas strong { font-size: var(--at-font-size-table); color: var(--at-ink); }
    .dvolba { margin: 14px 0 0; padding: 12px; background: var(--at-canvas);
              border: var(--at-border-rule) solid var(--at-rule); border-radius: var(--at-radius-control); }
    .dvolba > label { display: block; font-size: var(--at-font-size-small); font-weight: var(--at-font-weight-semibold); color: var(--at-ink); }
    .dvolba .drow { display: flex; align-items: center; gap: 10px; margin-top: 6px; }
    .dvolba input[type="range"] { flex: 1 1 auto; min-width: 0; }
    .dvolba .hint { margin: 8px 0 0; font-size: var(--at-font-size-small); line-height: 1.45; color: var(--at-muted); }
    .dvolba .dsp { margin-top: 8px; }
    /* výběr scénáře k předvedení */
    .dvyber { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
    .beak { position: fixed; width: 14px; height: 14px; background: var(--at-surface-1);
            border: var(--at-border-rule) solid var(--at-rule-strong); transform: rotate(45deg); z-index: 19;
            transition: top var(--at-motion-base) var(--at-motion-ease), left var(--at-motion-base) var(--at-motion-ease); }

    /* ---------- uvítací okno (rozcestník) — vzor .at-dialog ---------- */
    .wback { position: fixed; inset: 0; background: var(--at-overlay); z-index: 30; pointer-events: auto; }
    .welcome { position: fixed; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 620px; max-width: calc(100vw - 32px);
               max-height: 84vh; display: flex; flex-direction: column; background: var(--at-surface-1); color: var(--at-ink);
               border: var(--at-border-rule) solid var(--at-rule-strong); border-radius: var(--at-radius-dialog);
               box-shadow: var(--at-shadow-layer); z-index: 31; pointer-events: auto; overflow: hidden; }
    .welcome .whead { display: flex; align-items: center; gap: var(--at-space-3); padding: 12px 12px 10px 20px;
                      border-bottom: var(--at-border-rule) solid var(--at-dialog-head-rule); }
    .welcome .whead h2 { flex: 1; margin: 0; font-size: var(--at-font-size-h3); font-weight: var(--at-heading-weight);
                         line-height: var(--at-line-height-heading); color: var(--at-ink); }
    .welcome .wsub { padding: 12px 20px 4px; font-size: var(--at-font-size-text); color: var(--at-ink-soft); }
    .wsub .lg { display: block; margin-top: 6px; font-size: var(--at-font-size-small); color: var(--at-muted); }
    /* Vzorek rámečku v legendě — tentýž tvar a barva jako na stránce. */
    .vz { display: inline-block; width: 16px; height: 11px; margin-right: 5px; vertical-align: -1px;
          border: 3px solid var(--icop2-povinne); border-radius: var(--at-radius-control); }
    .vz.yellow { border-color: var(--icop2-doporuceni); }
    .wlist { padding: 10px 16px 16px; overflow: auto; }
    /* hledání kroku podle slova nebo kódu */
    .wsearch { padding: 4px 20px 0; }
    .wres { margin-top: 8px; }
    .wres .hit { display: flex; align-items: baseline; gap: 10px; width: 100%; text-align: left; margin: 0; padding: 8px 4px;
                 border: 0; border-bottom: var(--at-border-rule) solid var(--at-rule); background: transparent; color: inherit; cursor: pointer; }
    .wres .hit:hover { background: var(--at-canvas); }
    .wres .hit .kod { flex: none; padding: 0 6px; font-family: var(--at-font-data); font-size: 12px; font-weight: var(--at-font-weight-medium);
                      color: var(--at-ink-soft); background: var(--at-surface-1); border: var(--at-border-rule) solid var(--at-rule-strong);
                      border-radius: var(--at-radius-control); }
    .wres .hit .txt2 { min-width: 0; }
    .wres .hit .t { display: block; font-size: var(--at-font-size-table); font-weight: var(--at-font-weight-semibold); color: var(--at-ink); }
    .wres .hit .s { display: block; font-size: var(--at-font-size-small); color: var(--at-muted); margin-top: 1px; }
    .wres .nic { font-size: var(--at-font-size-small); color: var(--at-muted); padding: 4px 2px 8px; }
    /* úvodní dotaz na kontakt pro hotlinku */
    .wform { padding: 4px 20px 20px; overflow: auto; }
    .wform label { display: block; font-size: var(--at-font-size-small); font-weight: var(--at-font-weight-semibold); color: var(--at-ink); margin-top: 12px; }
    .wform .hint { margin-top: 4px; font-size: var(--at-font-size-small); color: var(--at-muted); line-height: 1.45; }
    .wform .hint.ok { color: var(--at-success); font-weight: var(--at-font-weight-semibold); }
    .wform .wact { display: flex; flex-wrap: wrap; gap: var(--at-space-2); margin-top: 16px; }
    /* Seznam scénářů: řádky oddělené linkou, ne mřížka karet. */
    .scen-radek { border-bottom: var(--at-border-rule) solid var(--at-rule); }
    .scen-radek .scen-item { margin-bottom: 0; }
    .scen-znovu { display: flex; margin: 0 0 8px 48px; min-height: 28px; padding: 2px 10px; }
    .scen-item { display: flex; align-items: center; gap: 12px; width: 100%; margin: 0; padding: 10px 8px; text-align: left;
                 border: 0; background: transparent; color: inherit; cursor: pointer; }
    .scen-item:hover { background: var(--at-canvas); }
    .scen-item.dis { cursor: default; }
    .scen-item.dis:hover { background: transparent; }
    .scen-item .num { display: flex; align-items: center; justify-content: center; flex: none; width: 28px; height: 28px;
                      border: var(--at-border-rule) solid var(--at-rule-strong); border-radius: var(--at-radius-control);
                      background: var(--at-surface-1); color: var(--at-ink); font-size: var(--at-font-size-small);
                      font-weight: var(--at-font-weight-semibold); font-variant-numeric: tabular-nums; }
    .scen-item.dis .num { border-color: var(--at-rule); color: var(--at-muted); }
    .scen-item .st { flex: 1; min-width: 0; }
    .scen-item .st .t { display: block; font-size: var(--at-font-size-text); font-weight: var(--at-font-weight-semibold); color: var(--at-ink); }
    .scen-item .st .d { display: block; font-size: var(--at-font-size-small); color: var(--at-muted); margin-top: 2px; }
    .scen-item.dis .st .t { color: var(--at-muted); }
    /* Stav scénáře slovem v barvě stavu (vzor .at-stav): probíhá = info,
       hotovo = úspěch, čeká = varování. „Spustit“ je akce, proto barva odkazu. */
    .badge { flex: none; display: inline-flex; align-items: center; gap: 4px; font-size: var(--at-font-size-small);
             font-weight: var(--at-font-weight-medium); white-space: nowrap; color: var(--at-ink-soft); }
    .badge.go { color: var(--at-accent-text); font-weight: var(--at-font-weight-semibold); }
    .badge.cont { color: var(--at-info); font-weight: var(--at-font-weight-semibold); }
    .badge.done { color: var(--at-success); }
    .badge.soon { color: var(--at-muted); }
    .badge.lock { color: var(--at-warning); white-space: normal; max-width: 180px; }
    /* odhad času na projití scénáře */
    .scen-item .st .d .min { display: inline-flex; align-items: center; gap: 3px; margin-left: 8px; white-space: nowrap; }
    .scen-item .st .d .min .at-i { width: 14px; height: 14px; }

    /* výběr obchodního specialisty v úvodním dotazu */
    .spvyber { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px; }
    .spvol { min-height: var(--at-control-height); font-size: var(--at-font-size-table); }

    /* uvítací video po úvodním dotazu */
    .wvideo { padding: 12px 20px 0; }
    .wvideo video { display: block; width: 100%; border-radius: var(--at-radius-control); background: var(--at-ink); }
    .wact.uvitakce { display: flex; justify-content: flex-end; padding: 12px 20px 20px; }

    /* ---------- režim správce: úprava kroku přímo na stránce ---------- */
    .edit { margin: 10px 16px 0; padding: 10px 12px; background: var(--at-canvas);
            border: var(--at-border-rule) solid var(--at-rule-strong); border-radius: var(--at-radius-control); font-size: var(--at-font-size-small); }
    .edit .ehead { display: flex; align-items: center; gap: 6px; font-size: var(--at-font-size-small);
                   font-weight: var(--at-font-weight-semibold); color: var(--at-ink); margin-bottom: 2px; }
    .edit label { display: block; font-size: var(--at-font-size-small); font-weight: var(--at-font-weight-semibold); color: var(--at-ink); margin-top: 8px; }
    .edit input[type="text"], .edit input[type="number"], .edit textarea, .edit select {
      min-height: 32px; font-size: var(--at-font-size-small); }
    .edit textarea { min-height: 84px; padding-block: 6px; resize: vertical; }
    .edit .erow { display: flex; gap: 8px; }
    .edit .erow label { flex: 1 1 0; min-width: 0; }
    .edit .eacts { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 10px; }
    .edit .ehint { margin-top: 8px; font-size: var(--at-font-size-small); line-height: 1.45; color: var(--at-muted); }
    .edit .ehint .ok { color: var(--at-success); font-weight: var(--at-font-weight-semibold); }
    .edit details { margin-top: 10px; }
    .edit details > summary { font-size: var(--at-font-size-small); font-weight: var(--at-font-weight-semibold); color: var(--at-ink); cursor: pointer; }
    .edit .ekroky { max-height: 180px; overflow: auto; margin-top: 6px; padding: 4px 8px; background: var(--at-surface-1);
                    border: var(--at-border-rule) solid var(--at-rule); border-radius: var(--at-radius-control); }
    .edit .ekroky label { display: flex; gap: 7px; align-items: baseline; margin: 3px 0; font-weight: var(--at-font-weight-regular); }
    .edit .ekroky .eid { flex: none; font-family: var(--at-font-data); font-size: 12px; color: var(--at-muted); }
    .edit .evidea { display: flex; align-items: center; gap: 7px; margin-top: 10px; }

    /* výběr prvku na stránce (režim správce) */
    .vybram { position: fixed; border: 2px solid var(--at-accent); background: color-mix(in srgb, var(--at-accent) 10%, transparent);
              border-radius: var(--at-radius-control); pointer-events: none; z-index: 60; }
    .vyblista { position: fixed; top: 10px; left: 50%; transform: translateX(-50%); max-width: calc(100vw - 40px);
                padding: 8px 16px; background: var(--at-ink); color: var(--at-surface-1); border-radius: var(--at-radius-control);
                font-size: var(--at-font-size-small); font-weight: var(--at-font-weight-semibold); z-index: 61; pointer-events: none;
                box-shadow: var(--at-shadow-layer); }

    /* prezentace a cvičení v rozcestníku */
    .wdemo { padding: 0 16px 16px; }
    .dstart { display: block; width: 100%; margin: 0; padding: 10px 14px; text-align: left;
              border: var(--at-border-rule) solid var(--at-rule-strong); border-radius: var(--at-radius-control);
              background: var(--at-surface-1); color: var(--at-ink); font-size: var(--at-font-size-text);
              font-weight: var(--at-font-weight-semibold); cursor: pointer; }
    .dstart + .dstart { margin-top: 8px; }
    .dstart:hover { background: var(--at-canvas); border-color: var(--at-ink-soft); }
    .dstart > .at-i { margin-right: 8px; color: var(--at-ink-soft); }
    .dstart span:not(.at-i) { display: block; margin-top: 2px; font-size: var(--at-font-size-small);
                              font-weight: var(--at-font-weight-regular); color: var(--at-muted); }
    .dstart.bezi { background: var(--at-info-soft); }

    /* ---------- cvičení ---------- */
    .wcv { padding: 0 16px 10px; }
    .cvskup { margin-bottom: 14px; }
    .cvskup h3 { margin: 0 0 6px; font-size: var(--at-font-size-small); font-weight: var(--at-font-weight-semibold); color: var(--at-ink-soft); }
    .cvskup .scen-item { border-bottom: var(--at-border-rule) solid var(--at-rule); }
    .scen-item .num.cvnum { font-size: 12px; }
    .card .cvzad { font-size: 16px; line-height: 1.55; }
    .cvnap { margin: 10px 16px 0; padding: 10px 12px; font-size: var(--at-font-size-small); line-height: 1.5;
             color: var(--at-ink); background: var(--at-info-soft); border-radius: var(--at-radius-control); }
    .cvres { margin: 10px 16px 0; border-top: var(--at-border-rule) solid var(--at-ink); }
    .cvres .cvr { display: flex; align-items: baseline; gap: 10px; padding: 8px 4px; border-bottom: var(--at-border-rule) solid var(--at-rule); }
    .cvres .k { flex: none; width: 90px; font-size: var(--at-font-size-small); color: var(--at-muted); }
    .cvres .v { font-size: 16px; font-weight: var(--at-font-weight-semibold); color: var(--at-ink); font-variant-numeric: tabular-nums; }
    .cvres .p { font-size: var(--at-font-size-small); color: var(--at-muted); }

    /* ---------- výuka: souhrn, výsledky, zadání ---------- */
    .cvsouhrn { display: flex; gap: 16px; padding: 0 20px 10px; }
    .cvsouhrn .cvr { flex: 1; padding-top: 6px; border-top: var(--at-border-rule) solid var(--at-rule-strong); }
    .cvsouhrn .k { display: block; font-size: var(--at-font-size-small); color: var(--at-muted); }
    .cvsouhrn .v { display: block; font-size: 18px; font-weight: var(--at-font-weight-semibold); color: var(--at-ink);
                   margin-top: 1px; font-variant-numeric: tabular-nums; }
    .cvsouhrn.maly .v { font-size: 16px; }
    .cvlist .cvrad { display: flex; align-items: baseline; gap: 10px; padding: 8px 2px; border-bottom: var(--at-border-rule) solid var(--at-rule); }
    .cvlist .cvrad .t { flex: 1; font-size: var(--at-font-size-table); color: var(--at-ink); }
    .cvlist .cvrad .v { font-size: var(--at-font-size-small); font-weight: var(--at-font-weight-semibold); color: var(--at-ink-soft);
                        font-variant-numeric: tabular-nums; }
    .cvlist .cvrad .n { font-size: var(--at-font-size-small); color: var(--at-muted); width: 104px; text-align: right; }
    .cvlist .cvrad .n.ok { color: var(--at-success); font-weight: var(--at-font-weight-semibold); }
    .cvlist .cvrad.ne .t { color: var(--at-muted); }
    .cvplan { display: flex; flex-wrap: wrap; align-items: center; gap: 4px 6px; margin: 0 16px 10px; padding: 10px 12px;
              font-size: var(--at-font-size-small); line-height: 1.45; color: var(--at-ink);
              background: var(--at-info-soft); border-radius: var(--at-radius-control); }
    .cvplan button { min-height: 28px; padding: 2px 8px; }
    .scen-item.zadano { background: var(--at-canvas); }
    .cvvol { display: flex; align-items: center; gap: 10px; padding: 8px 2px; border-bottom: var(--at-border-rule) solid var(--at-rule); cursor: pointer; }
    .cvvol .t { flex: 1; font-size: var(--at-font-size-table); color: var(--at-ink); }
    .cvvol .m { font-size: var(--at-font-size-small); color: var(--at-muted); font-variant-numeric: tabular-nums; }
    .wform input[readonly] { background: var(--at-surface-2); font-family: var(--at-font-data); font-size: 13px; }
    .wdemoask { padding: 14px 20px 20px; overflow: auto; }
    .wdemoask p { margin: 0 0 10px; font-size: var(--at-font-size-text); line-height: var(--at-line-height-body); color: var(--at-ink); }
    .wdemoask p.pozor { display: flex; gap: var(--at-space-2); align-items: flex-start; padding: 10px 12px;
                        background: var(--at-warning-soft); border-radius: var(--at-radius-control); }
    .wdemoask .wask { display: flex; flex-wrap: wrap; gap: var(--at-space-2); margin-top: 14px; }

    /* ---------- plovoucí tlačítko ----------
       Pojmenované tlačítko místo kulatého „?“ (PRAVIDLA, oddíl 4: žádná
       nepojmenovaná ikona). Verze u názvu odliší průvodce v2 od v1. */
    .fab { position: fixed; display: inline-flex; align-items: center; gap: var(--at-space-2); height: 44px; padding: 0 14px 0 12px;
           border: var(--at-border-rule) solid var(--at-accent); border-radius: var(--at-radius-control);
           background: var(--at-accent); color: var(--at-on-accent); font-size: var(--at-font-size-table);
           font-weight: var(--at-font-weight-semibold); line-height: 1; white-space: nowrap; cursor: pointer;
           box-shadow: var(--at-shadow-layer); z-index: 40; pointer-events: auto; user-select: none; touch-action: none; }
    .fab:hover { border-color: var(--at-accent-hover); background: var(--at-accent-hover); }
    .fab .at-i { width: 20px; height: 20px; }
    .fab .b20 { font-weight: var(--at-font-weight-regular); font-variant-numeric: tabular-nums; }
    .fab.off { border-color: var(--at-field-border); background: var(--at-surface-1); color: var(--at-ink-soft); }
    .fmenu { position: fixed; width: 280px; padding: 4px; background: var(--at-surface-1);
             border: var(--at-border-rule) solid var(--at-rule-strong); border-radius: var(--at-radius-dialog);
             box-shadow: var(--at-shadow-layer); z-index: 41; pointer-events: auto; overflow: hidden; }
    .fmenu .row { display: flex; align-items: center; gap: 10px; width: 100%; min-height: 40px; margin: 0; padding: 8px 12px;
                  border: 0; border-radius: var(--at-radius-control); background: transparent; color: var(--at-ink);
                  text-align: left; font-size: var(--at-font-size-table); font-weight: var(--at-font-weight-medium); cursor: pointer; }
    .fmenu .row:hover { background: var(--at-surface-2); }
    .fmenu .row .at-i { color: var(--at-ink-soft); }
    /* Přepínač (vzor .at-switch): dráha s jezdcem, stav nese i text řádku. */
    .fmenu .row .sw { position: relative; flex: none; margin-left: auto; width: 38px; height: 22px;
                      border: var(--at-border-rule) solid var(--at-field-border); border-radius: var(--at-radius-control);
                      background: var(--at-surface-1); transition: background var(--at-motion-base) var(--at-motion-ease); }
    .fmenu .row .sw::after { content: ""; position: absolute; top: 3px; left: 3px; width: 14px; height: 14px;
                             border-radius: 1px; background: var(--at-field-border);
                             transition: left var(--at-motion-base) var(--at-motion-ease); }
    .fmenu .row .sw.on { border-color: var(--at-accent); background: var(--at-accent); }
    .fmenu .row .sw.on::after { left: 19px; background: var(--at-on-accent); }
    .hidden { display: none !important; }
    /* Cíl odrolovaný z dohledu — průvodce zmizí, ale zůstane změřitelný, aby
       se po odrolování zpátky objevil na správném místě bez poskočení. */
    .mimo { visibility: hidden !important; pointer-events: none !important; }
    /* Otevřený rozcestník — karta kroku pod ním nesvítí, aby uživatel nečetl
       dvě obrazovky naráz. */
    .zaoknem { visibility: hidden !important; pointer-events: none !important; }
  `;
  root.appendChild(style);

  // spotlight SVG
  const spot = document.createElementNS(SVGNS, 'svg');
  spot.setAttribute('class', 'spot hidden');
  const defs = document.createElementNS(SVGNS, 'defs');
  const mask = document.createElementNS(SVGNS, 'mask');
  mask.setAttribute('id', 'icop2m');
  const maskBg = document.createElementNS(SVGNS, 'rect');
  maskBg.setAttribute('x', '0'); maskBg.setAttribute('y', '0');
  maskBg.setAttribute('width', '100%'); maskBg.setAttribute('height', '100%');
  maskBg.setAttribute('fill', 'white');
  mask.appendChild(maskBg);
  defs.appendChild(mask);
  spot.appendChild(defs);
  const shade = document.createElementNS(SVGNS, 'rect');
  shade.setAttribute('x', '0'); shade.setAttribute('y', '0');
  shade.setAttribute('width', '100%'); shade.setAttribute('height', '100%');
  shade.setAttribute('class', 'shade');   // barva závoje = token --at-overlay
  shade.setAttribute('mask', 'url(#icop2m)');
  spot.appendChild(shade);
  root.appendChild(spot);

  const labelsLayer = document.createElement('div');
  labelsLayer.className = 'labels';
  root.appendChild(labelsLayer);

  const beak = document.createElement('div');
  beak.className = 'beak hidden';
  root.appendChild(beak);

  const card = document.createElement('div');
  card.className = 'card hidden';
  card.setAttribute('role', 'dialog');
  card.setAttribute('aria-live', 'polite');
  card.setAttribute('aria-labelledby', 'icop2-step-title');
  root.appendChild(card);

  const wback = document.createElement('div');
  wback.className = 'wback hidden';
  root.appendChild(wback);
  const welcome = document.createElement('div');
  welcome.className = 'welcome hidden';
  welcome.setAttribute('role', 'dialog');
  welcome.setAttribute('aria-modal', 'true');
  welcome.setAttribute('aria-labelledby', 'icop2-welcome-title');
  welcome.tabIndex = -1;
  root.appendChild(welcome);

  const fab = document.createElement('button');
  fab.type = 'button';
  fab.className = 'fab';
  fab.innerHTML = `${ik('napoveda')}<span>Průvodce</span><span class="b20">${UI_VERSION}</span>`;
  fab.title = `IC Office Tutoriál ${UI_VERSION}`;
  fab.setAttribute('aria-label', 'Otevřít nabídku IC Office Tutoriálu');
  fab.setAttribute('aria-haspopup', 'menu');
  fab.setAttribute('aria-expanded', 'false');
  // Na veřejné stránce se tlačítko nesmí ani mihnout — applyEnabled() přijde
  // až po načtení stavu ze storage, což je několik snímků po vykreslení.
  if (verejnaStranka()) fab.classList.add('hidden');
  root.appendChild(fab);
  const fmenu = document.createElement('div');
  fmenu.className = 'fmenu hidden';
  fmenu.setAttribute('role', 'menu');
  fmenu.setAttribute('aria-label', 'Nabídka IC Office Tutoriálu');
  root.appendChild(fmenu);

  document.documentElement.appendChild(host);

  // ------------------------------------------------------------------ engine
  const engine = {
    scenario: null,
    steps: [],
    idx: -1,
    step: null,
    stage: 1,             // 1 = hlavní cíl, 2 = „then" cíl (menu/modal se otevřel)
    unlocked: true,       // gated tlačítko odemčeno?
    fallbackNext: false,  // cíl dlouho nenalezen → nouzové tlačítko Pokračovat
    targetMissing: false, // cíl kroku na stránce není (zavřené okno) → upozornit
    jumpFrom: null,       // { idx, title } — zobrazený krok NEodpovídá uloženému
    _path: '',            // adresa při zobrazení kroku (detekce navigace bez reloadu)
    _timer: null,
    _autoTicks: 0,
    _hiddenWasVisible: false,
    _hiddenTicks: 0,
    _notFoundTicks: 0,
    _holes: new Map(),    // key -> { holeRect, lemRect, ringRect, lbl }
    _userBackIdx: null,   // krok, na který se uživatel vrátil tlačítkem Zpět
    _vlnaOtevreno: false, // nabídka našeptávače byla vidět v minulém ticku
    _vlnaBezi: false,
    _vlnaAnimace: [],
  };

  // Některý scénář nemá smysl pustit dřív, než uživatel něco jiného dokončí —
  // „opravit fakturu" bez jediné vystavené faktury je jen matoucí. `vyzaduje`
  // je seznam scénářů, ze kterých stačí mít hotový JEDEN.
  function scenarSplnen(sc) {
    const nutne = sc && sc.vyzaduje;
    if (!Array.isArray(nutne) || !nutne.length) return true;
    return nutne.some((id) => state.done[id] === true);
  }

  function activeScenario() {
    if (!state.active) return null;
    return DATA.scenarios.find((s) => s.id === state.active.scenarioId) || null;
  }

  function tourVisible() {
    return state.enabled && state.active && !state.active.paused && engine.step;
  }

  // -------- žlutá vlna přes položky rozbalené nabídky (flashMenuItems) --------
  // Našeptávač předdefinovaných oprav (jQuery UI) vypadá jako obyčejný seznam
  // a lidé do pole psali vlastní popis, přestože stačilo vybrat. Průvodce v1
  // to řešil vlnou: položky se po sobě krátce rozsvítí žlutě — „tady se dá
  // vybírat". Ve v2 to chybělo, tak se vrací.
  //
  // Kreslí se přímo na položky ve stránce (nabídka je v light DOM), takže:
  //  • žádný vlastní <style> do cizí stránky — animace jde přes el.animate(),
  //    která po sobě uklidí sama a nenechá v DOM ani třídu navíc,
  //  • nabídka dostane díru ve ztmavení (viz renderSpotlight), jinak by žlutá
  //    prosvítala přes šedý závoj jako špinavá.
  const VLNA_ZLUTA = 'rgba(245, 197, 24, 0.85)';
  const VLNA_RAMECEK = 'inset 0 0 0 2px rgba(245, 197, 24, 0.95)';

  // První VIDITELNÁ nabídka, která opravdu má položky. Samotné `ul.ui-autocomplete`
  // nestačí: jQuery UI si na stránce drží jeden prázdný seznam ke každému poli.
  function najdiNabidku(cfg) {
    const sel = (cfg && cfg.menu) || 'ul.ui-autocomplete';
    let uzly = [];
    try { uzly = document.querySelectorAll(sel); } catch (e) { return null; }
    for (const m of uzly) {
      if (isVisible(m) && m.querySelector('li')) return m;
    }
    return null;
  }

  const VLNA_SVIT_MS = 800;     // jak dlouho svítí jedna položka
  const VLNA_PAUZA_MS = 700;    // mezera mezi koly, ať se vlna nezmění v blikání

  function vlnaStop() {
    engine._vlnaAnimace.forEach((a) => { try { a.cancel(); } catch (e) { /* */ } });
    engine._vlnaAnimace = [];
    engine._vlnaBezi = false;
    engine._vlnaOtevreno = false;
  }

  // Rozestup položek NEDĚLAJÍ časovače, ale `delay` jedné animace na položku.
  // Je to schválně: na skryté kartě Chrome škrtí setTimeout a všechny položky
  // by se rozsvítily naráz — přesně to, čemu se vlna vyhýbá. Časová osa
  // animací tímhle netrpí.
  function vlnaSpust(menu, cfg) {
    const perItem = Math.max(40, Number(cfg.perItem) || 160);
    const repeats = Math.max(1, Number(cfg.repeats) || 2);
    const maxItems = Number(cfg.maxItems) > 0 ? Number(cfg.maxItems) : 12;
    const polozky = [...menu.querySelectorAll('li')].slice(0, maxItems);
    if (!polozky.length) return;
    // Jedno kolo = všechny položky po sobě + pauza. Svit je jen krátký úsek
    // na začátku cyklu, zbytek položka „čeká", než na ni přijde další kolo.
    const cyklus = polozky.length * perItem + VLNA_PAUZA_MS;
    const podil = Math.min(0.9, VLNA_SVIT_MS / cyklus);
    const zhasnuto = { backgroundColor: 'rgba(245, 197, 24, 0)', boxShadow: 'inset 0 0 0 0 rgba(245, 197, 24, 0)' };
    polozky.forEach((li, i) => {
      let a = null;
      try {
        a = li.animate([
          Object.assign({ offset: 0, easing: 'ease-in' }, zhasnuto),
          { offset: podil * 0.35, backgroundColor: VLNA_ZLUTA, boxShadow: VLNA_RAMECEK, easing: 'ease-out' },
          Object.assign({ offset: podil }, zhasnuto),
          Object.assign({ offset: 1 }, zhasnuto)
        ], { duration: cyklus, delay: i * perItem, iterations: repeats });
      } catch (e) { return; }   // prohlížeč bez WAAPI — vlna prostě nebude
      engine._vlnaAnimace.push(a);
    });
    if (!engine._vlnaAnimace.length) return;
    engine._vlnaBezi = true;
    // Konec vlny je i ZRUŠENÍ animace, ne jen doběhnutí. Prohlížeč animace ruší
    // sám, jakmile položka zmizí z dokumentu — a jQuery UI si položky při každém
    // otevření překresluje. S `then(konec)` bez druhé větve zůstal příznak
    // „vlna běží“ navždy na true a druhé rozbalení nabídky už nic nerozsvítilo
    // (nález z živého provozu).
    const konec = () => { engine._vlnaBezi = false; engine._vlnaAnimace = []; };
    engine._vlnaAnimace[engine._vlnaAnimace.length - 1].finished.then(konec, konec);
  }

  // Volá se z ticku. Vlna se spouští na HRANĚ zavřeno → otevřeno, aby se
  // neopakovala pořád dokola, dokud má uživatel nabídku rozbalenou.
  function vlnaTick(step) {
    const cfg = step && step.flashMenuItems;
    if (!cfg) return;
    const menu = najdiNabidku(cfg);
    // Zavřená nabídka = vlna nemá co rozsvěcet. Druhá pojistka proti zaseknutému
    // příznaku: kdyby slib o konci animace nedorazil, další otevření se tím
    // odblokuje samo.
    if (!menu) engine._vlnaBezi = false;
    else if (!engine._vlnaOtevreno && !engine._vlnaBezi) vlnaSpust(menu, cfg);
    engine._vlnaOtevreno = !!menu;
  }

  // ---------------- spotlight ----------------
  function clearHoles() {
    for (const h of engine._holes.values()) {
      h.holeRect.remove(); h.lemRect.remove(); h.ringRect.remove(); if (h.lbl) h.lbl.remove();
    }
    engine._holes.clear();
  }

  function upsertHole(key, rect, color, labelText, odstup) {
    let h = engine._holes.get(key);
    if (!h) {
      const holeRect = document.createElementNS(SVGNS, 'rect');
      holeRect.setAttribute('class', 'hole');
      holeRect.setAttribute('fill', 'black');
      holeRect.setAttribute('rx', '2');
      mask.appendChild(holeRect);
      // Světlý lem vně rámečku: víno oblasti na závoji nad tmavou lištou samo
      // nestačí (1,9 : 1), lem drží rámeček vidět na tmavé i světlé stránce.
      const lemRect = document.createElementNS(SVGNS, 'rect');
      lemRect.setAttribute('class', 'lem');
      lemRect.setAttribute('rx', '4');
      spot.appendChild(lemRect);
      const ringRect = document.createElementNS(SVGNS, 'rect');
      ringRect.setAttribute('class', 'ring');
      ringRect.setAttribute('rx', '3');
      spot.appendChild(ringRect);
      let lbl = null;
      if (labelText) {
        lbl = document.createElement('div');
        lbl.className = 'lbl ' + (color === YELLOW ? YELLOW : RED);
        lbl.innerHTML = stitekHtml(labelText);
        lbl.dataset.pro = key;   // ke kterému rámečku patří — viz resolveLabelCollisions
        labelsLayer.appendChild(lbl);
      }
      h = { holeRect, lemRect, ringRect, lbl };
      engine._holes.set(key, h);
    }
    // U těsných formulářů se rámečky semknou k prvku (viz odstupRamecku).
    // Světlý výřez se semkne s nimi — jinak by rámeček spadl dovnitř výřezu.
    const rx = odstup && odstup.x !== undefined ? odstup.x : RAMECEK_ODSTUP;
    const ry = odstup && odstup.y !== undefined ? odstup.y : RAMECEK_ODSTUP;
    const p = pad(rect, Math.max(0, rx - 2), Math.max(0, ry - 2));
    h.holeRect.setAttribute('x', p.left); h.holeRect.setAttribute('y', p.top);
    h.holeRect.setAttribute('width', Math.max(4, p.width)); h.holeRect.setAttribute('height', Math.max(4, p.height));
    const q = pad(rect, rx, ry);
    // Rozměry rámečku si pamatujeme. Číst je zpátky z SVG nejde: v okamžiku,
    // kdy se rozmisťují štítky, může být spotlight ještě schovaný a všechny
    // rozměry pak vyjdou nulové.
    h.q = q;
    h.ringRect.setAttribute('x', q.left); h.ringRect.setAttribute('y', q.top);
    h.ringRect.setAttribute('width', Math.max(4, q.width)); h.ringRect.setAttribute('height', Math.max(4, q.height));
    h.ringRect.setAttribute('class', 'ring ' + (color === YELLOW ? YELLOW : RED));
    const l = pad(rect, rx + 3, ry + 3);
    h.lemRect.setAttribute('x', l.left); h.lemRect.setAttribute('y', l.top);
    h.lemRect.setAttribute('width', Math.max(4, l.width)); h.lemRect.setAttribute('height', Math.max(4, l.height));
    // Štítek se NEUMISŤUJE tady. Dělá to resolveLabelCollisions, která jediná
    // vidí všechny rámečky i ostatní štítky naráz — dvě místa počítající tutéž
    // polohu se rozešla a štítky skončily slepené v rohu okna.
    return h;
  }

  function removeStaleHoles(liveKeys) {
    for (const [key, h] of engine._holes) {
      if (!liveKeys.has(key)) {
        h.holeRect.remove(); h.lemRect.remove(); h.ringRect.remove(); if (h.lbl) h.lbl.remove();
        engine._holes.delete(key);
      }
    }
  }

  // Kam se štítek postaví.
  //
  // U ŠIROKÝCH prvků (formulářová pole přes celou šířku) jde štítek do prázdného
  // pruhu VLEVO VEDLE pole a svisle na jeho střed. Tam nezakrývá ani vyplňovanou
  // hodnotu, ani sousední řádek formuláře, a je jasně vidět, ke kterému řádku
  // patří. Uvnitř pole naopak seděl přesně na tom, co má uživatel číst.
  //
  // U ÚZKÝCH prvků (tlačítka, položky menu) tohle nejde — vlevo od nich je
  // soused, ne prázdno, takže tam štítek zůstává na svém prvku jako dosud.
  //
  // Štítky se navíc nesmí překrývat mezi sebou ani padnout na CIZÍ vysvícený
  // prvek. Kolidující uhýbají jen SVISLE a nejvýš tak, aby zůstaly u svého
  // řádku — uhýbání do strany je u polí přes celou šířku odstřelilo za pravý
  // okraj a nebylo poznat, kam patří.
  //
  // POZOR: nepočítat přes getBoundingClientRect — štítky mají CSS transition na
  // top/left a čerstvě zapsaná pozice by se změřila stará (kolize by „nemizela").
  // Počítáme aritmeticky z cílových style hodnot.
  function resolveLabelCollisions() {
    // Poloha se počítá VŽDY ZNOVU z rámečku, ke kterému štítek patří — nikdy
    // se nečte zpátky z vlastního stylu. Čtení zpět se při prvním vykreslení
    // (rámeček ještě nemá rozměry) uzamklo na nule a štítky pak zůstaly
    // slepené v rohu okna, i když se rámečky mezitím spočítaly správně.
    const rects = [...labelsLayer.children].map((l) => ({
      l,
      w: l.offsetWidth || 80,
      h: l.offsetHeight || 22,
      // Štítek smí ležet na rámečku prvku, který sám popisuje — ne na cizím.
      pro: l.dataset.pro || ''
    }));
    // Překážky nejsou jen ostatní štítky, ale i VYSVÍCENÁ POLE. Štítek, který
    // padne na cizí pole, zakryje přesně to, co má uživatel číst nebo vyplnit
    // — a když jsou pole ve formuláři těsně pod sebou, stane se to snadno.
    const prekazky = [];
    for (const [key, h] of engine._holes) {
      if (h.q && h.q.width && h.q.height) {
        prekazky.push({ key, left: h.q.left, top: h.q.top, w: h.q.width, h: h.q.height });
      }
    }
    const kolize = (r, p, mezera) =>
      !(r.left + r.w < p.left - mezera || r.left > p.left + p.w + mezera
        || r.top + r.h < p.top - mezera || r.top > p.top + p.h + mezera);

    // Vysvícený OBAL (řádek zakázky, panel) není pro štítky prvků UVNITŘ něj
    // překážka. Leží v něm úplně všechno, takže by kolem ikon nezbylo jediné
    // volné místo a všechny štítky by spadly zpátky na ně. Přes prázdné pozadí
    // obalu vést smí; přes sousední vysvícenou ikonu pořád ne.
    const obal = (p, m) => !!m && p.key !== m.key
      && p.left <= m.left && p.top <= m.top
      && p.left + p.w >= m.left + m.w && p.top + p.h >= m.top + m.h
      && (p.w >= m.w + 16 || p.h >= m.h + 16);
    const prekazi = (p, r) => p.key !== r.pro && !obal(p, r.muj);

    // Prvek širší než tohle je formulářové pole (v IC Office jdou přes celou
    // šířku obsahu); užší je tlačítko nebo položka menu. Rozhoduje to, na kterou
    // stranu se štítek zkusí postavit dřív: u pole je volno VLEVO, kde má
    // stránka sloupec s popisky, kdežto tlačítko tam má pole, ke kterému patří,
    // a volno má naopak VPRAVO.
    const SIROKY = 200;

    for (const r of rects) {
      const muj = prekazky.find((p) => p.key === r.pro);
      if (!muj) { r.left = 6; r.top = 6; r.muj = null; continue; }
      r.muj = muj;
      // Svislé meze se hlídají jen u poloh POD a NAD prvkem. U poloh vedle
      // prvku se na ně dosud nekoukalo (dorovnal je závěrečný ořez) a měnit to
      // by přeskládalo štítky u formulářů, kde sedí správně.
      const volno = (poz) => poz.left >= 6 && poz.left + r.w <= innerWidth - 6
        && !(poz.svisle && (poz.top < 6 || poz.top + r.h > innerHeight - 6))
        && !prekazky.some((p) => prekazi(p, r)
          && kolize({ left: poz.left, top: poz.top, w: r.w, h: r.h }, p, 2));
      // 1) Nejraději VEDLE prvku, svisle na jeho střed — ne na něm. Na prvku
      //    štítek zakrýval přesně to, co si má uživatel přečíst nebo vyplnit.
      const stred = muj.top + Math.round((muj.h - r.h) / 2);
      const vlevo = { left: muj.left - r.w - 8, top: stred };
      const vpravo = { left: muj.left + muj.w + 8, top: stred };
      // 2) Vedle je obsazeno — POD prvek, případně NAD něj, zarovnaně na jeho
      //    levou hranu, ať je poznat, ke kterému prvku štítek patří. U širokých
      //    prvků se zkouší nejdřív nad: nad řádkem tabulky štítek čte jako jeho
      //    nadpis, kdežto pod ním by si stoupl do cesty štítkům jeho ikon.
      const uKraje = Math.max(6, Math.min(muj.left, innerWidth - r.w - 6));
      const pod = { left: uKraje, top: muj.top + muj.h + 6, svisle: true };
      const nad = { left: uKraje, top: muj.top - r.h - 6, svisle: true };
      const kam = (muj.w >= SIROKY ? [vlevo, vpravo, nad, pod] : [vpravo, vlevo, pod, nad]).find(volno);
      if (kam) {
        r.left = kam.left;
        r.top = kam.top;
        r.pod = kam === pod;
        r.nad = kam === nad;
        continue;
      }
      // Zachovat současnou pojistku: celý štítek mimo vlastní prvek.
      r.left = Math.max(6, Math.min(muj.left + Math.round((muj.w - r.w) / 2), innerWidth - r.w - 6));
      const nadPrvkem = muj.top - r.h - 6;
      r.nad = nadPrvkem >= 6;
      r.pod = !r.nad;
      r.top = r.nad ? nadPrvkem : muj.top + muj.h + 6;
    }
    rects.sort((a, b) => a.top - b.top || a.left - b.left);
    const placed = [];
    for (const r of rects) {
      // Štítek zůstává VLEVO u svého pole a uhýbá jen SVISLE. Uhýbání do
      // strany ho u formulářů přes celou šířku odstřelilo až za pravý okraj
      // pole a nebylo poznat, ke kterému poli patří (nález z provozu).
      // Svisle se smí posunout nejvýš tak, aby zůstal na svém poli — to ale
      // neplatí pro štítek postavený POD prvek: ten uhýbá volně dolů, jinak by
      // se řada ikon vedle sebe nedokázala poskládat pod sebe a štítky by si
      // zase sedly na ikony.
      //
      // Štítek postavený NAD prvek uhýbá naopak NAHORU. Dolů mu vede cesta
      // přesně na prvek, kterému se vyhnul — u řady polí materiálu a práce si
      // takhle štítek „Cena" sedl zpátky na pole s cenou.
      const maxTop = r.pod ? innerHeight - r.h - 6
        : (r.muj ? r.muj.top + Math.max(0, r.muj.h - r.h - 4) : innerHeight - r.h - 6);
      let guard = 0;
      while (guard++ < 8) {
        const naStitek = placed.find((p) => kolize(r, p, 4));
        const hit = naStitek || prekazky.find((p) => prekazi(p, r) && kolize(r, p, 2));
        if (!hit) break;
        // O PIXEL za toleranci, ne přesně na ni — jinak tatáž podmínka hlásí
        // kolizi dál a štítek uvízne, kde byl.
        const odstup = naStitek ? 5 : 3;
        if (r.nad) {
          const nahoru = Math.max(hit.top - r.h - odstup, 6);
          if (nahoru >= r.top) break;   // výš už to nejde — zbytek je menší zlo
          r.top = nahoru;
          continue;
        }
        const pod = Math.min(hit.top + hit.h + odstup, maxTop);
        if (pod <= r.top) break;   // níž už to nejde — zbytek je menší zlo
        r.top = pod;
      }
      r.top = Math.max(6, Math.min(r.top, innerHeight - r.h - 6));
      r.l.style.left = r.left + 'px';
      r.l.style.top = r.top + 'px';
      placed.push(r);
    }
  }

  // Odrolovaný cíl = celý průvodce se schová a po odrolování zpátky se zase
  // ukáže. Bez toho zůstal rámeček viset přes lepivé menu a ukazoval na něco
  // jiného. Schovává se, ne ruší: krok běží dál, jen není vidět.
  function mimoObraz(ano) {
    if (engine.mimoObraz === ano) return;
    engine.mimoObraz = ano;
    for (const el of [spot, labelsLayer, card, beak]) el.classList.toggle('mimo', ano);
  }

  function renderSpotlight() {
    const step = engine.step;
    if (!step || step.kind === 'info') { mimoObraz(false); spot.classList.add('hidden'); clearHoles(); return; }
    // Cvičení bez vysvícení — to je jeho smysl. Vysvítí se, až si uživatel
    // řekne o nápovědu, a jen na ten jeden krok.
    if (cvBezi() && !engine.cv.napovedaTed) { mimoObraz(false); spot.classList.add('hidden'); clearHoles(); return; }
    // Nejdřív se posbírají všechny vysvícené prvky a teprve pak se kreslí:
    // svislý odstup rámečku závisí na tom, jak těsně jsou prvky nad sebou,
    // takže ho nejde spočítat, dokud nejsou známé všechny.
    const cile = [];
    const thenEl = step.then && engine.stage === 2 ? findVisible(step.then.target) : null;
    if (thenEl) {
      // Ve druhé fázi spotlight skutečně PŘESUNOUT na nově otevřenou volbu.
      // Původní prvek a doplňky by jinak zbytečně soutěžily o pozornost.
      cile.push({ key: 't', el: thenEl, rect: thenEl.getBoundingClientRect(), color: RED, label: step.then.label || null });
    } else {
      const primEl = findVisible(step.target);
      if (primEl) {
        cile.push({ key: 'p', el: primEl, rect: primEl.getBoundingClientRect(), color: colorOf(step.color), label: step.label || null });
      }
      (step.extras || []).forEach((ex, i) => {
        const el = findVisible(ex.target);
        if (el) {
          cile.push({ key: 'x' + i, el, rect: el.getBoundingClientRect(), color: colorOf(ex.color), label: ex.label || null });
        }
      });
    }
    // Rozbalená nabídka našeptávače dostane vlastní žlutý rámeček a hlavně
    // díru ve ztmavení — přes šedý závoj by žlutá vlna přes položky nebyla
    // vidět. Přidává se AŽ ZA hlavní cíl, aby rozhodování „vidí to uživatel"
    // dál patřilo cíli kroku.
    if (step.flashMenuItems) {
      const menuEl = najdiNabidku(step.flashMenuItems);
      if (menuEl) cile.push({ key: 'm', el: menuEl, rect: menuEl.getBoundingClientRect(), color: YELLOW, label: null });
    }
    // Rozhoduje HLAVNÍ cíl kroku. Doplňky bývají hned vedle něj, takže je
    // zbytečné testovat každý zvlášť, a rozhodovat podle nich by průvodce
    // schovávalo i tehdy, když je to podstatné vidět.
    if (cile.length && !vidiUzivatel(cile[0].el)) { mimoObraz(true); return; }
    mimoObraz(false);
    const odstup = odstupRamecku(cile.map((c) => c.rect));
    const live = new Set();
    for (const c of cile) {
      upsertHole(c.key, c.rect, c.color, c.label, odstup);
      live.add(c.key);
    }
    removeStaleHoles(live);
    if (live.size === 0) { spot.classList.add('hidden'); return; }
    spot.classList.remove('hidden');
    resolveLabelCollisions();
  }

  // ---------------- vyhledávání a skok na krok ----------------
  // Průvodce byl dosud jen pro nováčka: vyber scénář, projdi ho. Jenže i
  // zkušený člověk dvakrát ročně řeší dobropis a neví jak. Hledání z toho
  // dělá nápovědu pro každodenní práci.
  //
  // Stejné pole zvládne i KÓD KROKU (OS-Z04) — díky tomu se hotline dostane
  // přesně tam, kde uživatel stojí, aniž by cokoli proklikávala.
  const bezDiakritiky = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const bezHtml = (s) => String(s || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  // Kód je zkratka scénáře a id kroku velkými písmeny. Id může mít víc úseků
  // (závěrečný krok `x-hotovo` dává OS-S-HOTOVO), proto počet ani délka úseků nejsou omezené.
  const KOD_RX = /^[A-Za-z]{2}[-\s]?[A-Za-z0-9]+(?:[-\s][A-Za-z0-9]+)*$/;

  let searchIndex = null;
  function buildIndex() {
    if (searchIndex) return searchIndex;
    searchIndex = [];
    for (const sc of DATA.scenarios) {
      if (!sc.available || !sc.steps.length) continue;
      sc.steps.forEach((step, i) => {
        const titulek = bezHtml(step.title || step.id);
        const telo = bezHtml([
          step.text, step.label, step.help,
          (step.extras || []).map((e) => e.label).join(' '),
          step.then ? step.then.text + ' ' + step.then.label : ''
        ].join(' '));
        searchIndex.push({
          scId: sc.id, i, titulek, scTitulek: sc.title,
          kod: (sc.code || '??') + '-' + String(step.id).toUpperCase(),
          hTitulek: bezDiakritiky(titulek),
          hTelo: bezDiakritiky(telo + ' ' + sc.title + ' ' + (sc.desc || ''))
        });
      });
    }
    return searchIndex;
  }

  function najdiKrok(dotaz) {
    const raw = String(dotaz || '').trim();
    if (!raw) return [];
    const idx = buildIndex();
    if (KOD_RX.test(raw)) {
      const kod = raw.toUpperCase().replace(/\s+/g, '-');
      const presne = idx.filter((r) => r.kod === kod || r.kod.replace(/-/g, '') === kod.replace(/-/g, ''));
      if (presne.length) return presne;
    }
    const slova = bezDiakritiky(raw).split(/\s+/).filter(Boolean);
    if (!slova.length) return [];
    const nalezy = [];
    for (const r of idx) {
      let skore = 0, vseSedi = true;
      for (const w of slova) {
        if (r.hTitulek.includes(w)) skore += 3;
        else if (r.hTelo.includes(w)) skore += 1;
        else { vseSedi = false; break; }
      }
      if (vseSedi) nalezy.push({ r, skore });
    }
    return nalezy.sort((a, b) => b.skore - a.skore).slice(0, 8).map((x) => x.r);
  }

  // Skok na konkrétní krok. Když je na jiné adrese, ukáže se karta „průvodce
  // čeká“ s tím, kam jít — to je přesně to, co hotline potřebuje uživateli říct.
  function jumpToStep(scId, i) {
    const sc = DATA.scenarios.find((s) => s.id === scId);
    if (!sc || !sc.steps[i]) return false;
    closeWelcome();
    // Skok podle kódu kroku nebo z hledání je ruční zásah — prezentace tím
    // končí. Jinak by pokračovala v automatickém klikání na místě, kam ji
    // nikdo neposlal.
    demoUkonci();
    if (!state.enabled) { state.enabled = true; fab.classList.remove('off'); }
    state.active = { scenarioId: scId, step: i, stepId: sc.steps[i].id, paused: false };
    saveState();
    resume(true);
    return true;
  }

  // ---------------- tisk postupu ----------------
  // Autoservis je papírové prostředí — checklist na zeď dílny se hodí.
  // Kódy kroků na výtisku navazují na hotlinku.
  function printScenario(sc) {
    if (!sc || !sc.steps.length) return;
    const h = SUP.hotline || {};
    const radky = sc.steps.map((st) => {
      const kod = (sc.code || '??') + '-' + String(st.id).toUpperCase();
      const popis = bezHtml(st.text || '');
      return `<li><span class="kod">${escHtml(kod)}</span><div class="t">${escHtml(bezHtml(st.title || st.id))}</div>`
        + (popis ? `<div class="p">${escHtml(popis)}</div>` : '') + '</li>';
    }).join('');
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write('<!DOCTYPE html><html lang="cs"><head><meta charset="utf-8"><title>'
      + escHtml(sc.title) + ' — IC Office Tutoriál</title><style>'
      + 'body{font-family:-apple-system,"Segoe UI",Arial,sans-serif;color:#1c2330;max-width:760px;margin:24px auto;padding:0 18px;line-height:1.45}'
      + 'h1{font-size:21px;margin:0 0 4px}.sub{color:#78818d;font-size:12.5px;margin:0 0 18px}'
      + 'ol{padding-left:0;list-style:none;counter-reset:k}'
      + 'li{counter-increment:k;padding:9px 0 9px 42px;border-top:1px solid #e2e7ee;position:relative;break-inside:avoid}'
      + 'li::before{content:counter(k);position:absolute;left:0;top:9px;width:28px;height:28px;border-radius:50%;'
      + 'background:#e53935;color:#fff;font-weight:800;font-size:13px;display:flex;align-items:center;justify-content:center}'
      + '.kod{float:right;font-family:ui-monospace,Consolas,monospace;font-size:11px;font-weight:800;color:#8a919c}'
      + '.t{font-weight:700;font-size:14.5px}.p{font-size:12.5px;color:#46505d;margin-top:2px}'
      + '.foot{margin-top:20px;padding-top:12px;border-top:2px solid #e53935;font-size:12px;color:#46505d}'
      + '@media print{body{margin:0}}</style></head><body>'
      + '<h1>' + escHtml(sc.title) + '</h1>'
      + '<p class="sub">' + escHtml(sc.desc || '') + ' · ' + sc.steps.length + ' kroků · průvodce '
      + escHtml(DATA.version || '') + '</p><ol>' + radky + '</ol>'
      + '<p class="foot"><strong>Nevíte si rady?</strong> Nadiktujte na hotline <strong>kód kroku</strong> '
      + 'ze sloupce vpravo — technik uvidí přesně, u čeho stojíte.'
      + (h.tel || h.email ? '<br>' + escHtml([h.nazev, h.hodiny, h.tel, h.email].filter(Boolean).join(' · ')) : '')
      + '</p></body></html>');
    w.document.close();
    w.focus();
    setTimeout(() => { try { w.print(); } catch (e) { /* uživatel si vytiskne sám */ } }, 400);
  }

  // ---------------- návody IC Office ----------------
  // „Více“ dřív ukazovalo jen naši vlastní poznámku, často o něčem jiném.
  // Teď k ní přidá výňatek z oficiální nápovědy k TÉMATU daného kroku
  // a proklik na přesnou kotvu v /help/manuals.
  let MANUALS = DATA.manuals || {};
  let MANUALS_URL = DATA.manualsUrl || '';

  function manualHtml(step) {
    const m = step && step.manual ? MANUALS[step.manual] : null;
    if (!m) return '';
    const link = MANUALS_URL
      ? `<a href="${MANUALS_URL}#${step.manual}" target="_blank" rel="noopener">Otevřít v nápovědě IC Office${ik('externi-odkaz')}</a>` : '';
    // Výňatky z nápovědy IC Office jsou dlouhá souvislá próza v úzké kartě —
    // sazbu potřebují stejně jako text kroku (6 z 9 v ní mělo vadu).
    return `<div class="manual">
      <div class="mh">Z nápovědy IC Office: ${typografie(m.titulek)}</div>
      <p>${typografie(m.text)}</p>${link}</div>`;
  }

  // ---------------- pomoc / hotline ----------------
  // KÓD KROKU (např. OS-Z04) je jednoznačná adresa místa v průvodci. Uživatel
  // ho nadiktuje na hotlinku a technik ví přesně, u čeho stojí — bez toho, aby
  // musel popisovat, čemu nerozumí.
  let SUP = DATA.support || {};
  const IS_IOS = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const IS_WIN = /Windows|Win32|Win64/.test(navigator.userAgent + ' ' + (navigator.platform || ''));

  // Doporučení nástroje pro sdílení plochy podle systému. Na Windows je to
  // Rychlá pomoc (Quick Assist) — ta je součástí systému a servis ji používá.
  const REMOTE_TIP = IS_WIN
    ? 'Sdílení plochy: spusťte <strong>Rychlou pomoc</strong> (Quick Assist) klávesami '
      + '<strong>Ctrl + Win + Q</strong>, nebo ji najděte v nabídce Start. Technik vám nadiktuje kód, '
      + 'který do ní zadáte.'
    : IS_IOS
      ? 'Sdílení plochy na iPhonu/iPadu: nainstalujte <strong>TeamViewer QuickSupport</strong> z App Store, '
        + 'spusťte ji a nahlaste technikovi ID, které se zobrazí.'
      : 'Sdílení plochy: technik nejčastěji použije <strong>TeamViewer QuickSupport</strong> — '
        + 'spusťte ho, až vás o to požádá, a nahlaste zobrazené ID.';

  // Odesílání je zapnuté, jen když je vyplněná adresa A všechny doplňkové
  // hodnoty (typicky přístupový klíč). Adresa s prázdným klíčem je běžný
  // polotovar — v takovém stavu se nesmí tvářit, že odesílání funguje,
  // protože každý pokus by skončil chybou a uživatel by čekal na hotline.
  const endpointReady = () => !!SUP.endpoint
    && Object.values(SUP.endpointExtra || {}).every((v) => String(v || '').trim() !== '');

  // Jde žádost přes cizí službu, nebo rovnou k IC Office? Uživatel má právo to
  // vědět DŘÍV, než klikne — README to přiznávalo, okno s potvrzením ne.
  // Pozná se to z adresy: co není na ic-office.eu, je třetí strana.
  function prenosCizi() {
    if (!SUP.endpoint) return false;
    try {
      const host = new URL(SUP.endpoint).hostname.toLowerCase();
      return !(host === 'ic-office.eu' || host.endsWith('.ic-office.eu'));
    } catch (e) {
      return true;   // neznámá adresa = radši varovat
    }
  }

  // Poloha na cestě scénářem: první krok 0 %, poslední 100 %.
  const pctKroku = (idx, n) => (n > 1 ? Math.round((idx / (n - 1)) * 100) : 100);

  const escHtml = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  // ---------------- číslované body v textu kroku ----------------
  // Obsah kroků čísluje varianty znaky ①②③. Ve fontu prohlížeče vycházejí
  // drobné a v bílé barvě na štítku byly prakticky nečitelné. Nahrazujeme je
  // proto vlastní značkou — kolečko s obyčejnou číslicí, které si samo řídí
  // velikost i kontrast podle podkladu.
  const KROUZKY = /[①-⑳]/g;                      // ① až ⑳
  const cisloZnacka = (ch) => `<span class="cis">${ch.codePointAt(0) - 0x245F}</span>`;

  // ---------------- česká typografie ----------------
  // V úzké kartě se text láme často, takže na ní jde vidět každý prohřešek.
  // Sazba drží pohromadě tři věci:
  //
  //   1. Jednopísmenné předložky a spojky (a, i, k, o, s, u, v, z). České
  //      pravidlo je nenechat je na konci řádku — vážou se k následujícímu
  //      slovu. Vážeme je ale i k předchozímu, aby řádek nezačínal osamoceným
  //      „a“, které vypadá jako překlep (nález z provozu: „VIN (17 znaků)“ /
  //      „a SPZ“). Dozadu jen u krátkého slova, jinak by vznikl neroztržitelný
  //      blok, který text rozhází jinde.
  //   2. Číslo a jeho jednotka — „17 znaků“, „2 hodiny“, „31 kroků“.
  //   3. Skupiny číslic v telefonu — „+420 604 964 867“.
  //
  // Pevné mezery se sázejí AŽ PŘI VYKRESLENÍ, ne do obsahu: obsah se dá
  // přepsat vlastním souborem z editoru a ten by je neobsahoval.
  const JEDNOPISMENNA = 'aAiIkKoOsSuUvVzZ';
  const MAX_KUS = 40;   // znaků; delší neroztržitelný kus by přetekl řádek
  // Značky jsou při sazbě schované za zástupné znaky — do délky se nepočítají.
  const delkaBezZnacek = (s) => String(s).replace(/\d+/g, '').length;
  const MEZ = ' ';

  // POŘADÍ PRAVIDEL JE PODSTATNÉ. Oddělovače se vážou jako první: kdyby šla
  // dřív spojka, snědla by mezeru za pomlčkou („— a jestli“) a pomlčka by
  // pak neměla, čeho se chytit, takže by uvízla na začátku řádku.
  function typografieText(s) {
    let t = String(s);

    // 1) Pomlčka a šipka se vážou jen DOZADU. Česká sazba je nechává na konci
    //    řádku, ne na začátku dalšího; u řetězu „a → b → c“ by vazba na obě
    //    strany udělala jeden nezlomitelný provaz.
    t = t.replace(/(\S+)[ \t]+([–—→⇒»])(?=[ \t])/g, (m, pred, odd) => pred + MEZ + odd);

    // 2) Osamocené lomítko a spol. — „Jméno / Název“ je jeden údaj a lámat ho
    //    v půlce nedává smysl. Váže se na obě strany, pokud je kus krátký.
    t = t.replace(/(\S+)[ \t]+([\/|·×]+)[ \t]+(?=(\S*))/g, (m, pred, odd, po) =>
      (delkaBezZnacek(pred) + delkaBezZnacek(po) + odd.length + 2 <= MAX_KUS
        ? pred + MEZ + odd + MEZ : pred + MEZ + odd + ' '));

    // 3) Jednopísmenná předložka/spojka → pevná mezera k následujícímu slovu.
    t = t.replace(new RegExp('(^|[\\s' + MEZ + '(„“"\'\\u2013\\u2014])([' + JEDNOPISMENNA + '])[ \\t]+', 'g'),
      (m, pred, pis) => pred + pis + MEZ);

    // 4) …a k předchozímu — pak takové písmeno nemůže řádek ani začít, ani
    //    skončit. Váže se celý kus „slovo a slovo“; kdyby byl delší, než řádek
    //    unese, zůstane jen vazba dopředu (české pravidlo).
    //
    //    Následující slovo se čte NAHLÍŽENÍM, ne zabráním: zabrané slovo by
    //    nemohlo sloužit jako předchozí slovo hned další dvojici a věta
    //    „zakázky k fakturaci a faktury“ by druhé „a“ nechala bez vazby.
    //
    //    Otevírací závorka smí být na písmenu nalepená — „(v části Ceníky)“ se
    //    jinak vázat nedalo a začínalo řádek.
    t = t.replace(new RegExp('(\\S+)[ \\t]+([(„“"\']*)([' + JEDNOPISMENNA + '])' + MEZ + '(?=(\\S*))', 'g'),
      (m, pred, otv, pis, po) => {
        if (delkaBezZnacek(pred) + delkaBezZnacek(po) + 3 > MAX_KUS) return m;
        // Spojovník uvnitř slova je pro sazbu místo ke zlomu a pevná mezera za
        // ním ho nepřebije: „e-mailů a plnou moc“ se lámalo přesně tam, kde
        // nemělo. V tomhle jednom kusu ho vyměníme za nezlomitelný spojovník —
        // vypadá stejně, jen se u něj řádek neláme.
        const pevne = pred.replace(/(\p{L})-(\p{L})/gu, '$1\u2011$2');
        return pevne + MEZ + otv + pis + MEZ;
      });

    // 5) Číslo a jeho jednotka — „17 znaků“, „2 hodiny“, „31 kroků“.
    t = t.replace(/(\d)[ \t]+(\p{L}{1,7})(?=[\s.,;:)!?]|$)/gu, (m, c, slovo) => c + MEZ + slovo);

    // 6) Skupiny číslic v telefonu — „+420 604 964 867“.
    t = t.replace(/(\d)[ \t]+(?=\d)/g, (m, c) => c + MEZ);

    // 7) Vdova: poslední řádek odstavce, na kterém zůstalo jediné krátké
    //    slovo („…okno se zavře.“ / „zavře.“). Svážou se poslední dvě slova,
    //    takže poslední řádek má vždycky aspoň dvě — buď se přesunou obě,
    //    nebo zůstanou obě nahoře. Spojovník v předposledním slově se mění za
    //    nezlomitelný ze stejného důvodu jako v pravidle 4: „e-mail, SMS.“ se
    //    jinak zlomí za pomlčkou a vdova zůstane.
    t = t.replace(/(\S+)[ \t]+(\S+\s*)$/, (m, pred, posl) => {
      if (delkaBezZnacek(pred) + delkaBezZnacek(posl) + 1 > MAX_KUS) return m;
      return pred.replace(/(\p{L})-(\p{L})/gu, '$1\u2011$2') + MEZ + posl;
    });

    return t;
  }

  // Značky se na dobu sazby schovají za zástupku, místo aby se text rozsekal
  // na kusy mezi nimi. Věta „<strong>DUZP</strong> a <strong>splatnost</strong>“
  // je pak pro pravidla jeden souvislý text; rozsekaná by u toho „a“ neviděla,
  // co je před ním, a nechala by ho začínat řádek. Zástupka zároveň chrání
  // obsah atributů (href, title), kam pevná mezera nepatří.
  function typografie(html) {
    if (!html) return '';
    const znacky = [];
    const schovano = String(html).replace(/<[^>]*>/g, (t) => {
      znacky.push(t);
      return '\u0001' + (znacky.length - 1) + '\u0002';
    });
    return typografieText(schovano)
      .replace(/\u0001(\d+)\u0002/g, (m, i) => znacky[+i]);
  }

  // Text kroku: každý číslovaný bod dostane vlastní blok s visícím odsazením,
  // aby druhý řádek začínal pod textem, ne pod číslem. Dřív se body lámaly
  // doprostřed a nebylo poznat, kde jeden končí a druhý začíná.
  function textKroku(html) {
    if (!html) return '';
    const casti = String(html).split(/<br\s*\/?>/i);
    let out = '';
    let predchoziBod = false;
    casti.forEach((c, i) => {
      const bod = /^\s*[①-⑳]/.test(c);
      // <br> se vynechá tam, kde ho blok bodu udělá sám — jinak vznikne
      // prázdný řádek navíc.
      if (i > 0 && !bod && !predchoziBod) out += '<br>';
      // Sazba běží po ODSTAVCÍCH, ne na celém textu najednou: pravidlo proti
      // vdově se ptá na konec odstavce, a to je právě tady. Vázat přes <br>
      // by navíc nemělo smysl — tam se láme tak jako tak.
      const sazba = typografie(bod ? c.trim() : c);
      out += bod ? `<span class="bod">${sazba}</span>` : sazba;
      predchoziBod = bod;
    });
    return out.replace(KROUZKY, cisloZnacka);
  }

  // Štítek u rámečku. Text se escapuje (může přijít z vlastního obsahu
  // v editoru), takže se do něj nedá propašovat značka — číslo se doplní až
  // po escapování.
  const stitekHtml = (s) => typografie(escHtml(s)).replace(KROUZKY, cisloZnacka);

  // Kontakt uživatele — vyplní se v okně doplňku, ukládá se lokálně.
  // Slouží jen k tomu, aby hotline věděla, komu zavolat zpět.
  function contactKnown() {
    const c = state.contact || {};
    return !!(c.tel || c.email);
  }
  function contactLine2() {
    const c = state.contact || {};
    const ic = c.icZakaznik ? 'IC ' + c.icZakaznik : '';
    return [ic, c.jmeno, c.tel, c.email].filter(Boolean).join(' · ');
  }

  const hasIcNumber = () => !!((state.contact || {}).icZakaznik);

  // Obchodní specialisté z obsahu — pro výběr v úvodním dotazu i pro pomoc.
  const specialisteSeznam = () => (Array.isArray(SUP.specialiste) ? SUP.specialiste
    : (SUP.specialista ? [SUP.specialista] : []))
    .filter((s) => s && s.nazev);

  // Úvodní dotaz je hotový, až když je vybraný i specialista ("—" = neví).
  // Když obsah žádné specialisty nevede, výběr se přeskakuje.
  const specialistaZvolen = () => !specialisteSeznam().length || !!((state.contact || {}).specialista);

  // Vypínač videí pro správce (FORMAT.md §1: "videa": false) — skryje tlačítko
  // „Video" u všech kroků i uvítací video. Rozdává se importem obsahu.
  const videaZapnuta = () => DATA.videa !== false;

  // Stručné texty pro zkušené (zapíná se v okně doplňku). Kdo v IC Office
  // pracuje denně, nepotřebuje návod — stačí mu, KAM kliknout. Karta pak místo
  // textu kroku ukáže jen jeho tučná slova. Nový text se nepíše: tučně jsou
  // v obsahu právě názvy tlačítek a polí. Drží se v local jako režim správce.
  const STRUCNE_KEY = 'icop2:strucne';
  let STRUCNE = false;
  try {
    chrome.storage.local.get([STRUCNE_KEY], (r) => {
      STRUCNE = !!(r && r[STRUCNE_KEY]);
      if (STRUCNE && engine.step) { buildCard(); positionCard(); }
    });
  } catch (e) { /* mimo rozšíření */ }

  // Tučná slova textu, nejvýš tři. Delší výčet už není „stručně“ — pak vrací
  // prázdný řetězec a karta sáhne po nadpisu kroku. Za slovo se počítá jen
  // úsek s písmenem nebo číslicí, takže „+ Přidat klienta“ jsou dvě slova.
  function strucnyText(html) {
    const casti = [];
    for (const m of String(html || '').matchAll(/<strong>([\s\S]*?)<\/strong>/gi)) {
      const t = bezHtml(m[1]);
      if (t && !casti.includes(t)) casti.push(t);
    }
    const slov = casti.join(' ').split(/\s+/).filter((w) => /[\p{L}\p{N}]/u.test(w)).length;
    if (!slov || slov > 3) return '';
    // Bez escapování — obsah je HTML stejně jako v textKroku(), jen bez vnořených značek.
    return casti.map((t) => `<strong>${t}</strong>`).join(' · ');
  }

  // Uvítací video (FORMAT.md §1). Jen ODKAZ — video se do doplňku nebalí,
  // aby balíček nebobtnal; soubor leží na serveru (typicky /videos/… na
  // doméně IC Office) a přehraje se streamem.
  const uvitaciVideoUrl = () => {
    if (!videaZapnuta()) return '';
    const u = DATA.uvitani && typeof DATA.uvitani.video === 'string' ? DATA.uvitani.video.trim() : '';
    return u;
  };

  // Odhad času na projití celého scénáře — ukazuje se v rozcestníku.
  // `minuty` dodává obsah (FORMAT.md §2); bez nich se odhad odvodí z počtu kroků.
  function odhadMinut(sc) {
    const m = Number(sc && sc.minuty);
    if (Number.isFinite(m) && m >= 1 && m <= 30) return Math.round(m);
    const n = sc && sc.steps ? sc.steps.length : 0;
    return Math.max(1, Math.min(10, Math.round(n / 10)));
  }

  // Telefon, e-mail a název firmy si průvodce doplní z IC Office sám —
  // uživatel je nemusí nikam vypisovat. Je to dotaz na STEJNÝ web, na kterém
  // průvodce běží (Nastavení → Firma), přihlášenou session uživatele; žádná
  // data neopouštějí IC Office. Vyplňují se jen prázdná pole, ručně zadané
  // hodnoty se nepřepisují. Když se to nepovede, prostě se nedoplní nic.
  const SETTINGS_URL = '/settings/company';
  let udajeDotazeny = false;

  function doplnUdajeZNastaveni() {
    if (udajeDotazeny) return;
    if (verejnaStranka()) return;   // bez přihlášení skončí dotaz na úvodní stránce
    const c = state.contact || {};
    if (c.jmeno && c.tel && c.email) return;          // už máme vše potřebné
    const url = window.__icop2TestSettingsUrl || SETTINGS_URL;
    if (!window.__icop2TestSettingsUrl && !/(^|\.)ic-office\.eu$/.test(location.hostname)) return;
    udajeDotazeny = true;
    Promise.resolve()
      .then(() => fetch(url, { credentials: 'same-origin' }))
      .then((r) => (r && r.ok ? r.text() : null))
      .then((html) => {
        if (!html) return;
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const val = (sel) => {
          const el = doc.querySelector(sel);
          return el ? (el.getAttribute('value') || '').trim().slice(0, 120) : '';
        };
        const nove = {
          jmeno: val("input[name='nazev']"),
          tel: val("input[name='telefon']"),
          email: val("input[name='email']")
        };
        const merged = Object.assign({}, state.contact);
        let zmena = false;
        for (const k of ['jmeno', 'tel', 'email']) {
          if (!merged[k] && nove[k]) { merged[k] = nove[k]; zmena = true; }
        }
        if (zmena) { state.contact = merged; saveState(); }
      })
      .catch(() => { /* nepřihlášen, jiná struktura stránky — nevadí */ });
  }

  // Úvodní dotaz: zákaznické číslo + volba obchodního specialisty. Se
  // zákaznickým číslem si hotline zbytek (kontakt, firmu) dohledá sama;
  // specialista se pak nabízí v kartě „Potřebuji pomoc" na prvním místě.
  // Telefon a e-mail jsou volitelné a doplní se v okně doplňku.
  function onboardingHtml() {
    const c = state.contact || {};
    const katalog = SUP.katalogUrl || '';
    const spec = specialisteSeznam();
    return `
      <div class="wsub">Než začneme — vyplňte prosím své <strong>zákaznické číslo Inter Cars</strong>${
        spec.length ? ' a vyberte svého <strong>obchodního specialistu</strong>' : ''}.</div>
      <div class="wform">
        <label for="ob-ic">Vaše zákaznické číslo Inter Cars</label>
        <input id="ob-ic" type="text" value="${escHtml(c.icZakaznik || '')}" placeholder="např. C63442"
               autocomplete="off" spellcheck="false">
        <div class="hint">Najdete ho v <strong>katalogu Inter Cars</strong> vpravo nahoře u svého jména —
          je to kód začínající písmenem <strong>C</strong> (např. <strong>C63442</strong>).
          ${katalog ? `<br><a href="${katalog}" target="_blank" rel="noopener">Otevřít katalog Inter Cars${ik('externi-odkaz')}</a>` : ''}</div>
        ${spec.length ? `
        <label>Váš obchodní specialista IC Office</label>
        <div class="spvyber">
          ${spec.map((s) => `<button type="button" class="spvol${c.specialista === s.nazev ? ' on' : ''}"
            data-spec="${escHtml(s.nazev)}">${escHtml(s.nazev)}</button>`).join('')}
          <button type="button" class="spvol${c.specialista === '—' ? ' on' : ''}" data-spec="—">Zatím nevím</button>
        </div>
        <div class="hint">Kontakt na vybraného specialistu pak najdete přímo v průvodci pod tlačítkem <strong>Pomoc</strong>.</div>` : ''}
        <div class="wact">
          <button type="button" class="b main" data-a="contactSave" disabled>Pokračovat →</button>
        </div>
      </div>`;
  }

  // Uvítací video — přehraje se (se zvukem) hned po dokončení úvodního
  // dotazu, dřív než uživatel spustí první scénář. Klik na „Pokračovat"
  // v dotazu je gesto uživatele, takže prohlížeč zvuk pustí.
  function uvitaniHtml() {
    return `
      <div class="wsub">Krátké uvítací video — scénáře na vás počkají.</div>
      <div class="wvideo">
        <video controls autoplay src="${escHtml(uvitaciVideoUrl())}"></video>
        <div class="vid-err hidden">Video se nepodařilo načíst — pokračujte rovnou na scénáře.</div>
      </div>
      <div class="wact uvitakce">
        <button type="button" class="b main" data-a="uvitanidal">Pokračovat na scénáře →</button>
      </div>`;
  }

  function stepCode() {
    if (!engine.scenario || !engine.step) return '';
    return (engine.scenario.code || '??') + '-' + String(engine.step.id).toUpperCase();
  }

  // Podklad pro hotlinku. Adresa BEZ parametrů dotazu — ty nesou id klienta
  // a zakázky a do hlášení nepatří (viz PRIVACY.md).
  function diagText() {
    const sc = engine.scenario, st = engine.step;
    return [
      'IC Office Tutoriál — žádost o pomoc',
      'Kód kroku: ' + stepCode(),
      'Scénář: ' + (sc ? sc.title : '—'),
      'Krok: ' + (st ? (st.title || st.id) : '—') + ' (' + (engine.idx + 1) + ' z ' + engine.steps.length + ')',
      'Stránka: ' + currentPath().split('?')[0],
      'Verze tutoriálu: ' + (DATA.version || ''),
      'Kontakt na mě: ' + (contactKnown() ? contactLine2() : '(nevyplněn v nastavení doplňku)'),
      'Prohlížeč: ' + navigator.userAgent
    ].join('\n');
  }

  function contactLine(o) {
    const bits = [];
    if (o.tel) bits.push(`<a href="tel:${o.tel.replace(/\s/g, '')}">${o.tel}</a>`);
    if (o.email) bits.push(`<a href="mailto:${o.email}">${o.email}</a>`);
    return bits.join(' · ');
  }

  function helpPaneHtml() {
    const h = SUP.hotline || {};
    // Specialistů může být víc (zástup, dovolená) — bere se pole i jediný
    // objekt, ať starší tvar obsahu nepřestane fungovat.
    const spec = (Array.isArray(SUP.specialiste) ? SUP.specialiste
      : (SUP.specialista ? [SUP.specialista] : []))
      .filter((s) => s && (s.nazev || s.tel || s.email));
    // Specialista vybraný v úvodním dotazu jde na první místo — je to „jeho"
    // člověk. Ostatní zůstávají jako zástup pro dovolené a nemoci.
    const muj = spec.find((s) => s.nazev && s.nazev === (state.contact || {}).specialista) || null;
    const ostatni = muj ? spec.filter((s) => s !== muj) : spec;
    return `<div class="helpp">
      <span class="bigcode">${stepCode()}</span>
      Nadiktujte tento <strong>kód kroku</strong> — Hotlinka i Váš specialista podle něj přesně poznají,
      u jakého kroku jste a potřebujete poradit.
      ${h.tel || h.email ? `<div class="row"><strong>${h.nazev || 'Hotline'}</strong>${h.hodiny ? ' — ' + h.hodiny : ''}<br>${contactLine(h)}</div>` : ''}
      ${muj ? `<div class="row"><strong>Váš obchodní specialista</strong><br>${escHtml(muj.nazev)}${
        muj.tel || muj.email ? ' — ' + contactLine(muj) : ''}</div>` : ''}
      ${ostatni.length ? `<div class="row"><strong>${muj ? 'Zástup' : (ostatni.length > 1 ? 'IC Office specialisté' : 'Váš IC Office specialista')}</strong>${
        ostatni.map((s) => `<br>${escHtml(s.nazev || '')}${s.nazev ? ' — ' : ''}${contactLine(s)}`).join('')}</div>` : ''}
      <div class="acts">
        <button type="button" class="prim" data-a="sosask">${ik('podpora')}Potřebuji pomoc</button>
        <button type="button" data-a="copydiag">${ik('kopirovat')}Zkopírovat údaje</button>
        <button type="button" data-a="tisk">${ik('tisk')}Vytisknout postup</button>
        <button type="button" data-a="hlasit" title="Když průvodce ukazuje na místo, které na stránce není">${ik('varovani')}Průvodce nefunguje</button>
      </div>
      <div class="tip">${REMOTE_TIP}</div>
      <div class="tip" data-copied></div>
    </div>`;
  }

  // Mezikrok „opravdu?“ — aby se požadavek na hotlinku neodeslal omylem.
  function sosAskHtml() {
    const auto = endpointReady();
    return `<div class="helpp sos">
      <span class="bigcode">${stepCode()}</span>
      <strong>Chcete pomoc od týmu IC Office?</strong>
      <div class="row">Nic nemusíte psát. Odejde kód kroku, kde jste, a <strong>váš kontakt</strong>,
        aby se vám měl kdo ozvat. Údaje o vašich klientech se neodesílají.</div>
      ${contactKnown() ? `<div class="row">Kontakt: <strong>${escHtml(contactLine2())}</strong>
        <br><span class="tip">Změníte ho v okně doplňku (ikona vedle adresního řádku).</span></div>`
        : `<div class="row">${ik('varovani')} Nemáte vyplněný kontakt. Doplňte ho v okně doplňku (ikona vedle
        adresního řádku) — jinak hotline nebude mít komu zavolat.</div>`}
      <div class="acts">
        <button type="button" class="prim" data-a="sosyes">Ano, potřebuji pomoc</button>
        <button type="button" data-a="sosno">Ne, teď ne</button>
      </div>
      <div class="tip">${auto ? `Žádost odejde rovnou na hotline IC Office.
        ${prenosCizi() ? 'Přenos zajišťuje <strong>Web3Forms</strong> — služba třetí strany, která z požadavku udělá e-mail. Vaše údaje tedy projdou i přes ni.' : ''}`
        : 'Automatické odesílání zatím není zapnuté — otevře se hotový e-mail, který stačí odeslat.'}</div>
      <div class="tip" data-sosresult>${engine.sosVysledek || ''}</div>
    </div>`;
  }

  function copyDiag() {
    const text = diagText();
    const done = (ok) => {
      const el = card.querySelector('[data-copied]');
      if (el) el.innerHTML = ok
        ? '<span class="ok">' + ik('hotovo') + 'Zkopírováno — vložte do e-mailu nebo zprávy (Ctrl+V).</span>'
        : 'Kopírování se nepovedlo — kód kroku je vidět výše, nadiktujte ho.';
    };
    // Záloha pro starší prohlížeče a případy, kdy clipboard API odmítne.
    // Textarea musí být v BĚŽNÉM DOM — výběr textu přes hranici Shadow DOM
    // execCommand spolehlivě nezvládá.
    const fallback = () => {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.cssText = 'position:fixed;top:-1000px;left:0;opacity:0';
      document.body.appendChild(ta);
      let ok = false;
      try {
        ta.select();
        ta.setSelectionRange(0, ta.value.length);
        ok = document.execCommand('copy');
      } catch (e) { /* */ }
      ta.remove();
      done(ok);
    };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => done(true), fallback);
      } else fallback();
    } catch (e) { fallback(); }
  }

  // mailto = otevře poštovního klienta s předvyplněným textem. Odeslání je
  // v tomto případě vždy na uživateli (viz PRIVACY.md).
  function mailDiag() {
    const h = SUP.hotline || {};
    if (!h.email) return false;
    const url = 'mailto:' + h.email
      + '?subject=' + encodeURIComponent('IC Office Tutoriál — pomoc ' + stepCode())
      + '&body=' + encodeURIComponent(diagText());
    const a = document.createElement('a');
    a.href = url; a.target = '_blank'; a.rel = 'noopener';
    root.appendChild(a); a.click(); a.remove();
    return true;
  }

  // Odeslání žádosti o pomoc. Když je nastavený endpoint IC Office, pošle se
  // rovnou tam (přes service worker, aby oprávnění bylo v manifestu). Jinak
  // se otevře předvyplněný e-mail — doplněk sám po síti nekomunikuje.
  function sendSupport() {
    // Výsledek si engine PAMATUJE. Dřív se psal přímo do karty a při jejím
    // překreslení (odemknutá brána, fáze then, tik hlídače) zmizel — uživatel
    // pak nevěděl, jestli žádost odešla, a poslal ji znovu.
    const say = (html) => {
      engine.sosVysledek = html;
      const el = card.querySelector('[data-sosresult]');
      if (el) el.innerHTML = html;
    };
    const c = state.contact || {};
    // Ploché pole schválně — přeposílací služby vkládají do e-mailu jen
    // hodnoty nejvyšší úrovně; vnořený objekt by dorazil jako [object Object].
    // Názvy subject / from_name / email / message jsou to, čemu tyto služby
    // rozumí bez konfigurace; české názvy jsou navíc pro endpoint IC Office.
    const payload = Object.assign({
      subject: 'IC Office Tutoriál — žádost o pomoc ' + stepCode(),
      from_name: c.jmeno || ('Zákazník ' + (c.icZakaznik || '')),
      email: c.email || '',
      message: diagText(),
      prijemce: SUP.prijemce || (SUP.hotline || {}).email || '',
      kodKroku: stepCode(),
      scenar: engine.scenario ? engine.scenario.title : '',
      krok: engine.step ? (engine.step.title || engine.step.id) : '',
      poradi: (engine.idx + 1) + '/' + engine.steps.length,
      stranka: currentPath().split('?')[0],
      verze: DATA.version || '',
      zakaznickeCislo: c.icZakaznik || '',
      telefon: c.tel || ''
      // `kontaktniEmail` tu bývalo taky — byla to jen kopie pole `email`.
      // Posílat tentýž osobní údaj dvakrát nemá důvod.
    }, SUP.endpointExtra || {});

    // Bez adresy, která umí e-mail odeslat, průvodce NIC neodešle. V takovém
    // případě nesmí tvrdit „budete kontaktováni“ — otevře uživateli hotovou
    // zprávu a řekne mu na rovinu, že ji musí odeslat.
    if (!endpointReady()) {
      say(mailDiag()
        ? 'Otevřel se e-mail s hotovou žádostí. <strong>Odešlete ho prosím</strong> — teprve pak se o vás hotline dozví.'
        : 'Nepodařilo se otevřít e-mail. Zavolejte prosím na hotline a nadiktujte kód výše.');
      return;
    }
    say('Odesílám…');
    try {
      chrome.runtime.sendMessage({ ns: 'icop2', action: 'sos', endpoint: SUP.endpoint, payload }, (res) => {
        if (chrome.runtime.lastError || !res || !res.ok) {
          say('Odeslání se nepovedlo. ' + (mailDiag()
            ? 'Otevřel se místo toho e-mail — <strong>odešlete ho prosím</strong>.'
            : 'Zavolejte prosím na hotline a nadiktujte kód výše.'));
        } else {
          say('<span class="ok">' + ik('hotovo') + 'Žádost odeslána.</span> Tým IC Office se vám ozve v nejbližší době '
            + 'na uvedený kontakt. Můžete pokračovat v práci.');
        }
      });
    } catch (e) {
      say('Odeslání se nepovedlo. ' + (mailDiag() ? 'Otevřel se e-mail — <strong>odešlete ho prosím</strong>.' : ''));
    }
  }

  // Hlášení rozbitých selektorů autorovi průvodce. Health-check dosud nálezy
  // ukazoval jen v popupu toho uživatele — autor se o změně IC Office nedozvěděl
  // nikdy. Tohle tu smyčku uzavírá stejnou cestou jako žádost o pomoc.
  function hlasitRozbite() {
    const say = (html) => {
      const el = card.querySelector('[data-copied]');
      if (el) el.innerHTML = html;
    };
    try {
      chrome.storage.local.get([HEALTH_KEY], (r) => {
        const items = (r && r[HEALTH_KEY] && r[HEALTH_KEY].items) || {};
        const nalezy = Object.entries(items)
          .filter(([, v]) => v.confirmed || (v.misses || 0) >= 2)
          .map(([k, v]) => `${k} — ${v.scenario} / ${v.step}${v.label ? ' (' + v.label + ')' : ''}`
            + ` · ${v.path} · ${v.misses}×${v.confirmed ? ' potvrzeno' : ''}`);
        const c = state.contact || {};
        const zprava = ['Hlášení: průvodce ukazuje na místo, které na stránce není', '',
          'Aktuální krok: ' + stepCode() + ' (' + (engine.step ? engine.step.title : '—') + ')',
          'Stránka: ' + currentPath().split('?')[0],
          'Verze tutoriálu: ' + (DATA.version || ''),
          'Zákazník: ' + (c.icZakaznik || '—') + ' · ' + (c.tel || '') + ' ' + (c.email || ''),
          '', nalezy.length ? 'Nenalezené prvky (' + nalezy.length + '):' : 'Automatická kontrola zatím nic nezachytila.',
          ...nalezy].join('\n');
        const payload = Object.assign({
          subject: 'IC Office Tutoriál — hlášení chyby ' + stepCode(),
          from_name: c.jmeno || ('Zákazník ' + (c.icZakaznik || '')),
          email: c.email || '',
          message: zprava,
          typ: 'chyba-pruvodce',
          kodKroku: stepCode(),
          stranka: currentPath().split('?')[0],
          verze: DATA.version || '',
          zakaznickeCislo: c.icZakaznik || ''
        }, SUP.endpointExtra || {});
        if (!endpointReady()) { say('Odesílání hlášení není nastavené. Napište prosím na hotline a uveďte kód ' + stepCode() + '.'); return; }
        say('Odesílám hlášení…');
        chrome.runtime.sendMessage({ ns: 'icop2', action: 'sos', endpoint: SUP.endpoint, payload }, (res) => {
          say(res && res.ok
            ? '<span class="ok">' + ik('hotovo') + 'Děkujeme, hlášení odesláno.</span> Průvodce opravíme.'
            : 'Hlášení se nepodařilo odeslat. Zkuste to prosím později.');
        });
      });
    } catch (e) { say('Hlášení se nepodařilo odeslat.'); }
  }

  // ---------------- karta ----------------
  function buildCard() {
    const step = engine.step;
    const n = engine.steps.length;
    // Rozepsaná úprava v režimu správce se nesmí ztratit kvůli překreslení
    // z ticku (odemknutá brána, chybějící cíl). Dokud má kurzor pole editoru,
    // karta se nepřestavuje — náhled si editor obnovuje sám.
    if (engine.editorOpen && root.activeElement && card.contains(root.activeElement)
        && root.activeElement.closest && root.activeElement.closest('.edit')) return;
    // Procenta jako poloha posuvníku: na prvním kroku 0 %, na posledním 100 %.
    // Dřív se počítal rovnou zlomek (krok / celkem), aby procento sedělo
    // s textem „Krok 3 z 31“. Jenže pak průvodce hlásil 3 % dřív, než uživatel
    // cokoli udělal. Zlomek je vedle napsaný slovy, procenta můžou říkat to
    // druhé — jak daleko je člověk na cestě.
    const pct = pctKroku(engine.idx, n);
    const gated = isGated(step);
    const showGateHint = gated && !engine.unlocked;

    // Pomocné odkazy do samostatného proužku, hlavní postup zůstává dole.
    // Stručně jen v běžném průvodci: prezentace mluví k publiku a správce
    // v editoru upravuje právě celý text. „Celý text“ platí pro jeden krok.
    const muzeStrucne = STRUCNE && !demoBezi() && !(SPRAVA && engine.editorOpen);
    const strucne = muzeStrucne && !engine.celyText;
    // Pořadí: vlastní `kratce` fáze (FORMAT.md §3) → tučná slova textu → štítek
    // druhé fáze → nadpis.
    const faze = (engine.stage === 2 && step.then) ? step.then : step;
    const titulek = strucne
      ? (faze.kratce || strucnyText(faze.text) || (faze !== step && faze.label ? `<strong>${faze.label}</strong>` : '') || typografie(step.title || ''))
      : typografie(step.title || '');

    let tools = '';
    tools += muzeStrucne ? `<button class="b mini" data-a="celytext">${strucne ? 'Celý text' : 'Stručně'}</button>` : '';
    tools += (step.help || step.manual) ? '<button class="b mini" data-a="more">' + ik('info') + 'Více</button>' : '';
    tools += (step.video && videaZapnuta()) ? '<button class="b mini" data-a="video">Video</button>' : '';
    tools += (SPRAVA && !cvBezi()) ? '<button class="b mini" data-a="edit" title="Režim správce — upravit tento krok">' + ik('upravit') + 'Upravit</button>' : '';
    tools += '<button class="b mini" data-a="help" title="Kód kroku a kontakt na hotlinku">' + ik('podpora') + 'Pomoc</button>';
    tools += `<button type="button" class="codeq" data-a="help" title="Kód kroku pro hotlinku — klikněte pro kontakty">${stepCode()}</button>`;

    let btns = '';
    btns += '<span class="sp"></span>';
    if (!step.noPrev && prevMatchingIdx() !== null) btns += '<button class="b ghost" data-a="prev">← Zpět</button>';
    if (step.skip) btns += `<button class="b ghost" data-a="skip">${typeof step.skip === 'string' ? step.skip : 'Přeskočit'}</button>`;
    const nextLabel = step.next === false ? null : (step.next || 'Další →');
    if (nextLabel) {
      btns += `<button class="b main" data-a="next" ${showGateHint ? 'disabled' : ''}>${nextLabel}</button>`;
    } else if (engine.fallbackNext) {
      btns += '<button class="b ghost" data-a="next">Pokračovat i tak →</button>';
    }

    // překreslení uprostřed kroku (odemknutí gate, fáze then) nesmí zavřít
    // rozbalenou nápovědu, zastavit přehrávané video ani sebrat kurzor tomu,
    // kdo kartu ovládá klávesnicí — proto si zapamatujeme, na čem stál
    const oldFocus = root.activeElement && card.contains(root.activeElement)
      ? (root.activeElement.dataset.a || null) : null;
    const oldMore = card.querySelector('.more');
    const moreOpen = !!(oldMore && !oldMore.classList.contains('hidden'));
    const oldFold = card.querySelector('.fold.jump');
    const foldOpen = !!(oldFold && oldFold.open);
    const oldVideo = card.querySelector('.vid video');

    card.dataset.color = step.color === 'yellow' ? 'yellow' : 'red';
    card.classList.toggle('center', step.kind === 'info');
    // Volitelná šířka karty z obsahu (FORMAT.md §3, `sirka`) — upravuje se
    // i interaktivně v režimu správce.
    const sirka = Number(step.sirka);
    card.style.width = (Number.isFinite(sirka) && sirka >= 320 && sirka <= 640) ? Math.round(sirka) + 'px' : '';
    // Ve cvičení má uživatel jen zadání — instrukce ani vysvícení nedostane,
    // dokud si o nápovědu neřekne.
    if (cvBezi()) {
      card.classList.add('center');
      card.innerHTML = cvKartaHtml();
      card.classList.remove('hidden');
      if (oldFocus) {
        const znovu = card.querySelector(`[data-a="${oldFocus}"]:not([disabled])`);
        if (znovu) { try { znovu.focus({ preventScroll: true }); } catch (e) { znovu.focus(); } }
      }
      card.style.maxHeight = '';
      engine._naturalH = card.offsetHeight || 220;
      return;
    }
    card.innerHTML = `
      <div class="head"><div class="scen">${engine.scenario.title}</div>
        <button class="x" data-a="close" title="Skrýt průvodce" aria-label="Skrýt průvodce">${ik('zavrit')}</button></div>
      <div class="pmeta">
        <span class="pstep">Krok ${engine.idx + 1} z ${n}</span>
        <span class="ppct">${pct} %</span>
      </div>
      <div class="track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}"
           aria-label="Průběh scénáře: krok ${engine.idx + 1} z ${n}"><div class="bar"
           style="width:${pct}%${pct === 0 ? ';min-width:0' : ''}"></div></div>
      <h3 id="icop2-step-title"${strucne ? ' class="strucne"' : ''}>${titulek}</h3>
      ${strucne ? '' : `<div class="txt">${textKroku(step.text)}</div>`}
      ${(step.then && !strucne) ? `<div class="then-txt ${engine.stage === 2 ? '' : 'hidden'}">${textKroku(step.then.text)}</div>` : ''}
      ${engine.targetMissing ? `<div class="warn">${ik('varovani')} Místo, na které průvodce ukazuje, teď na stránce <strong>není</strong> —
        nejspíš se zavřelo okno, se kterým tento krok počítá.
        ${prevMatchingIdx() !== null ? '<br><button type="button" data-a="prev">← Zpět o krok a otevřít znovu</button>' : ''}</div>` : ''}
      ${engine.jumpFrom ? `<details class="fold jump"><summary>Jiná část postupu, než kde jste skončili</summary>
        <div class="foldc">Uložený krok je „<strong>${engine.jumpFrom.title}</strong>“ — zatím se nezměnil.
        <br><button type="button" data-a="backjump">← Zpět na uložený krok</button></div></details>` : ''}
      ${showGateHint ? `<div class="gate">${ik('zamek')}<span>${typografie(step.gateHint || 'Vyplňte označená pole — potom lze pokračovat.')}</span></div>` : ''}
      ${engine.helpOpen === 'sos' ? typografie(sosAskHtml()) : (engine.helpOpen ? typografie(helpPaneHtml()) : '')}
      ${(step.help || step.manual) ? `<div class="more hidden">${typografie(step.help || '')}${manualHtml(step)}</div>` : ''}
      ${(step.video && videaZapnuta()) ? '<div class="vid hidden"></div>' : ''}
      ${(SPRAVA && engine.editorOpen) ? editorHtml() : ''}
      ${demoBezi() ? demoBarHtml() : ''}
      <div class="tools">${tools}</div>
      <div class="btns">${btns}</div>`;
    if (moreOpen) {
      const m = card.querySelector('.more');
      if (m) m.classList.remove('hidden');
    }
    if (foldOpen) {
      const f = card.querySelector('.fold.jump');
      if (f) f.open = true;
    }
    if (oldVideo && step.video && videaZapnuta()) {
      const v = card.querySelector('.vid');
      if (v) {
        v.appendChild(oldVideo);
        v.classList.remove('hidden');
        if (oldVideo.play) oldVideo.play().catch(() => {});
      }
    }
    card.classList.remove('hidden');
    if (oldFocus) {
      const znovu = card.querySelector(`[data-a="${oldFocus}"]:not([disabled])`);
      if (znovu) { try { znovu.focus({ preventScroll: true }); } catch (e) { znovu.focus(); } }
    }
    // Přirozená výška karty — podklad pro rozhodnutí, jestli se vejde vedle
    // vysvícených prvků, nebo ji bude potřeba zmenšit (viz positionCard).
    // Měřit AŽ po odkrytí — skrytá karta má offsetHeight 0.
    card.style.maxHeight = '';
    engine._naturalH = card.offsetHeight || 220;
  }

  function positionCard() {
    const step = engine.step;
    if (!step) return;
    // Karta cvičení se drží uprostřed nahoře — nemá se u čeho usadit, protože
    // nic nevysvěcuje, a poskakování by rušilo.
    if (cvBezi() && !engine.cv.napovedaTed) {
      beak.classList.add('hidden');
      card.style.maxHeight = '';
      card.style.left = Math.round(Math.max(8, (innerWidth - (card.offsetWidth || 440)) / 2)) + 'px';
      card.style.top = '90px';
      return;
    }
    // Kartu si uživatel přetáhl sám — automatika ji nepřemisťuje, jen ji drží
    // celou na obrazovce (změna velikosti okna, vyšší obsah karty).
    if (engine.rucniPoloha) {
      if (card.style.maxHeight) card.style.maxHeight = '';
      const p = kartaClamp(engine.rucniPoloha.x, engine.rucniPoloha.y);
      engine.rucniPoloha = p;
      card.style.left = p.x + 'px';
      card.style.top = p.y + 'px';
      beak.classList.add('hidden');
      return;
    }
    const vw = innerWidth, vh = innerHeight;
    const cw = card.offsetWidth || 380;
    // Přirozenou (nezmenšenou) výšku měříme JEN při stavbě karty. Kdybychom ji
    // zjišťovali tady, museli bychom před každým měřením zrušit maxHeight —
    // a reset + přepočet na každém snímku kartu rozhoupal a zatěžoval layout.
    let ch = engine._naturalH || card.offsetHeight || 220;
    let shrinkTo = 0;
    let anchor = null;
    if (step.kind !== 'info') {
      const el = (engine.stage === 2 && step.then) ? (findVisible(step.then.target) || findVisible(step.target)) : findVisible(step.target);
      if (el) anchor = pad(el.getBoundingClientRect(), 10);
    }
    if (!anchor) {
      card.style.left = Math.round((vw - cw) / 2) + 'px';
      card.style.top = Math.round(Math.max(16, (vh - ch) / 2.4)) + 'px';
      beak.classList.add('hidden');
      return;
    }
    const m = 14;
    // karta se nesmí překrývat s žádným vysvíceným prvkem (poučení z v1 —
    // nápověda zakrývala sousední pole)
    const holeRects = [...engine._holes.values()].map((h) => h.ringRect.getBoundingClientRect());
    // plocha překryvu — abychom uměli vybrat „nejmíň špatnou“ pozici, ne jen
    // ano/ne. Hranice se navíc počítá s rezervou 6 px.
    const overlapArea = (l, t, h) => holeRects.reduce((sum, r) => {
      const ow = Math.min(l + cw, r.right + 6) - Math.max(l, r.left - 6);
      const oh = Math.min(t + h, r.bottom + 6) - Math.max(t, r.top - 6);
      return sum + (ow > 0 && oh > 0 ? ow * oh : 0);
    }, 0);
    const overlapsHole = (l, t) => overlapArea(l, t, ch) > 0;
    // Štítky se rozmisťují dřív než karta (renderSpotlight) a o kartě nevědí.
    // Karta, která nezakryje žádný rámeček, tak mohla zakrýt všechny štítky
    // najednou — u voleb VIN reportu seděla přesně na čtyřech štítcích vlevo
    // od popisků. Poloha, která nezakryje ani štítek, má proto přednost; když
    // žádná není, platí dosavadní výběr jen podle rámečků.
    // Polohu štítků čteme ze style, ne z getBoundingClientRect (CSS přechod).
    const labelRects = [...labelsLayer.children]
      .filter((l) => l.style.left && l.style.display !== 'none')
      .map((l) => ({ left: parseFloat(l.style.left), top: parseFloat(l.style.top), w: l.offsetWidth, h: l.offsetHeight }));
    const overlapsLabel = (l, t) => labelRects.some((r) =>
      l < r.left + r.w && l + cw > r.left && t < r.top + r.h && t + ch > r.top);
    // horní/levá hrana má přednost — karta vyšší než okno nesmí utéct do záporu
    const clampL = (l) => Math.max(8, Math.min(l, vw - cw - 8));
    const clampT = (t) => Math.max(8, Math.min(t, vh - ch - 8));
    const candidates = [
      { side: 'r', fits: anchor.left + anchor.width + m + cw <= vw - 8, left: anchor.left + anchor.width + m, top: anchor.top + anchor.height / 2 - ch / 2 },
      { side: 'l', fits: anchor.left - m - cw >= 8, left: anchor.left - m - cw, top: anchor.top + anchor.height / 2 - ch / 2 },
      { side: 'b', fits: anchor.top + anchor.height + m + ch <= vh - 8, left: anchor.left + anchor.width / 2 - cw / 2, top: anchor.top + anchor.height + m },
      { side: 't', fits: anchor.top - m - ch >= 8, left: anchor.left + anchor.width / 2 - cw / 2, top: anchor.top - m - ch }
    ].filter((c) => c.fits).map((c) => ({ ...c, left: clampL(c.left), top: clampT(c.top) }));
    // Vedle prvku stojí štítky právě na té straně, kam jde karta: u úzkých polí
    // kalendáře vpravo od nich. Karta proto zkusí stejnou stranu ještě jednou,
    // odsunutou až za štítky, dřív než se smíří s tím, že je zakryje.
    const zaStitky = (c) => {
      let left = c.left;
      for (let i = 0; i < 4; i++) {
        const pod = labelRects.filter((r) => left < r.left + r.w && left + cw > r.left
          && c.top < r.top + r.h && c.top + ch > r.top);
        if (!pod.length) break;
        left = c.side === 'r'
          ? Math.max(...pod.map((r) => r.left + r.w)) + m
          : Math.min(...pod.map((r) => r.left)) - m - cw;
      }
      return (left !== c.left && left >= 8 && left + cw <= vw - 8) ? { ...c, left } : null;
    };
    const odsunute = candidates.filter((c) => c.side === 'r' || c.side === 'l').map(zaStitky).filter(Boolean);
    const volna = (c) => !overlapsHole(c.left, c.top) && !overlapsLabel(c.left, c.top);
    let pick = candidates.find(volna) || odsunute.find(volna)
      || candidates.find((c) => !overlapsHole(c.left, c.top));
    if (!pick && holeRects.length) {
      // Žádná strana se nevejde bez překryvu — typicky u pole přes celou šířku
      // stránky (Popis objednané opravy). Zakrýt pole, které má uživatel právě
      // vyplňovat, je to nejhorší, co průvodce může udělat, takže kartu
      // VMÁČKNEME nad nebo pod vysvícené prvky a v případě potřeby jí zmenšíme
      // výšku — text se uvnitř roluje.
      const maxBottom = Math.max(...holeRects.map((r) => r.bottom));
      const minTop = Math.min(...holeRects.map((r) => r.top));
      const below = vh - 8 - (maxBottom + 12);
      const above = (minTop - 12) - 8;
      const band = Math.max(below, above);
      if (band >= 170) {
        const useBelow = below >= above;
        ch = Math.min(ch, Math.round(band));
        shrinkTo = ch;
        pick = {
          side: useBelow ? 'b' : 't',
          left: clampL(anchor.left + anchor.width / 2 - cw / 2),
          top: useBelow ? Math.round(maxBottom + 12) : Math.max(8, Math.round(minTop - 12 - ch))
        };
      } else {
        // ani pruh nad/pod nestačí — aspoň vyber pozici s nejmenším překryvem
        pick = candidates
          .map((c) => ({ ...c, ov: overlapArea(c.left, c.top, ch) }))
          .sort((a, b) => a.ov - b.ov)[0];
      }
    }
    if (!pick) pick = candidates[0];
    // zapisujeme jen při skutečné změně — jinak by se každý snímek restartoval
    // CSS přechod a karta by se třásla
    const wantMaxH = shrinkTo ? shrinkTo + 'px' : '';
    if (card.style.maxHeight !== wantMaxH) card.style.maxHeight = wantMaxH;
    let left, top, side;
    if (pick) { side = pick.side; left = pick.left; top = pick.top; }
    else { side = null; left = (vw - cw) / 2; top = Math.max(16, (vh - ch) / 2.4); }
    left = Math.max(8, Math.min(left, vw - cw - 8));
    top = Math.max(8, Math.min(top, vh - ch - 8));
    card.style.left = Math.round(left) + 'px';
    card.style.top = Math.round(top) + 'px';
    // zobáček směrem k cíli
    if (side) {
      const cx = anchor.left + anchor.width / 2;
      const cy = anchor.top + anchor.height / 2;
      let bx, by;
      if (side === 'r') { bx = left - 7; by = Math.min(Math.max(cy - 7, top + 12), top + ch - 26); }
      else if (side === 'l') { bx = left + cw - 7; by = Math.min(Math.max(cy - 7, top + 12), top + ch - 26); }
      else if (side === 'b') { by = top - 7; bx = Math.min(Math.max(cx - 7, left + 12), left + cw - 26); }
      else { by = top + ch - 7; bx = Math.min(Math.max(cx - 7, left + 12), left + cw - 26); }
      // Pojistka: zobáček musí držet u hrany karty. Kdyby po klampování skončil
      // jinde (vysoká karta, malé okno), vypadá jako samostatný tvar viset
      // u rámečku — pak ho radši neukazovat vůbec.
      const uKarty = (side === 'r' || side === 'l')
        ? (by + 14 >= top && by <= top + ch)
        : (bx + 14 >= left && bx <= left + cw);
      if (uKarty) {
        beak.classList.remove('hidden');
        beak.style.left = Math.round(bx) + 'px';
        beak.style.top = Math.round(by) + 'px';
      } else {
        beak.classList.add('hidden');
      }
    } else {
      beak.classList.add('hidden');
    }
  }

  // ---------------- tažení karty ----------------
  // Kartu jde přesunout za hlavičku, když překáží ve výhledu. Poloha platí
  // jen pro AKTUÁLNÍ krok (další krok se zase umístí sám) a klampuje se tak,
  // aby karta zůstala CELÁ na obrazovce — uživatel si ji nemůže „zahodit"
  // někam, odkud by nešlo odkliknout další krok.
  function kartaClamp(x, y) {
    const cw = card.offsetWidth || 420;
    const ch = card.offsetHeight || 220;
    return {
      x: Math.round(Math.max(8, Math.min(x, innerWidth - cw - 8))),
      y: Math.round(Math.max(8, Math.min(y, innerHeight - ch - 8)))
    };
  }

  let cardDrag = null;
  card.addEventListener('pointerdown', (e) => {
    const head = e.target.closest && e.target.closest('.head');
    if (!head || e.target.closest('.x')) return;
    cardDrag = { sx: e.clientX, sy: e.clientY, ox: card.offsetLeft, oy: card.offsetTop, moved: false, id: e.pointerId };
    try { card.setPointerCapture(e.pointerId); } catch (err) { /* */ }
  });
  card.addEventListener('pointermove', (e) => {
    if (!cardDrag) return;
    const dx = e.clientX - cardDrag.sx, dy = e.clientY - cardDrag.sy;
    if (Math.abs(dx) + Math.abs(dy) > 4) cardDrag.moved = true;
    if (!cardDrag.moved) return;
    card.classList.add('tazena');
    const p = kartaClamp(cardDrag.ox + dx, cardDrag.oy + dy);
    engine.rucniPoloha = p;
    beak.classList.add('hidden');
    card.style.left = p.x + 'px';
    card.style.top = p.y + 'px';
  });
  const kartaPust = () => { cardDrag = null; card.classList.remove('tazena'); };
  card.addEventListener('pointerup', kartaPust);
  card.addEventListener('pointercancel', kartaPust);

  function isGated(step) {
    const a = step.advance || {};
    return !a.auto && !!(a.filled || a.filledAny);
  }

  function gateSatisfied(step) {
    const a = step.advance || {};
    const ma = (g) => groupHasValue(g, !!a.nenulove);
    if (a.filled) return a.filled.every(ma);
    if (a.filledAny) return a.filledAny.some(ma);
    return true;
  }

  function prevMatchingIdx() {
    for (let j = engine.idx - 1; j >= 0; j--) {
      if (stepMatchesUrl(engine.steps[j])) return j;
    }
    return null;
  }

  // ---------------- prezentace (ukázkový režim) ----------------
  // Průvodce si projde scénář sám: pomalu vypisuje ukázkové údaje a kliká.
  // Běží na ostrém IC Office, takže kroky s uložením SKUTEČNĚ uloží — proto
  // má každá vyplněná hodnota v názvu „UKÁZKA" a spuštění musí uživatel
  // potvrdit ve varovném okně.
  const demoBezi = () => !!(state.demo && state.demo.bezi);
  const demoPauzaPlatna = (s) => {
    const n = Math.round(Number(s));
    return Number.isFinite(n) ? Math.min(Math.max(n, DEMO_PAUZA_MIN), DEMO_PAUZA_MAX) : DEMO_PAUZA_DEF;
  };

  // Text, který je v kroku k přečtení — podklad pro délku pauzy i pro hlas.
  function demoTextKroku() {
    const s = engine.step;
    if (!s) return '';
    const then = (engine.stage === 2 && s.then) ? s.then.text : '';
    return bezHtml([s.title, s.text, then].filter(Boolean).join('. ')).replace(/\s+/g, ' ').trim();
  }

  // Pauza pro AKTUÁLNÍ krok. Dvouřádková poznámka nepotřebuje stejný čas jako
  // krok s výčtem na deset řádků, proto se základní pauza násobí poměrem délky
  // textu — v rozmezí půlnásobku až dvojnásobku, ať zůstane předvídatelná.
  function demoPauzaKroku() {
    const d = state.demo || {};
    const zaklad = demoPauzaPlatna(d.pauza) * 1000;
    if (d.dleTextu === false || !engine.step) return zaklad;
    const pomer = Math.min(Math.max(demoTextKroku().length / DEMO_PRUMER_ZNAKU, 0.5), 2);
    return Math.round(zaklad * pomer);
  }

  // ---- předčítání kroku ----
  // Přednost má NAHRÁVKA. Systémový hlas čte česky s chybami v přízvuku
  // i skloňování a u odborných slov (VIN, DUZP, SPZ) to je znát; namluvený
  // text zní o třídu líp. Nahrávky ale nemusí být hotové pro každý krok,
  // takže když chybí, přečte krok systémový hlas — prezentace kvůli tomu
  // nikdy neztichne.
  //
  // Soubory se jmenují podle KÓDU KROKU: src/assets/hlas/OS-S03.mp3.
  // Které existují, říká seznam.json (vyrábí `node build/hlas.mjs`), aby
  // průvodce nesahal na soubory, které tam nejsou.
  const HLAS_SLOZKA = 'src/assets/hlas/';
  let hlasSeznam = null;   // Set kódů s nahrávkou; null = ještě nenačteno

  function nactiHlasSeznam() {
    if (hlasSeznam) return;
    hlasSeznam = new Set();
    try {
      fetch(chrome.runtime.getURL(HLAS_SLOZKA + 'seznam.json'))
        .then((r) => (r.ok ? r.json() : []))
        .then((s) => { if (Array.isArray(s)) hlasSeznam = new Set(s); })
        .catch(() => { /* nahrávky nejsou — zůstane systémový hlas */ });
    } catch (e) { /* mimo rozšíření */ }
  }

  // Krok s druhou fází má i druhou nahrávku (`OS-S02-B`). Bez toho se po
  // rozbalení nabídky přehrála celá první nahrávka znovu — včetně věty, kterou
  // už uživatel slyšel. Když druhá fáze nahrávku nemá, radši se mlčí a nechá
  // se mluvit systémový hlas, než aby se opakovala ta první.
  function hlasKod() {
    const zaklad = stepCode();
    return (engine.stage === 2 && engine.step && engine.step.then) ? zaklad + '-B' : zaklad;
  }

  function demoMluv() {
    if (!(state.demo || {}).hlas) return;
    demoTicho();
    const kod = hlasKod();
    if (hlasSeznam && hlasSeznam.has(kod)) {
      try {
        const zvuk = new Audio(chrome.runtime.getURL(HLAS_SLOZKA + kod + '.mp3'));
        engine._demoZvuk = zvuk;
        // Když se nahrávka nepovede přehrát, nesmí krok zůstat němý.
        zvuk.addEventListener('error', () => { engine._demoZvuk = null; demoMluvSystem(); }, { once: true });
        zvuk.play().catch(() => { engine._demoZvuk = null; demoMluvSystem(); });
        return;
      } catch (e) { /* spadneme na systémový hlas */ }
    }
    demoMluvSystem();
  }

  // Záloha: hlas zabudovaný v prohlížeči. Nic se neodesílá a funguje offline,
  // ale česká výslovnost je jen přibližná.
  function demoMluvSystem() {
    const synth = window.speechSynthesis;
    if (!synth) return;
    const text = demoTextKroku();
    if (!text) return;
    try {
      synth.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'cs-CZ';
      const cesky = (synth.getVoices() || []).find((v) => /^cs/i.test(v.lang || ''));
      if (cesky) u.voice = cesky;
      u.rate = 0.95;
      synth.speak(u);
    } catch (e) { /* prohlížeč hlas nemá — prezentace běží dál potichu */ }
  }

  function demoTicho() {
    try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (e) { /* */ }
    const z = engine._demoZvuk;
    if (z) { try { z.pause(); z.currentTime = 0; } catch (e) { /* */ } engine._demoZvuk = null; }
  }

  // Podpis křížkem. Podpisové pole je canvas, na kterém knihovna poslouchá
  // ukazovací události — proto křížek „nakreslíme“ stejnými událostmi, jaké
  // vyvolá prst nebo myš. Přímý zápis do canvasu by knihovna neviděla a doklad
  // by zůstal nepodepsaný.
  function demoPodpisKrizek(sel) {
    const cv = findVisible(sel) || findEl(sel);
    if (!cv) return false;
    const r = cv.getBoundingClientRect();
    if (!r.width || !r.height) return false;
    const x1 = r.left + r.width * 0.35, x2 = r.left + r.width * 0.65;
    const y1 = r.top + r.height * 0.30, y2 = r.top + r.height * 0.70;
    const tah = (ax, ay, bx, by) => {
      const kroku = 12;
      const ev = (typ, x, y) => {
        const spol = { bubbles: true, cancelable: true, clientX: x, clientY: y, buttons: 1, button: 0 };
        try { cv.dispatchEvent(new PointerEvent(typ, Object.assign({ pointerId: 1, pointerType: 'mouse', isPrimary: true }, spol))); } catch (e) { /* */ }
        try { cv.dispatchEvent(new MouseEvent(typ.replace('pointer', 'mouse'), spol)); } catch (e) { /* */ }
      };
      ev('pointerdown', ax, ay);
      for (let i = 1; i <= kroku; i++) ev('pointermove', ax + (bx - ax) * (i / kroku), ay + (by - ay) * (i / kroku));
      ev('pointerup', bx, by);
    };
    tah(x1, y1, x2, y2);
    tah(x2, y1, x1, y2);
    return true;
  }

  function demoZrus() {
    if (engine._demoTimer) { clearTimeout(engine._demoTimer); engine._demoTimer = null; }
    if (engine._demoPsani) {
      clearInterval(engine._demoPsani);
      engine._demoPsani = null;
      // Přerušené vypisování (změna tempa, přepnutí na ruční, zavření karty)
      // by v poli nechalo půlku slova — a protože prezentace už vyplněná pole
      // nepřepisuje, zůstal by v ostrých datech useknutý údaj bez značky
      // UKÁZKA. Rozepsané pole proto radši vrátíme na prázdno.
      const el = engine._demoPisEl;
      if (el && el.isConnected) { try { demoNastav(el, ''); } catch (e) { /* */ } }
    }
    engine._demoPisEl = null;
  }

  // Ukončení bez překreslení karty — pro místa, kde se stejně překresluje jinak.
  function demoUkonci() {
    demoZrus();
    demoZnacka(false);
    engine.demoCeka = '';
    if (state.demo) { state.demo = null; saveState(); }
  }

  function demoStart(scenarId) {
    const def = demoScenar(scenarId || engine.demoVyber);
    if (!def) return;
    const sc = DATA.scenarios.find((s) => s.id === def.scenar);
    if (!sc || !sc.available || !sc.steps.length || !scenarSplnen(sc)) return;
    demoZnacka(true);
    nactiHlasSeznam();   // ať je jasné, které kroky mají nahrávku
    engine.demoVyber = def.scenar;
    state.demo = { bezi: true, auto: true, pauza: demoPauzaPlatna(engine.demoPauzaVolba),
      dleTextu: true, hlas: !!engine.demoHlasVolba, scenar: def.scenar };
    state.active = { scenarioId: sc.id, step: 0, stepId: sc.steps[0].id, paused: false };
    engine.demoCeka = '';
    // Prezentace musí začít od prvního kroku. Kdyby ji uživatel spustil na
    // stránce, kde první krok neplatí (rozepsaná zakázka, karta klienta),
    // průvodce by odskočil doprostřed scénáře — a přeskok prezentaci ukončí
    // (viz resume). Proto nejdřív přejdeme na přehled klientů, odkud postup
    // začíná. V testovacím harnessu se navigace simuluje stejným háčkem
    // jako adresa stránky (__icop2TestPath).
    if (!stepMatchesUrl(sc.steps[0])) {
      hideAll();
      saveState(() => {
        const kam = def.start || '/customers/';
        if (typeof window.__icop2TestGoTo === 'function') { window.__icop2TestGoTo(kam); resume(); return; }
        if (/(^|\.)ic-office\.eu$/.test(location.hostname)) { location.href = kam; return; }
        resume();
      });
      return;
    }
    saveState();
    resume();
  }

  function demoStop() {
    demoUkonci();
    closeFabMenu();
    if (engine.step) { buildCard(); positionCard(); }
  }

  // Krok se nepodařilo provést. Když ho scénář dovoluje přeskočit (načtení
  // z registru vozidel, řádky materiálu), prezentace ho přeskočí — je to
  // legitimní volba uživatele a předvádění nemá váznout. Jinak zastaví.
  function demoZaseknuto(duvod) {
    if (engine.step && engine.step.skip) { demoZrus(); skip(); return; }
    demoPauza(duvod);
  }

  // Prezentace se zastavila (nepovedlo se vyplnit, klik nikam nevedl…).
  // Nepokoušíme se hádat dál — přepneme na ruční tempo a řekneme proč.
  function demoPauza(duvod) {
    demoZrus();
    if (!demoBezi()) return;
    state.demo.auto = false;
    // Důvod se ukládá do stavu. Bez toho by po načtení stránky zůstal ruční
    // režim bez jakéhokoli vysvětlení, proč se prezentace zastavila.
    state.demo.ceka = duvod || '';
    engine.demoCeka = duvod || '';
    saveState();
    buildCard();
    positionCard();
  }

  function demoNaplanuj() {
    demoZrus();
    if (!demoBezi() || !engine.step) return;
    // Po načtení stránky si důvod zastavení vezmeme ze stavu — jinak by
    // uživatel viděl ruční režim bez vysvětlení, proč se prezentace zastavila.
    if (!engine.demoCeka && state.demo.ceka) engine.demoCeka = state.demo.ceka;
    // Přečíst krok nahlas se má jednou — ne znovu při každé změně tempa.
    const sig = engine.step.id + '/' + engine.stage;
    if (engine._demoReceno !== sig) { engine._demoReceno = sig; demoMluv(); }
    if (!state.demo.auto) return;   // ruční tempo — čeká se na tlačítko „Krok"
    engine._demoTimer = setTimeout(demoProved, demoPauzaKroku());
  }

  // Hodnotu je nutné zapsat nativním setterem, jinak si jí framework na
  // stránce nemusí všimnout a pole zůstane „prázdné" i s viditelným textem.
  function demoNastav(el, val) {
    const proto = (el.tagName === 'TEXTAREA') ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, val); else el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }

  // Text vypisujeme po znacích — na prezentaci má být vidět, co se zadává.
  function demoPis(el, text, hotovo) {
    let i = 0;
    const krok = DEMO_PSANI_MS;
    engine._demoPisEl = el;
    engine._demoPsani = setInterval(() => {
      if (!demoBezi()) { demoZrus(); return; }
      // Pole zmizelo uprostřed psaní (zavřený modal, překreslený řádek).
      // Bez hlášky by prezentace tiše umřela a nikdo by nevěděl proč.
      if (!el.isConnected) {
        demoZaseknuto('Pole, do kterého prezentace psala, ze stránky zmizelo. Vyplňte ho prosím sami a pokračujte tlačítkem „Další krok“.');
        return;
      }
      i++;
      demoNastav(el, text.slice(0, i));
      if (i >= text.length) {
        clearInterval(engine._demoPsani);
        engine._demoPsani = null;
        engine._demoPisEl = null;   // hotová hodnota se už nesmí mazat
        hotovo();
      }
    }, krok);
  }

  // Zadání kroku vždy převedeme na seznam ŘÁDKŮ. Jednoduchý krok (jméno,
  // telefon) má jeden řádek, materiál a práce v zakázce jich mají několik.
  function demoZadani(step) {
    const prazdne = { klik: null, radky: [], preskocit: false, podpis: null };
    const z = UKAZKA[step && step.id];
    if (Array.isArray(z)) return Object.assign({}, prazdne, { radky: [z] });
    if (z && typeof z === 'object') {
      if (z.preskocit) return Object.assign({}, prazdne, { preskocit: true });
      if (z.podpis) return Object.assign({}, prazdne, { podpis: z.podpis });
      if (Array.isArray(z.radky)) return Object.assign({}, prazdne, { klik: z.klik || null, radky: z.radky });
      return Object.assign({}, prazdne, { klik: z.klik || null, radky: [Array.isArray(z.pole) ? z.pole : []] });
    }
    return prazdne;
  }

  // i-tý výskyt selektoru = i-tý řádek. Řádky materiálu i práce jsou v DOM
  // pod sebou a každý má svoje pole se stejným selektorem, takže pořadí
  // výskytu odpovídá pořadí řádků.
  function demoPrvek(sel, i) {
    let list;
    try { list = document.querySelectorAll(sel); } catch (e) { list = []; }
    if (list[i]) return list[i];
    return i === 0 ? (findVisible(sel) || findEl(sel)) : null;
  }

  // Kolik řádků na stránce už je — počítáme podle prvního pole prvního řádku.
  function demoPocetRadku(zad) {
    const sel = zad.radky[0] && zad.radky[0][0] && zad.radky[0][0][0];
    if (!sel) return 0;
    try { return document.querySelectorAll(sel).length; } catch (e) { return 0; }
  }

  // Pole tohoto kroku, která ještě nejsou vyplněná. Co uživatel vyplnil sám,
  // prezentace nepřepisuje.
  function demoPole(step) {
    const out = [];
    demoZadani(step).radky.forEach((radek, i) => {
      for (const dvojice of radek) {
        const el = demoPrvek(dvojice[0], i);
        if (el && 'value' in el && !String(el.value || '').trim()) out.push([el, String(dvojice[1])]);
      }
    });
    return out;
  }

  function demoProved() {
    demoZrus();
    if (!demoBezi() || !engine.step) return;
    engine.demoCeka = '';
    state.demo.ceka = '';
    const zad = demoZadani(engine.step);
    // Krok, který prezentace nesmí provést naostro.
    if (zad.preskocit) { skip(); return; }
    // Podpisové pole — křížek se kreslí jen jednou za krok.
    if (zad.podpis && !engine._demoPodepsano) {
      engine._demoPodepsano = true;
      if (demoPodpisKrizek(zad.podpis)) {
        engine._demoTimer = setTimeout(demoPosun, DEMO_KLIK_MS);
        return;
      }
      demoZaseknuto('Podpisové pole se nepodařilo najít. Podepište prosím sami a pokračujte tlačítkem „Další krok“.');
      return;
    }
    // Řádky materiálu a práce v zakázce ještě neexistují — musí je vytvořit
    // tlačítko „Přidat…". Nejdřív naklikáme VŠECHNY řádky a teprve pak je
    // vyplňujeme: kdybychom vyplňovali průběžně, po prvním řádku by se brána
    // kroku odemkla a prezentace by odešla dál bez zbytku položek.
    // Počet kliknutí je shora omezený, aby se řádky nemnožily donekonečna.
    if (zad.klik && demoPocetRadku(zad) < zad.radky.length && engine._demoKliku < zad.radky.length) {
      const el = findVisible(zad.klik) || findEl(zad.klik);
      if (el) {
        engine._demoKliku++;
        try { el.click(); } catch (e) { /* */ }
        engine._demoTimer = setTimeout(demoProved, DEMO_KLIK_MS);
        return;
      }
    }
    const pole = demoPole(engine.step);
    if (pole.length) { demoVyplnuj(pole, 0); return; }
    demoPosun();
  }

  function demoVyplnuj(pole, i) {
    if (!demoBezi()) return;
    if (i >= pole.length) {
      engine._demoTimer = setTimeout(demoPosun, DEMO_KLIK_MS);
      return;
    }
    const el = pole[i][0];
    if (!el.isConnected) { demoVyplnuj(pole, i + 1); return; }
    try { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.focus(); } catch (e) { /* */ }
    demoPis(el, pole[i][1], () => {
      try { el.dispatchEvent(new Event('change', { bubbles: true })); el.blur(); } catch (e) { /* */ }
      engine._demoTimer = setTimeout(() => demoVyplnuj(pole, i + 1), 260);
    });
  }

  function demoPosun() {
    demoZrus();
    if (!demoBezi() || !engine.step) return;
    const step = engine.step;
    const rucne = (UKAZKA[step.id] || {}).rucne;
    if (Array.isArray(rucne) && !rucne.every((g) => groupHasValue(g))) {
      demoPauza((step.gateHint || 'Doplňte povinné údaje.') + ' Výběr proveďte sami a pokračujte tlačítkem „Další krok“.');
      return;
    }
    if (isGated(step) && !gateSatisfied(step)) {
      demoZaseknuto('Tento krok čeká na vyplněná pole a prezentace je nedokázala doplnit sama. Vyplňte je a pokračujte tlačítkem „Další krok“.');
      return;
    }
    // Krok, který se posouvá sám (advance.auto po vyplnění polí): nesmíme
    // volat next() — engine ho posune ve svém ticku a dvojí posun by přeskočil
    // následující krok. Jen počkáme a hlídáme, že se to opravdu stalo.
    if ((step.advance || {}).auto) {
      const podpisA = step.id + '/' + engine.stage;
      engine._demoTimer = setTimeout(() => {
        if (!demoBezi() || !engine.step) return;
        if (engine.step.id + '/' + engine.stage === podpisA) {
          demoZaseknuto('Prezentace čeká — tento krok se sám neposunul. Pokračujte tlačítkem „Další krok“.');
        }
      }, 8000);
      return;
    }
    // Krok, který se posouvá ZMIZENÍM okna (advance.hidden): když je okno už
    // zavřené a tlačítko pryč, je hotovo. Čekat na tlačítko, které neexistuje,
    // nemá smysl — přesně tak prezentace uvázla po uložení vozidla, přestože
    // vozidlo bylo založené.
    const adv = step.advance || {};
    if (adv.hidden) {
      const okno = findEl(adv.hidden);
      if (!(okno && isVisible(okno)) && !findVisible(step.target)) { next(); return; }
    }
    if (step.next === false) {
      // Krok se posouvá kliknutím přímo v IC Office — klikneme za uživatele.
      const podpis = step.id + '/' + engine.stage;
      // Rozbalovací menu se otevírá NAJETÍM MYŠI a jeho položky jsou v DOM
      // i zavřené. Klik na rodiče by NAVIGOVAL (položka menu je odkaz) a
      // prezentace se zacyklila hned na „+ Přidat klienta" — rodiče proto jen
      // pohladíme hover událostmi a klikneme rovnou na cíl druhé fáze.
      // Nabídky, jejichž položky vznikají až po kliknutí (popover podpisu,
      // select2 se seznamem vozidel), tudy neprojdou — cíl druhé fáze v DOM
      // ještě není — a jedou dál původní cestou přes klik na rodiče.
      if (engine.stage === 1 && step.then) {
        const uvnitr = findEl(step.then.target);
        if (uvnitr) {
          const rodic = findVisible(step.target);
          if (rodic) demoHover(rodic);
          demoKlikni(uvnitr, podpis, true);
          return;
        }
      }
      const cil = (engine.stage === 2 && step.then)
        ? (findVisible(step.then.target) || findEl(step.then.target) || findVisible(step.target))
        : findVisible(step.target);
      if (!cil) {
        demoZaseknuto('Místo, na které tento krok ukazuje, teď na stránce není. Klikněte prosím sami a pak pokračujte tlačítkem „Další krok“.');
        return;
      }
      demoKlikni(cil, podpis);
      return;
    }
    next();
  }

  // Najetí myší vyvolané skriptem. CSS :hover tím nevznikne, ale menu
  // rozbalovaná javascriptem se otevřou — a hlavně je v záznamu prezentace
  // vidět, kudy se šlo.
  function demoHover(el) {
    for (const typ of ['pointerover', 'pointerenter', 'mouseover', 'mouseenter']) {
      try {
        const Ev = typ.startsWith('pointer') ? PointerEvent : MouseEvent;
        el.dispatchEvent(new Ev(typ, { bubbles: !typ.endsWith('enter'), cancelable: true }));
      } catch (e) { /* starší prohlížeč bez PointerEvent — nevadí */ }
    }
  }

  // Klik za uživatele + hlídač, že opravdu někam vedl.
  // `uzThen` = klikáme rovnou na cíl druhé fáze, další pokus už nebude.
  function demoKlikni(cil, podpis, uzThen) {
    const step = engine.step;
    // Strop na počet pokusů v rámci JEDNÉ fáze kroku. Když IC Office uložení
    // odmítne, krok se vrátí zpět a prezentace by jinak mačkala „Uložit“
    // donekonečna — a každý pokus je odeslaný formulář.
    if (engine._demoPokusPodpis !== podpis) { engine._demoPokusPodpis = podpis; engine._demoPokusu = 0; }
    engine._demoPokusu++;
    if (engine._demoPokusu > 3) {
      demoPauza('Prezentace zkoušela tento krok třikrát a nepovedlo se. Dokončete ho prosím sami a pokračujte tlačítkem „Další krok“.');
      return;
    }
    try { cil.click(); } catch (e) { /* */ }
    // Klik posune krok SYNCHRONNĚ (advanceFromClick → showStep → demoNaplanuj).
    // Kdybychom hlídač nasadili natvrdo, přepsal by právě naplánovaný další
    // krok a prezentace by se zasekla hned na prvním kliknutí.
    if (!engine.step || engine.step.id + '/' + engine.stage !== podpis) return;
    // Rozbalovací menu IC Office se otevírá najetím myší (CSS :hover), a to
    // skriptem vyvolat nejde. Cíl druhé fáze je ale v DOM i zavřený — po chvíli
    // na něj klikneme přímo, jinak by se tu prezentace vždy zastavila.
    if (step && step.then && engine.stage === 1 && !uzThen) {
      // Nabídka se nemusí rozbalit hned — select2 si položky domýšlí až po
      // otevření a někdy je dotahuje ze serveru. Proto se na cíl druhé fáze
      // ptáme opakovaně, ne jen jednou; jinak prezentace hlásila „nabídka se
      // nerozbalila“ v okamžiku, kdy se rozbalovala.
      let cekani = 0;
      const zkusThen = () => {
        if (!demoBezi() || !engine.step || engine.step.id + '/' + engine.stage !== podpis) return;
        const skryty = findVisible(step.then.target) || findEl(step.then.target);
        if (skryty) { demoKlikni(skryty, podpis, true); return; }
        if (++cekani < 6) { engine._demoTimer = setTimeout(zkusThen, 500); return; }
        demoZaseknuto('Nabídka se nerozbalila. Vyberte prosím sami a pokračujte tlačítkem „Další krok“.');
      };
      engine._demoTimer = setTimeout(zkusThen, DEMO_KLIK_MS);
      return;
    }
    // hlídač: klik nemusí nikam vést (změněná stránka) — pak radši stop
    engine._demoTimer = setTimeout(() => {
      if (!demoBezi() || !engine.step) return;
      if (engine.step.id + '/' + engine.stage === podpis) {
        demoZaseknuto('Prezentace se zastavila — po kliknutí se nic nezměnilo. Pokračujte ručně tlačítkem „Další krok“.');
      }
    }, 6000);
  }

  function demoBarHtml() {
    const d = state.demo || {};
    const auto = d.auto !== false;
    const pauza = demoPauzaPlatna(d.pauza);
    const tento = Math.round(demoPauzaKroku() / 1000);
    const dleTextu = d.dleTextu !== false;
    // Hlavička říká STAV, tlačítko AKCI. Když stav nesl jen zvýrazněný přepínač
    // s popiskem „Ruční tempo", četlo se to jako „ruční režim je zapnutý“.
    return `<div class="demo">
      <div class="dhead">Prezentace — ${auto ? 'běží automaticky' : 'ruční tempo, čeká na vás'}</div>
      ${engine.demoCeka ? `<div class="dwait">${escHtml(engine.demoCeka)}</div>` : ''}
      <div class="drow">
        <button type="button" class="db" data-a="demoauto">${auto ? 'Přepnout na ruční' : 'Spustit automaticky'}</button>
        <button type="button" class="db" data-a="demonext">Další krok</button>
        <button type="button" class="db${d.hlas ? ' on' : ''}" data-a="demohlas"
                title="Předčítat text kroku nahlas">${d.hlas ? 'Mluví' : 'Mluvit'}</button>
        <span class="sp"></span>
        <button type="button" class="db stop" data-a="demostop">Konec</button>
      </div>
      <div class="drow dpauza">
        <button type="button" class="db kr" data-a="demominus" aria-label="Zkrátit pauzu">−</button>
        <span class="dcas"><strong>${pauza} s</strong> mezi kroky${dleTextu && tento !== pauza ? ` · tento krok <strong>${tento} s</strong>` : ''}</span>
        <button type="button" class="db kr" data-a="demoplus" aria-label="Prodloužit pauzu">+</button>
        <label class="dsp"><input type="checkbox" data-a="demodle" ${dleTextu ? 'checked' : ''}> podle délky textu</label>
      </div>
    </div>`;
  }

  // Nastavení pauzy ještě před spuštěním — přednášející si tempo naladí předem.
  function demoPauzaVolbaHtml() {
    const p = demoPauzaPlatna(engine.demoPauzaVolba);
    return `<div class="dvolba">
      <label for="demo-pauza">Pauza mezi kroky</label>
      <div class="drow">
        <input id="demo-pauza" type="range" min="${DEMO_PAUZA_MIN}" max="${DEMO_PAUZA_MAX}" step="1" value="${p}">
        <span class="dcas"><strong id="demo-pauza-cas">${p}</strong> s</span>
      </div>
      <p class="hint">Kratší pauza = svižná ukázka pro publikum, které systém zná.
        Delší dává čas přečíst si popis a zeptat se. Měnit ji jde i během prezentace.
        U delších popisů se pauza automaticky prodlouží, u krátkých zkrátí.</p>
      <label class="dsp"><input type="checkbox" id="demo-hlas" ${engine.demoHlasVolba ? 'checked' : ''}> Předčítat text kroku nahlas</label>
    </div>`;
  }

  // Seznam cvičení — seskupený, ať je vidět, že jde o krátké úseky, ne
  // o hodinový blok. Pořadí odpovídá tomu, jak na sebe práce navazuje.
  function cvSeznamHtml() {
    const skupiny = [];
    for (const cv of CVICENI) {
      const nazev = cv.skupina || 'Ostatní';
      let g = skupiny.find((x) => x.nazev === nazev);
      if (!g) { g = { nazev, polozky: [] }; skupiny.push(g); }
      g.polozky.push(cv);
    }
    const hotova = (state.cvHotova || {});
    const bloky = skupiny.map((g) => `<div class="cvskup"><h3>${escHtml(g.nazev)}</h3>${g.polozky.map((cv) => {
      const sc = DATA.scenarios.find((s) => s.id === cv.scenar);
      const jde = !!(sc && sc.available && scenarSplnen(sc) && cvIndexy(cv));
      const zn = hotova[cv.id];
      const zadano = !!(state.plan && state.plan.cviceni.indexOf(cv.id) >= 0);
      return `<button class="scen-item ${jde ? '' : 'dis'}${zadano ? ' zadano' : ''}" data-cvstart="${jde ? escHtml(cv.id) : ''}" ${jde ? '' : 'disabled'}>
        <span class="num cvnum">${zadano ? ik('seznam') : cv.minuty + '′'}</span>
        <span class="st"><span class="t">${escHtml(cv.titulek)}</span>
        <span class="d">${escHtml(sc ? sc.title : '')}</span></span>
        ${!jde && sc && sc.vyzadujeText ? `<span class="badge lock">${ik('zamek')}${escHtml(sc.vyzadujeText)}</span>`
          : (zn ? `<span class="badge done">${ik('hotovo')}${zn.napoved === 0 ? 'bez nápovědy' : zn.napoved + '× nápověda'}</span>`
                : '<span class="badge go">Zkusit</span>')}</button>`;
    }).join('')}</div>`).join('');
    const s = cvSouhrn();
    const plan = state.plan;
    return `<div class="wsub">Krátké úkoly, u kterých vám průvodce <strong>neradí</strong> — dokud si o to neřeknete.
        Každý zabere pár minut a dá se opakovat.
        <span class="lg">Číslo vlevo je orientační čas v minutách.</span></div>
      ${plan ? `<div class="cvplan">${ik('seznam')}<strong>Zadání${plan.od ? ' od: ' + escHtml(plan.od) : ''}</strong> —
        procvičit ${plan.cviceni.length} ${plan.cviceni.length === 1 ? 'cvičení' : 'cvičení'}.
        Hotovo ${plan.cviceni.filter((id) => (state.cvHotova || {})[id]).length} z ${plan.cviceni.length}.
        <button type="button" data-a="cvplanpryc">Zrušit zadání</button></div>` : ''}
      ${s.zkusena ? `<div class="cvsouhrn maly">
        <div class="cvr"><span class="k">Zvládnuto</span><span class="v">${s.zkusena} z ${s.celkem}</span></div>
        <div class="cvr"><span class="k">Bez nápovědy</span><span class="v">${s.bezNapovedy}</span></div>
      </div>` : ''}
      <div class="wlist">${bloky}</div>
      <div class="wdemo">
        <button type="button" class="dstart cv" data-a="cvvysledky">Moje výsledky
          <span>Přehled, kolik jste zvládli sami — a předání mistrovi kódem</span></button>
        <button type="button" class="dstart" data-a="cvnacist">Načíst kód
          <span>Zadání od mistra, nebo výsledky učně, které vám poslal</span></button>
        <button type="button" class="dstart" data-a="cvzadani">Sestavit zadání pro učně
          <span>Zaškrtáte cvičení a vyrobí se kód, který učni pošlete</span></button>
        <button type="button" class="dstart" data-a="cvzpet">← Zpět na scénáře</button>
      </div>`;
  }

  // Mistr sestaví zadání: zaškrtá, co má učeň procvičit, a vyrobí kód.
  function cvZadaniHtml() {
    const skupiny = [];
    for (const cv of CVICENI) {
      const nazev = cv.skupina || 'Ostatní';
      let g = skupiny.find((x) => x.nazev === nazev);
      if (!g) { g = { nazev, polozky: [] }; skupiny.push(g); }
      g.polozky.push(cv);
    }
    const bloky = skupiny.map((g) => `<div class="cvskup"><h3>${escHtml(g.nazev)}</h3>${g.polozky.map((cv) => {
      const sc = DATA.scenarios.find((s) => s.id === cv.scenar);
      if (!sc || !sc.available) return '';
      return `<label class="cvvol"><input type="checkbox" data-zadani="${escHtml(cv.id)}">
        <span class="t">${escHtml(cv.titulek)}</span><span class="m">${cv.minuty}′</span></label>`;
    }).join('')}</div>`).join('');
    return `<div class="wsub">Zaškrtejte, co má učeň procvičit. Vyrobí se <strong>kód zadání</strong>,
      který mu pošlete — on ho vloží a cvičení se mu označí.</div>
      <div class="wlist">${bloky}</div>
      <div class="wform">
        <label for="cv-od">Od koho (volitelné)</label>
        <input id="cv-od" type="text" autocomplete="off" placeholder="Vaše jméno" value="${escHtml((state.contact || {}).jmeno || '')}">
        <div class="wact">
          <button type="button" class="b main" data-a="cvzadanikod">Vyrobit kód zadání</button>
          <button type="button" class="b ghost" data-a="cvzpet">Zpět</button>
        </div>
      </div>`;
  }

  // Které z podoken cvičení se zrovna ukazuje.
  function cvPohledHtml() {
    if (engine.cvPohled === 'zadani') return cvZadaniHtml();
    if (engine.cvPohled === 'vysledky') return cvVysledkyHtml(null, null);
    if (engine.cvPohled === 'cizi') return cvVysledkyHtml(engine.cvCizi, engine.cvCiziKdo);
    if (engine.cvPohled === 'nacist') return cvKodHtml();
    if (engine.cvPohled === 'kod') return cvKodVenHtml();
    return cvSeznamHtml();
  }

  function demoAskHtml() {
    const def = demoScenar(engine.demoVyber) || {};
    const sc = DATA.scenarios.find((s) => s.id === def.scenar) || {};
    engine.demoVyber = def.scenar;
    // Výběr scénáře je nahoře, protože mění zbytek textu — co naostro vznikne
    // se u skladu liší od zakázky a přednášející to musí vidět předem.
    const vyber = PREZENTACE.length > 1 ? `<div class="dvyber">${PREZENTACE.map((p) => {
      const s = DATA.scenarios.find((x) => x.id === p.scenar);
      if (!s || !s.available) return '';
      return `<button type="button" class="dvol${p.scenar === def.scenar ? ' on' : ''}" data-demosc="${escHtml(p.scenar)}">
        ${escHtml(s.title)}</button>`;
    }).join('')}</div>` : '';
    return `<div class="wdemoask">
      ${vyber}
      <p>Průvodce si projde scénář <strong>${escHtml(sc.title || '')}</strong> sám — pomalu klikne na každé místo,
        vypíše ukázkové údaje a u každého kroku ukáže, co dělá a proč.</p>
      <p class="pozor">${ik('varovani')}<span>Prezentace běží na <strong>ostrém IC Office</strong>. Kroky s uložením se <strong>opravdu uloží</strong> —
        vznikne ${def.vznikne || 'nový záznam'}.${def.neudela ? ' ' + def.neudela : ''}</span></p>
      <p>Ukázková data mají v názvu slovo <strong>UKÁZKA</strong>, takže je po prezentaci poznáte a smažete.
        ${def.scenar === 'novy-zakaznik-osobne'
          ? 'Zakázkový list se <strong>podepíše křížkem</strong>. <strong>Vozidlo</strong> značku nést nemůže — uloží se pod zadaným VIN a SPZ. Telefon a e-mail klienta jsou <strong>vaše vlastní</strong>, takže případná automatická zpráva o stavu zakázky přijde vám, ne cizímu člověku.'
          : ''}</p>
      <p>Prezentace začne na adrese <strong>${escHtml(def.start || '/')}</strong>, takže si nejdřív dokončete, co máte rozepsané.</p>
      ${demoPauzaVolbaHtml()}
      <div class="wask">
        <button type="button" class="b main" data-a="demogo">Ano, spustit prezentaci</button>
        <button type="button" class="b ghost" data-a="demoback">Ne, zpět na scénáře</button>
      </div>
    </div>`;
  }

  // ---------------- cvičení (procvičení bez nápovědy) ----------------
  // Cvičení je úsek scénáře, který uživatel projde SÁM: vidí jen zadání, ne
  // instrukce ani vysvícení. Průvodce mezitím měří čas, kolikrát si řekl
  // o nápovědu a kolikrát klikl jinam, než kam krok mířil.
  //
  // Stav je jen v paměti — cvičení je jedno sezení. Kdyby přežilo načtení
  // stránky, uživatel by se do „režimu bez nápovědy" mohl dostat omylem
  // a nechápal by, proč mu průvodce přestal radit.
  let CVICENI = Array.isArray(DATA.cviceni) ? DATA.cviceni : [];

  // ---------------- obsah zvenčí ----------------
  // Obsah smí přijít z editoru (viz FORMAT.md). Než ho průvodce použije, musí
  // projít kontrolou — obsah z budoucnosti nebo rozbitý export nesmí uživateli
  // shodit průvodce, jen se tiše nepoužije a zůstane ten zabudovaný.
  const OBSAH_KEY = 'icop2:obsah';
  const OBSAH_FORMAT = 1;

  function obsahVada(d) {
    if (!d || typeof d !== 'object') return 'obsah není objekt';
    if (d.format !== OBSAH_FORMAT) {
      return `formát ${JSON.stringify(d.format)} — tento průvodce umí ${OBSAH_FORMAT}`;
    }
    if (!Array.isArray(d.scenarios) || !d.scenarios.length) return 'chybí scénáře';
    const kody = new Set();
    const ids = new Set();
    for (const sc of d.scenarios) {
      if (!sc || typeof sc.id !== 'string' || !sc.id) return 'scénář bez id';
      if (ids.has(sc.id)) return `dvakrát scénář ${sc.id}`;
      ids.add(sc.id);
      if (!/^[A-Z]{2}$/.test(sc.code || '')) return `scénář ${sc.id} nemá dvoupísmenný code`;
      if (kody.has(sc.code)) return `dvakrát zkratka ${sc.code}`;
      kody.add(sc.code);
      if (!Array.isArray(sc.steps)) return `scénář ${sc.id} nemá kroky`;
      const stepIds = new Set();
      for (const st of sc.steps) {
        if (!st || typeof st.id !== 'string' || !st.id) return `krok bez id ve scénáři ${sc.id}`;
        if (stepIds.has(st.id)) return `dvakrát krok ${sc.id}/${st.id}`;
        stepIds.add(st.id);
        if (!['info', 'click', 'fill', 'note'].includes(st.kind)) return `krok ${sc.id}/${st.id}: neznámý druh`;
        if (!Array.isArray(st.url) || !st.url.length) return `krok ${sc.id}/${st.id}: chybí url`;
        if (st.kind !== 'info' && !st.target) return `krok ${sc.id}/${st.id}: chybí target`;
      }
    }
    return null;
  }

  // Přepnutí na jiný obsah. Všechno, co se z obsahu odvozuje, se přepočítá tady
  // — jinde v enginu se DATA čte až za běhu, takže stačí tohle jedno místo.
  function pouzijObsah(d, zdroj) {
    DATA = d;
    OBSAH_ZDROJ = zdroj;
    UI_VERSION = String(DATA.version || '2').split('.').slice(0, 2).join('.');
    UKAZKA = DATA.ukazka || {};
    PREZENTACE = (Array.isArray(DATA.prezentace) ? DATA.prezentace : []).filter((p) => p && p.scenar);
    MANUALS = DATA.manuals || {};
    MANUALS_URL = DATA.manualsUrl || '';
    SUP = DATA.support || {};
    CVICENI = Array.isArray(DATA.cviceni) ? DATA.cviceni : [];
  }
  const cvBezi = () => !!engine.cv;

  // ---------------- režim správce: interaktivní úpravy na stránce ----------------
  // Správce (zapíná se v okně doplňku) může krok upravit PŘÍMO na stránce:
  // text, barvu, štítek, šířku karty, přemířit cíl kliknutím na prvek, přidat
  // nový krok a kroky ze scénáře vynechávat či vracet. Úpravy se hned
  // promítají do běžícího průvodce a tlačítkem Uložit se zapíší jako VLASTNÍ
  // obsah doplňku (icop2:obsah) — tentýž, který jde v okně doplňku
  // vyexportovat do souboru a rozdat uživatelům importem.
  const SPRAVA_KEY = 'icop2:sprava';
  let SPRAVA = false;
  try {
    chrome.storage.local.get([SPRAVA_KEY], (r) => {
      SPRAVA = !!(r && r[SPRAVA_KEY]);
      if (SPRAVA && engine.step) { buildCard(); positionCard(); }
    });
  } catch (e) { /* mimo rozšíření */ }

  // Kroky vynechané správcem (vynechan: true) se za běhu přeskakují, ale
  // v uloženém obsahu zůstávají — editor je může kdykoli vrátit.
  function bezVynechanych(d) {
    const kopie = JSON.parse(JSON.stringify(d));
    for (const sc of kopie.scenarios || []) {
      if (Array.isArray(sc.steps)) sc.steps = sc.steps.filter((st) => !(st && st.vynechan));
    }
    return kopie;
  }

  // Úplný obsah včetně vynechaných kroků — nad ním pracuje editor a ten se
  // také ukládá. Vzniká až při první potřebě kopií právě běžícího obsahu.
  let OBSAH_PLNY = null;
  function zajistiPlny() {
    if (!OBSAH_PLNY) OBSAH_PLNY = JSON.parse(JSON.stringify(DATA));
    return OBSAH_PLNY;
  }

  function plnyKrok() {
    if (!engine.scenario || !engine.step) return null;
    const p = zajistiPlny();
    const sc = (p.scenarios || []).find((s) => s.id === engine.scenario.id);
    if (!sc) return null;
    return { sc, st: (sc.steps || []).find((st) => st.id === engine.step.id) || null };
  }

  function editorHtml() {
    const st = engine.step;
    const p = plnyKrok();
    const kroky = p ? p.sc.steps : [];
    return `<div class="edit">
      <div class="ehead">${ik('upravit')}Režim správce — úprava kroku ${stepCode()}</div>
      <label>Nadpis</label>
      <input type="text" data-e="title" value="${escHtml(st.title || '')}">
      <label>Text karty (HTML — &lt;strong&gt;, &lt;br&gt;)</label>
      <textarea data-e="text">${escHtml(st.text || '')}</textarea>
      <label>Štítek u vysvíceného prvku</label>
      <input type="text" data-e="label" value="${escHtml(st.label || '')}">
      <div class="erow">
        <label>Barva nápovědy
          <select data-e="color">
            <option value="red"${st.color !== 'yellow' ? ' selected' : ''}>vínová — povinný krok</option>
            <option value="yellow"${st.color === 'yellow' ? ' selected' : ''}>žlutá — doporučení</option>
          </select></label>
        <label>Šířka karty (px)
          <input type="number" data-e="sirka" min="320" max="640" step="10" value="${Number(st.sirka) || 420}"></label>
      </div>
      <div class="eacts">
        <button type="button" data-a="editCil">${ik('misto')}Vybrat prvek na stránce</button>
        <button type="button" data-a="editNovy">${ik('pridat')}Nový krok za tímto</button>
      </div>
      <details><summary>Kroky scénáře — zahrnout / vynechat</summary>
        <div class="ekroky">${kroky.map((k) => `<label><input type="checkbox" data-ekrok="${escHtml(k.id)}"${k.vynechan ? '' : ' checked'}>
          <span class="eid">${escHtml(String(k.id).toUpperCase())}</span> ${escHtml(bezHtml(k.title || ''))}</label>`).join('')}</div>
      </details>
      <label class="evidea"><input type="checkbox" data-evidea${videaZapnuta() ? ' checked' : ''}>
        Videa pro uživatele (tlačítko Video u kroků i uvítací video)</label>
      <div class="eacts">
        <button type="button" class="prim" data-a="editUlozit">Uložit úpravy</button>
        <button type="button" data-a="editZavrit">Zavřít editor</button>
      </div>
      <div class="ehint" data-estav>Úpravy se hned promítají do průvodce; Uložit je zapíše jako vlastní obsah doplňku.
        Rozdání uživatelům: okno doplňku → Uložit obsah do souboru → import u uživatele.</div>
    </div>`;
  }

  // Levný náhled bez přestavby karty — přestavba by sebrala kurzor z pole,
  // do kterého správce právě píše.
  function editorNahled(co) {
    const st = engine.step;
    if (!st) return;
    if (co === 'title') { const h = card.querySelector('h3'); if (h) h.innerHTML = typografie(st.title || ''); }
    if (co === 'text') { const t = card.querySelector('.txt'); if (t) t.innerHTML = textKroku(st.text); }
    if (co === 'color') card.dataset.color = st.color === 'yellow' ? 'yellow' : 'red';
    if (co === 'sirka') {
      const n = Number(st.sirka);
      card.style.width = (Number.isFinite(n) && n >= 320 && n <= 640) ? Math.round(n) + 'px' : '';
    }
    if (co === 'label' || co === 'color') { clearHoles(); renderSpotlight(); }
    positionCard();
  }

  function editorPouzijPole(co, pole) {
    const st = engine.step;
    if (!st) return;
    const p = plnyKrok();
    const zapis = (obj) => { Object.assign(st, obj); if (p && p.st) Object.assign(p.st, obj); };
    if (co === 'title') zapis({ title: pole.value });
    else if (co === 'text') zapis({ text: pole.value });
    else if (co === 'label') zapis({ label: pole.value });
    else if (co === 'color') zapis({ color: pole.value === 'yellow' ? 'yellow' : 'red' });
    else if (co === 'sirka') {
      const n = Math.round(Number(pole.value));
      zapis({ sirka: (Number.isFinite(n) && n >= 320 && n <= 640) ? n : undefined });
    }
    editorNahled(co);
  }

  // Promítne STRUKTURÁLNÍ úpravu (vynechání kroku, nový krok) do běžícího
  // průvodce a vrátí se na zadaný, případně nejbližší rozumný krok.
  function editorPrekresli(cilovyStepId) {
    const scId = engine.scenario && engine.scenario.id;
    const stepId = cilovyStepId || (engine.step && engine.step.id);
    pouzijObsah(bezVynechanych(zajistiPlny()), OBSAH_ZDROJ);
    const sc = DATA.scenarios.find((s) => s.id === scId);
    if (!sc || !sc.steps.length || !state.active) { hideAll(); return; }
    let idx = sc.steps.findIndex((st) => st.id === stepId);
    if (idx < 0) idx = Math.min(state.active.step, sc.steps.length - 1);
    state.active = { scenarioId: scId, step: idx, stepId: sc.steps[idx].id, paused: false };
    saveState();
    resume(true);
  }

  function editorVynechani(id, vynechat) {
    const p = plnyKrok();
    if (!p) return;
    const st = p.sc.steps.find((k) => k.id === id);
    if (!st) return;
    if (vynechat) st.vynechan = true; else delete st.vynechan;
    editorPrekresli();
  }

  function editorUlozit() {
    const p = zajistiPlny();
    const stav = () => card.querySelector('[data-estav]');
    const vada = obsahVada(p);
    if (vada) { const s = stav(); if (s) s.textContent = 'Obsah nejde uložit — ' + vada + '.'; return; }
    try {
      chrome.storage.local.set({ [OBSAH_KEY]: p }, () => {
        const s = stav();
        if (chrome.runtime.lastError) { if (s) s.textContent = 'Uložení se nepovedlo. Zkuste to prosím znovu.'; return; }
        OBSAH_ZDROJ = 'vlastní';
        if (s) s.innerHTML = '<span class="ok">' + ik('hotovo') + 'Uloženo jako vlastní obsah.</span> Export: okno doplňku → Uložit obsah do souboru.';
      });
    } catch (e) { const s = stav(); if (s) s.textContent = 'Uložení se nepovedlo.'; }
  }

  // Návrh selektoru pro prvek vybraný kliknutím — od nejstabilnějšího zápisu:
  // #id → [name] → [placeholder] → odkaz podle href → třídy → cesta od rodiče
  // s id. Vrací jen selektor, který na stránce míří PRÁVĚ na jeden prvek.
  function navrhniSelektor(el) {
    if (!el || el === document.body || el === document.documentElement) return null;
    const bezp = (s) => (window.CSS && CSS.escape ? CSS.escape(s) : String(s).replace(/([^\w-])/g, '\\$1'));
    const jedinecny = (sel) => {
      try { return document.querySelectorAll(sel).length === 1 ? sel : null; } catch (e) { return null; }
    };
    if (el.id) { const s = jedinecny('#' + bezp(el.id)); if (s) return s; }
    const tag = el.tagName.toLowerCase();
    for (const attr of ['name', 'placeholder', 'data-target']) {
      const v = el.getAttribute && el.getAttribute(attr);
      if (v) { const s = jedinecny(`${tag}[${attr}='${v.replace(/'/g, "\\'")}']`); if (s) return s; }
    }
    if (tag === 'a') {
      const href = el.getAttribute('href');
      if (href && href !== '#') { const s = jedinecny(`a[href='${href.replace(/'/g, "\\'")}']`); if (s) return s; }
    }
    if (tag === 'input') {
      const v = el.getAttribute('value');
      if (v) { const s = jedinecny(`input[value='${v.replace(/'/g, "\\'")}']`); if (s) return s; }
    }
    const cls = [...(el.classList || [])].filter((c) => !/^(active|open|in|show|hover|focus)$/.test(c));
    if (cls.length) { const s = jedinecny(tag + '.' + cls.map(bezp).join('.')); if (s) return s; }
    const rodic = el.closest ? el.closest('[id]') : null;
    if (rodic && rodic !== el && rodic.id) {
      const zaklad = '#' + bezp(rodic.id) + ' ' + tag + (cls.length ? '.' + cls.map(bezp).join('.') : '');
      const s = jedinecny(zaklad);
      if (s) return s;
      try {
        const stejne = [...rodic.querySelectorAll(tag)];
        const i = stejne.indexOf(el);
        if (i >= 0) {
          const s2 = jedinecny('#' + bezp(rodic.id) + ' ' + tag + ':nth-of-type(' + (i + 1) + ')');
          if (s2) return s2;
        }
      } catch (e) { /* */ }
    }
    return null;
  }

  // ---------------- výběr prvku kliknutím (režim správce) ----------------
  let vyber = null;   // { cb } — po kliknutí na prvek stránky se zavolá cb(el)
  const vyberRam = document.createElement('div');
  vyberRam.className = 'vybram hidden';
  root.appendChild(vyberRam);
  const vyberLista = document.createElement('div');
  vyberLista.className = 'vyblista hidden';
  root.appendChild(vyberLista);

  function vyberStart(cb, hint) {
    vyber = { cb };
    vyberLista.textContent = (hint || 'Klikněte na prvek, na který má krok ukazovat.') + ' Esc = zrušit.';
    vyberLista.classList.remove('hidden');
    zaOknem(true);   // karta nesmí zakrývat prvky, mezi kterými se vybírá
    document.documentElement.style.cursor = 'crosshair';
  }
  function vyberKonec() {
    vyber = null;
    vyberRam.classList.add('hidden');
    vyberLista.classList.add('hidden');
    zaOknem(false);
    document.documentElement.style.cursor = '';
  }
  document.addEventListener('mousemove', (e) => {
    if (!vyber) return;
    const cesta = e.composedPath ? e.composedPath() : [e.target];
    if (cesta.includes(host)) { vyberRam.classList.add('hidden'); return; }
    const el = cesta[0];
    if (!el || el === document.documentElement || el === document.body || !el.getBoundingClientRect) {
      vyberRam.classList.add('hidden');
      return;
    }
    const r = el.getBoundingClientRect();
    vyberRam.style.left = (r.left - 3) + 'px';
    vyberRam.style.top = (r.top - 3) + 'px';
    vyberRam.style.width = (r.width + 6) + 'px';
    vyberRam.style.height = (r.height + 6) + 'px';
    vyberRam.classList.remove('hidden');
  }, true);
  window.addEventListener('click', (e) => {
    if (!vyber) return;
    const cesta = e.composedPath ? e.composedPath() : [e.target];
    if (cesta.includes(host)) return;   // klik do vlastního UI průvodce
    e.preventDefault();
    e.stopImmediatePropagation();
    const cb = vyber.cb;
    vyberKonec();
    cb(cesta[0]);
  }, true);
  document.addEventListener('keydown', (e) => {
    if (vyber && e.key === 'Escape') {
      e.preventDefault();
      vyberKonec();
      buildCard();
      positionCard();
    }
  }, true);

  function cvNajdi(id) { return CVICENI.find((c) => c.id === id) || null; }

  function cvIndexy(cv) {
    const sc = DATA.scenarios.find((s) => s.id === cv.scenar);
    if (!sc) return null;
    const od = sc.steps.findIndex((s) => s.id === cv.od);
    const doI = sc.steps.findIndex((s) => s.id === cv.do);
    if (od < 0 || doI < 0 || doI < od) return null;
    return { sc, od, doI };
  }

  function cvStart(id) {
    const cv = cvNajdi(id);
    const ix = cv && cvIndexy(cv);
    if (!ix) return false;
    demoUkonci();                 // prezentace a cvičení se vylučují
    closeWelcome();
    if (!state.enabled) { state.enabled = true; fab.classList.remove('off'); }
    engine.cv = { id: cv.id, doIdx: ix.doI, start: Date.now(), napoved: 0, chyby: 0, napovedaTed: false };
    state.active = { scenarioId: ix.sc.id, step: ix.od, stepId: ix.sc.steps[ix.od].id, paused: false };
    saveState();
    resume(true);
    return true;
  }

  function cvKonec(dokonceno) {
    const cv = engine.cv;
    if (!cv) return;
    const zadani = cvNajdi(cv.id);
    const sekundy = Math.round((Date.now() - cv.start) / 1000);
    engine.cv = null;
    state.active = null;
    if (dokonceno) {
      // Do stavu jde jen záznam „tohle už jsem zkusil" — kvůli odznaku v seznamu.
      state.cvHotova = Object.assign({}, state.cvHotova || {});
      state.cvHotova[cv.id] = { napoved: cv.napoved, sekundy, chyby: cv.chyby, kdy: Date.now() };
    }
    saveState();
    hideAll();
    if (dokonceno && zadani) cvVysledekKarta(zadani, sekundy, cv);
  }

  function cvVysledekKarta(zadani, sekundy, cv) {
    const min = Math.floor(sekundy / 60), sek = sekundy % 60;
    const cas = min ? `${min} min ${sek} s` : `${sek} s`;
    const odhad = zadani.minuty;
    const hodnoceni = cv.napoved === 0
      ? '<strong>Bez jediné nápovědy.</strong> Tohle už umíte sami.'
      : (cv.napoved <= 2
        ? '<strong>Skoro samostatně.</strong> Zkuste cvičení ještě jednou — podruhé to většinou jde bez nápovědy.'
        : '<strong>Zatím s nápovědou.</strong> Projděte si klidně nejdřív celý scénář a pak cvičení zopakujte.');
    card.dataset.color = 'red';
    card.classList.add('center');
    card.innerHTML = `
      <div class="head"><div class="scen">Cvičení dokončeno</div><button class="x" data-a="cvzavri" title="Zavřít" aria-label="Zavřít">${ik('zavrit')}</button></div>
      <h3 id="icop2-step-title" style="margin-top:12px">${escHtml(zadani.titulek)}</h3>
      <div class="cvres">
        <div class="cvr"><span class="k">Čas</span><span class="v">${cas}</span><span class="p">orientačně ${odhad} min</span></div>
        <div class="cvr"><span class="k">Nápověda</span><span class="v">${cv.napoved}×</span><span class="p">čím míň, tím líp</span></div>
        <div class="cvr"><span class="k">Klik mimo</span><span class="v">${cv.chyby}×</span><span class="p">kliknutí jinam, než krok mířil</span></div>
      </div>
      <div class="txt">${hodnoceni}</div>
      <div class="btns"><span class="sp"></span>
        <button class="b ghost" data-a="cvzavri">Zavřít</button>
        <button class="b ghost" data-a="cvmenu">Další cvičení</button>
        <button class="b main" data-a="cvznovu" data-cv="${escHtml(zadani.id)}">${ik('obnovit')}Zkusit znovu</button></div>`;
    card.classList.remove('hidden');
    card.style.left = Math.round(Math.max(8, (innerWidth - (card.offsetWidth || 440)) / 2)) + 'px';
    card.style.top = '110px';
  }

  // Karta cvičení — místo instrukce jen zadání. Nápovědu si uživatel vyžádá.
  function cvKartaHtml() {
    const zadani = cvNajdi(engine.cv.id) || {};
    const celkem = engine.cv.doIdx - (engine.steps.findIndex((s) => s.id === (cvNajdi(engine.cv.id) || {}).od)) + 1;
    const poradi = engine.idx - engine.steps.findIndex((s) => s.id === zadani.od) + 1;
    const napoveda = engine.cv.napovedaTed;
    // Kroky, které se v běžném průvodci posouvají tlačítkem „Další", potřebují
    // potvrzení i tady — jinak by v nich uživatel uvízl. Popisek je záměrně
    // neutrální („Mám hotovo"), aby neprozrazoval, co se po něm chce.
    // Brána zůstává v platnosti: dokud nejsou pole vyplněná, potvrdit nejde.
    const potvrzeni = engine.step.next !== false;
    const zamceno = isGated(engine.step) && !engine.unlocked;
    return `
      <div class="head"><div class="scen">Cvičení — ${escHtml(zadani.skupina || '')}</div>
        <button class="x" data-a="cvzavri" title="Ukončit cvičení" aria-label="Ukončit cvičení">${ik('zavrit')}</button></div>
      <div class="pmeta"><span class="pstep">Úkol ${Math.max(1, poradi)} z ${Math.max(1, celkem)}</span></div>
      <h3 id="icop2-step-title">${typografie(escHtml(zadani.titulek || ''))}</h3>
      <div class="txt cvzad">${textKroku(zadani.zadani)}</div>
      ${napoveda ? `<div class="cvnap"><strong>Nápověda:</strong> ${textKroku(engine.step.text)}</div>` : ''}
      ${engine.helpOpen === 'sos' ? sosAskHtml() : (engine.helpOpen ? helpPaneHtml() : '')}
      ${potvrzeni && zamceno ? '<div class="gate">' + ik('zamek') + '<span>Vyplňte, co k tomuto úkolu patří — potom lze potvrdit.</span></div>' : ''}
      <div class="tools">
        ${napoveda ? '' : '<button class="b mini" data-a="cvnapoveda">' + ik('napoveda') + 'Napovědět</button>'}
        <button class="b mini" data-a="help" title="Kód kroku a kontakt na hotlinku">${ik('podpora')}Pomoc</button>
        <button type="button" class="codeq" data-a="help" title="Kód kroku pro hotlinku">${stepCode()}</button>
      </div>
      <div class="btns">
        <span class="sp"></span>
        <button class="b ghost" data-a="cvzavri">Ukončit cvičení</button>
        ${potvrzeni ? `<button class="b main" data-a="next" ${zamceno ? 'disabled' : ''}>Mám hotovo</button>` : ''}
      </div>`;
  }

  // ---------------- výuka: role, výsledky, zadání ----------------
  // Doplněk nemá server a mít ho nebude — postup i výsledky zůstávají
  // v prohlížeči uživatele. Předání mezi učněm a mistrem proto jde přes
  // KÓD, který se dá zkopírovat, poslat chatem nebo nadiktovat. Je to stejný
  // nápad jako kód kroku pro hotlinku: krátký text místo účtu a přihlašování.
  const KOD_HLAVICKA = 'ICT2';

  function kodZapis(typ, data) {
    try {
      const json = JSON.stringify({ t: typ, v: 1, d: data });
      const bajty = new TextEncoder().encode(json);
      let bin = '';
      bajty.forEach((b) => { bin += String.fromCharCode(b); });
      return KOD_HLAVICKA + ':' + btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    } catch (e) { return ''; }
  }

  function kodCti(text) {
    try {
      const cast = String(text || '').trim().replace(/\s+/g, '');
      const i = cast.indexOf(':');
      if (i < 0 || cast.slice(0, i) !== KOD_HLAVICKA) return null;
      let b64 = cast.slice(i + 1).replace(/-/g, '+').replace(/_/g, '/');
      while (b64.length % 4) b64 += '=';
      const bin = atob(b64);
      const bajty = Uint8Array.from(bin, (c) => c.charCodeAt(0));
      const obj = JSON.parse(new TextDecoder().decode(bajty));
      return (obj && obj.t && obj.v === 1) ? obj : null;
    } catch (e) { return null; }
  }

  // Souhrn pro učně i mistra. Počítá se ze stejných dat, aby si obě strany
  // nemohly protiřečit.
  function cvSouhrn(hotova) {
    const h = hotova || state.cvHotova || {};
    const dostupna = CVICENI.filter((cv) => {
      const sc = DATA.scenarios.find((s) => s.id === cv.scenar);
      return sc && sc.available;
    });
    const zkusena = dostupna.filter((cv) => h[cv.id]);
    const bezNapovedy = zkusena.filter((cv) => h[cv.id].napoved === 0);
    const sekundy = zkusena.reduce((s, cv) => s + (h[cv.id].sekundy || 0), 0);
    const napoved = zkusena.reduce((s, cv) => s + (h[cv.id].napoved || 0), 0);
    return { celkem: dostupna.length, zkusena: zkusena.length, bezNapovedy: bezNapovedy.length, sekundy, napoved };
  }

  const cas = (s) => (s >= 60 ? `${Math.floor(s / 60)} min ${s % 60} s` : `${s} s`);

  function cvVysledkyHtml(hotova, kdo) {
    const h = hotova || state.cvHotova || {};
    const s = cvSouhrn(h);
    const cizi = !!hotova;   // prohlížíme výsledky někoho jiného
    const radky = CVICENI.map((cv) => {
      const sc = DATA.scenarios.find((x) => x.id === cv.scenar);
      if (!sc || !sc.available) return '';
      const z = h[cv.id];
      return `<div class="cvrad ${z ? '' : 'ne'}">
        <span class="t">${escHtml(cv.titulek)}</span>
        ${z ? `<span class="v">${cas(z.sekundy || 0)}</span>
               <span class="n ${z.napoved === 0 ? 'ok' : ''}">${z.napoved === 0 ? 'bez nápovědy' : z.napoved + '× nápověda'}</span>`
            : '<span class="v">—</span><span class="n">nezkoušeno</span>'}
      </div>`;
    }).join('');
    return `<div class="wsub">${cizi
      ? `Výsledky, které vám poslal <strong>${escHtml(kdo || 'učeň')}</strong>.`
      : 'Přehled vašich cvičení. Čas ani počet nápověd nikam neodchází — zůstávají ve vašem prohlížeči.'}
      </div>
      <div class="cvsouhrn">
        <div class="cvr"><span class="k">Zvládnuto</span><span class="v">${s.zkusena} z ${s.celkem}</span></div>
        <div class="cvr"><span class="k">Bez nápovědy</span><span class="v">${s.bezNapovedy}</span></div>
        <div class="cvr"><span class="k">Celkový čas</span><span class="v">${cas(s.sekundy)}</span></div>
      </div>
      <div class="wlist cvlist">${radky}</div>
      <div class="wdemo">${cizi
        ? '<button type="button" class="dstart" data-a="cvzpet">← Zpět na cvičení</button>'
        : `<button type="button" class="dstart cv" data-a="cvodeslat">Předat výsledky mistrovi
             <span>Vyrobí kód, který zkopírujete a pošlete — žádné přihlašování ani účet</span></button>
           <button type="button" class="dstart" data-a="cvzpet">← Zpět na cvičení</button>`}</div>`;
  }

  // Pole pro vložení kódu — jedno pro výsledky učně i pro zadání od mistra,
  // typ se pozná z kódu samotného.
  function cvKodHtml() {
    return `<div class="wform">
      <label for="cv-kod">Vložte kód</label>
      <input id="cv-kod" type="text" autocomplete="off" spellcheck="false" placeholder="${KOD_HLAVICKA}:…">
      <div class="hint">Kód dostanete od učně (jeho výsledky) nebo od mistra (co máte procvičit).
        Průvodce sám pozná, o co jde.</div>
      <div class="hint" data-kodstav></div>
      <div class="wact">
        <button type="button" class="b main" data-a="cvkodnacti">Načíst</button>
        <button type="button" class="b ghost" data-a="cvzpet">Zpět</button>
      </div>
    </div>`;
  }

  function cvUkazKod(kod, popis) {
    engine.cvPohled = 'kod';
    engine.cvKodText = kod;
    engine.cvKodPopis = popis;
    openWelcome();
  }

  function cvKodVenHtml() {
    return `<div class="wform">
      <label for="cv-kod-ven">${escHtml(engine.cvKodPopis || 'Kód')}</label>
      <input id="cv-kod-ven" type="text" readonly value="${escHtml(engine.cvKodText || '')}">
      <div class="hint">Zkopírujte ho a pošlete (e-mailem, chatem, jak chcete). Druhá strana ho vloží
        v <strong>Cvičení → Načíst kód</strong>.</div>
      <div class="hint" data-kodstav></div>
      <div class="wact">
        <button type="button" class="b main" data-a="cvkodkopie">${ik('kopirovat')}Zkopírovat</button>
        <button type="button" class="b ghost" data-a="cvzpet">Hotovo</button>
      </div>
    </div>`;
  }

  // ---------------- životní cyklus kroku ----------------
  // jumpFrom: { idx, title } — krok se zobrazuje jen kvůli shodě s adresou,
  // uložený postup je jinde. Karta na to musí upozornit (jinak by např.
  // „Zakázka vytvořena“ tvrdilo něco, co se nestalo).
  function showStep(i, jumpFrom) {
    // Cvičení končí svým posledním krokem. Hlídat to jen v next() nestačí —
    // uložení klienta naviguje na jinou stránku a engine se pak dostane dál
    // přes obnovení podle adresy, které next() vůbec neprojde.
    if (engine.cv && i > engine.cv.doIdx) { cvKonec(true); return; }
    cleanupStep();
    const sc = activeScenario();
    if (!sc) return;
    engine.scenario = sc;
    engine.steps = sc.steps;
    engine.idx = i;
    engine.step = sc.steps[i];
    engine.stage = 1;
    engine.jumpFrom = jumpFrom || null;
    engine._path = currentPath();
    engine.fallbackNext = false;
    engine.targetMissing = false;
    engine.helpOpen = false;
    engine.celyText = false;
    // ručně přetažená karta platí jen pro krok, u kterého ji uživatel odsunul
    engine.rucniPoloha = null;
    card.classList.remove('tazena');
    engine.unlocked = !isGated(engine.step);
    engine._autoTicks = 0;
    // před-nastavit viditelnost hlídaného prvku hned (ne až v prvním ticku) —
    // rychle zavřený modal by jinak watcher nikdy nezaznamenal
    const adv = engine.step.advance || {};
    engine._hiddenWasVisible = adv.hidden ? isVisible(findEl(adv.hidden)) : false;
    engine._hiddenTicks = 0;
    engine._hiddenGoneTicks = 0;
    // Návrat tlačítkem Zpět platí pro KROK, ne pro jedno vykreslení karty:
    // stejný krok se překresluje i sám od sebe (obnovení stavu) a značka by
    // se tím ztratila. Maže ji až přechod na jiný krok.
    if (engine._userBackIdx !== i) engine._userBackIdx = null;
    engine._notFoundTicks = 0;
    engine._stageBackTicks = 0;
    engine._gateMissingTicks = 0;
    engine._demoKliku = 0;          // kolikrát prezentace klikla na „Přidat řádek"
    engine._demoPokusu = 0;         // pokusy prezentace o posun v této fázi
    engine._demoPokusPodpis = '';
    engine._demoPodepsano = false;
    if (engine.cv) engine.cv.napovedaTed = false;   // nápověda platí jen pro krok, kde se vyžádala
    buildCard();
    renderSpotlight();
    positionCard();
    positionCard(); // druhé volání: karta už je v DOM → přesné rozměry (poučení z v1)
    // srolovat cíl do zorného pole
    const el = findVisible(engine.step.target);
    if (el) { try { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { /* */ } }
    engine._timer = setInterval(tick, TICK_MS);
    tick(); // první vzorek hned — rychlejší detekce fáze then i advance podmínek
    demoNaplanuj();
  }

  function cleanupStep() {
    if (engine._timer) { clearInterval(engine._timer); engine._timer = null; }
    demoZrus();
    vlnaStop();
    engine.step = null;
    engine.jumpFrom = null;
    clearHoles();
    // display:none video NEpozastaví — zastavit explicitně, jinak hraje zvuk dál
    const vid = card.querySelector('video');
    if (vid) { try { vid.pause(); vid.removeAttribute('src'); vid.load(); } catch (e) { /* */ } }
    card.innerHTML = '';
    mimoObraz(false);   // ať se schování cíle nepřenese na další krok
    spot.classList.add('hidden');
    card.classList.add('hidden');
    beak.classList.add('hidden');
  }

  function hideAll() { cleanupStep(); }

  function tick() {
    const step = engine.step;
    if (!step) return;

    // adresa se změnila bez načtení stránky (history.pushState apod.).
    // Překreslujeme jen tehdy, když krok na nové adrese už nedává smysl —
    // jinak by změna query parametru zbytečně restartovala celý krok.
    const path = currentPath();
    if (path !== engine._path) {
      engine._path = path;
      if (!stepMatchesUrl(step)) { resume(); return; }
      scheduleHealthCheck(1500);
    }

    // fáze 2 — „then" cíl se objevil (rozbalené menu, modal)
    if (step.then && engine.stage === 1 && findVisible(step.then.target)) {
      engine.stage = 2;
      engine._stageBackTicks = 0;
      buildCard();
      const el = findVisible(step.then.target);
      if (el) { try { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { /* */ } }
      demoNaplanuj();   // druhá fáze má vlastní cíl — prezentace klikne znovu
    } else if (step.then && engine.stage === 2 && !findVisible(step.then.target)) {
      // „then" cíl zase zmizel (menu se zavřelo) → vrátit se k instrukci fáze 1
      engine._stageBackTicks++;
      if (engine._stageBackTicks >= 3) {
        engine.stage = 1;
        engine._stageBackTicks = 0;
        buildCard();
      }
    } else {
      engine._stageBackTicks = 0;
    }

    // rozbalený našeptávač → vlna přes položky (jen kroky, které si o ni řeknou)
    vlnaTick(step);

    const a = step.advance || {};

    // Během čekání na otevření modalu ještě nejde o chybějící cíl.
    let hiddenCeka = false;
    // advance: prvek zmizel (zavřel se modal)
    if (a.hidden) {
      const el = findEl(a.hidden);
      const vis = el ? isVisible(el) : false;
      if (vis) { engine._hiddenWasVisible = true; engine._hiddenTicks = 0; engine._hiddenGoneTicks = 0; }
      else if (engine._hiddenWasVisible) {
        engine._hiddenTicks++;
        if (engine._hiddenTicks >= 2) { next(); return; }
      } else if (engine._userBackIdx !== engine.idx && !findVisible(step.target)) {
        // Okno bylo zavřené UŽ KDYŽ krok začal. Typicky po uložení vozidla:
        // IC Office stránku znovu načte, průvodce se obnoví na tomhle kroku
        // a okno, jehož zmizení má hlídat, se tu už nikdy neotevře. Dřív tu
        // zůstal viset s hláškou „místo na stránce není“, přestože bylo
        // hotovo — teď pokračuje sám (u vozidla na krok „Vyberte vozidlo“,
        // který ukazuje na vozidlo v seznamu).
        //
        // Čeká se ve dvou tempech, aby se neodsunul krok, který teprve začíná:
        //   • okno JE v DOM, jen skryté (bootstrap modal patří do stránky) →
        //     2 s; víc čekat není na co, otevírá se okamžitě,
        //   • okno v DOM není → 6 s, tedy až v okamžiku, kdy engine i jinde
        //     přestává na cíl čekat; dotahovaný modal se do té doby objeví.
        // Cíl kroku navíc nesmí být vidět (na tlačítko na stránce se čeká) a
        // návrat tlačítkem „← Zpět“ posun vypíná — tam se uživatel vrátil
        // právě proto, aby si okno otevřel znovu.
        hiddenCeka = true;
        engine._hiddenGoneTicks++;
        if (engine._hiddenGoneTicks >= (el ? 6 : 18)) { next(); return; }
      } else {
        engine._hiddenGoneTicks = 0;
      }
    }

    // advance: prvek se objevil
    if (a.visible && findVisible(a.visible)) { next(); return; }

    // gated / auto vyplnění
    if (a.filled || a.filledAny) {
      const ok = gateSatisfied(step);
      if (a.auto) {
        // Automatický posun se počítá od chvíle, kdy jsou pole vyplněná —
        // jenže prezentace píše po znacích a už první písmeno vypadá jako
        // „vyplněno“. Bez téhle pojistky by engine posunul krok dřív, než
        // prezentace dopíše, a v ostrých datech by zůstal useknutý text.
        engine._autoTicks = (ok && !engine._demoPsani) ? engine._autoTicks + 1 : 0;
        if (engine._autoTicks >= 4) { next(); return; }
      } else if (ok !== engine.unlocked) {
        engine.unlocked = ok;
        buildCard();
      }
      // Pojistka proti driftu webu: když ŽÁDNÝ selektor hlídaných polí
      // neexistuje (změnila se stránka), tlačítko po ~6 s odemknout.
      //
      // POZOR: u kroků s dynamicky přidávanými řádky (materiál, práce) hlídaná
      // pole neexistují ZÁMĚRNĚ, dokud uživatel neklikne „Přidat materiál“.
      // Bez kotvy by pojistka odemkla bránu přesně v legitimním stavu a krok
      // „Materiál přidán →“ by šel odklikat bez jediné položky.
      // gateAnchor = prvek, který na správné stránce existuje vždy; dokud ho
      // vidíme, chybějící pole znamenají „uživatel ještě neklikl“, ne drift.
      if (!engine.unlocked && !a.auto) {
        const groups = a.filled || a.filledAny || [];
        const anyEl = groups.some((g) => g.some((s) => {
          try { return !!document.querySelector(s); } catch (e) { return false; }
        }));
        const anchorEl = a.gateAnchor ? findEl(a.gateAnchor) : null;
        if (!anyEl && !anchorEl) {
          engine._gateMissingTicks++;
          if (engine._gateMissingTicks >= 18) {
            engine.unlocked = true;
            recordMiss(engine.scenario, step, 'gate');
            buildCard();
          }
        } else {
          engine._gateMissingTicks = 0;
        }
      }
    }

    // Cíl kroku na stránce není. Dvě různě rychlé reakce:
    //  ~2 s → říct to uživateli a nabídnout návrat o krok (typicky zavřel okno
    //         fakturace / vozidla a zůstal by s návodem k oknu, které tam není)
    //  ~6 s → zapsat do health-checku a u kroků bez tlačítka Další nabídnout
    //         nouzové „Pokračovat i tak“ (spíš změna webu než chyba uživatele)
    if (step.kind !== 'info' && !hiddenCeka) {
      if (!findVisible(step.target)) {
        engine._notFoundTicks++;
        if (engine._notFoundTicks === 6 && !engine.targetMissing) {
          engine.targetMissing = true;
          buildCard();
        }
        if (engine._notFoundTicks === 18) {
          recordMiss(engine.scenario, step, 'target');
          if (step.next === false && !engine.fallbackNext) { engine.fallbackNext = true; buildCard(); }
        }
      } else {
        engine._notFoundTicks = 0;
        if (engine.targetMissing) { engine.targetMissing = false; buildCard(); }
      }
    }

    renderSpotlight();
    positionCard();
  }

  function next() {
    if (!state.active) return;
    const ni = engine.idx + 1;
    // Konec scénáře uzavřít DŘÍV, než se uloží index mimo rozsah. Kdyby se
    // karta zavřela mezi oběma asynchronními zápisy, zůstal by uložený
    // neplatný index a po reloadu by uživatel viděl „Hotovo!“ znovu —
    // scénář by se nikdy neoznačil jako dokončený.
    if (ni >= engine.steps.length) { finish(); return; }
    // Cvičení končí svým posledním krokem, ne koncem celého scénáře.
    if (cvBezi() && engine.idx >= engine.cv.doIdx) { cvKonec(true); return; }
    state.active.step = ni;
    saveState();
    if (stepMatchesUrl(engine.steps[ni])) showStep(ni);
    else {
      // další krok žije na jiné adrese — místo tichého zmizení řekneme kam jít
      hideAll();
      showWaitCard(engine.steps[ni]);
    }
  }

  function skip() {
    const stepId = engine.step && engine.step.skipTo;
    if (!stepId) { next(); return; }
    const ni = engine.steps.findIndex((step) => step.id === stepId);
    if (ni < 0) { next(); return; }
    state.active.step = ni;
    saveState();
    if (stepMatchesUrl(engine.steps[ni])) showStep(ni);
    else {
      hideAll();
      showWaitCard(engine.steps[ni]);
    }
  }

  // Karta „průvodce čeká" — krok patří na jinou stránku
  function showWaitCard(step) {
    if (!step) return;
    clearHoles();
    spot.classList.add('hidden');
    beak.classList.add('hidden');
    const pat = (step.url || []).find((p) => p && p !== '*');
    card.dataset.color = 'red';
    card.classList.add('center');
    card.innerHTML = `
      <div class="head"><div class="scen">${engine.scenario ? engine.scenario.title : 'Průvodce'}</div><button class="x" data-a="close" title="Skrýt průvodce" aria-label="Skrýt průvodce">${ik('zavrit')}</button></div>
      <h3 id="icop2-step-title" style="margin-top:12px">Průvodce čeká</h3>
      <div class="txt">Krok „<strong>${step.title || ''}</strong>“ patří na jinou stránku${pat ? ` (adresa <strong>${pat.replace(/\*/g, '…')}</strong>)` : ''}.
        Přejděte tam a průvodce naskočí sám — nebo ho otevřete tlačítkem <strong>Průvodce</strong> vpravo dole.</div>
      ${demoBezi() ? demoBarHtml() : ''}
      <div class="btns"><span class="sp"></span><button class="b ghost" data-a="close">Zavřít</button></div>`;
    card.classList.remove('hidden');
    card.style.left = Math.round(Math.max(8, (innerWidth - (card.offsetWidth || 440)) / 2)) + 'px';
    card.style.top = '110px';
  }

  // Krok, jehož okno je zavřené UŽ PŘI OBNOVENÍ kroku, je hotový — jen ho
  // nikdo neviděl dokončit. Sledovač v ticku by ho posunul až za dvě sekundy
  // a uživatel by po uložení vozidla viděl probliknout návod „Uložte vozidlo“.
  // Tady se rozhodne DŘÍV, než se karta vykreslí, takže nebliká nic.
  //
  // Po načtení stránky je to bezpečné: zavřené okno se samo neotevře a
  // rozdělaný modal reload nepřežije. Když prvek okna v DOM vůbec není,
  // nerozhodujeme se — může se teprve dotahovat a od toho je sledovač.
  function preskocHotove(sc, i) {
    let j = i;
    for (let guard = 0; guard < 5; guard++) {
      const step = sc.steps[j];
      const adv = (step && step.advance) || {};
      if (!adv.hidden) break;
      // Vědomý návrat tlačítkem Zpět má přednost — tam se uživatel vrátil
      // právě proto, aby si okno otevřel znovu.
      if (engine._userBackIdx === j) break;
      const el = findEl(adv.hidden);
      if (!el || isVisible(el) || findVisible(step.target)) break;
      if (j + 1 >= sc.steps.length || !stepMatchesUrl(sc.steps[j + 1])) break;
      j++;
    }
    if (j !== i) { state.active.step = j; saveState(); }
    return j;
  }

  function prev() {
    const j = prevMatchingIdx();
    if (j === null) return;
    state.active.step = j;
    saveState();
    // Vědomý návrat zpět. Kroky, které se posouvají zmizením okna, se na něm
    // nesmí samy odsunout dopředu — uživatel se sem vrátil právě proto, aby
    // si okno otevřel znovu.
    //
    // Drží se ČÍSLO KROKU, ne pravda/nepravda, a nastavuje se PŘED showStep.
    // Booleovská značka za showStep vydržela jen do nejbližšího překreslení
    // kroku (obnovení stavu, cizí zápis do úložiště) — na živé stránce se to
    // stalo do dvou sekund a průvodce uživatele hned zase odsunul dopředu.
    engine._userBackIdx = j;
    showStep(j);
  }

  // Návrat z „přeskočeného“ kroku zpět na skutečně uložený krok. Když je na
  // jiné adrese, ukážeme kartu s tím, kam má uživatel jít.
  function backToSavedStep() {
    const jump = engine.jumpFrom;
    const sc = activeScenario();
    if (!jump || !sc || !sc.steps[jump.idx]) return;
    if (stepMatchesUrl(sc.steps[jump.idx])) { showStep(jump.idx); return; }
    hideAll();
    engine.scenario = sc;
    engine.steps = sc.steps;
    showWaitCard(sc.steps[jump.idx]);
  }

  function finish() {
    const sc = activeScenario();
    if (sc) state.done[sc.id] = true;
    state.active = null;
    // Prezentaci je běžné pouštět několikrát za sebou (další skupina, jiný
    // posluchač). Místo tichého konce proto nabídneme spuštění znovu — se
    // stejným tempem, které si přednášející naladil.
    const bylaPrezentace = demoBezi();
    const tempo = bylaPrezentace ? Object.assign({}, state.demo) : null;
    demoZrus();
    demoZnacka(false);
    state.demo = null;
    engine.demoCeka = '';
    saveState();
    hideAll();
    if (bylaPrezentace) {
      engine.demoPauzaVolba = tempo.pauza;
      engine.demoHlasVolba = tempo.hlas;
      engine.demoVyber = tempo.scenar || engine.demoVyber;   // opakovat TENTÝŽ scénář
      showDemoAgainCard();
    }
  }

  // Karta po dojetí prezentace — opakování na jedno kliknutí.
  function showDemoAgainCard() {
    clearHoles();
    spot.classList.add('hidden');
    beak.classList.add('hidden');
    card.dataset.color = 'red';
    card.classList.add('center');
    card.innerHTML = `
      <div class="head"><div class="scen">Prezentace</div><button class="x" data-a="close" title="Zavřít" aria-label="Zavřít">${ik('zavrit')}</button></div>
      <h3 id="icop2-step-title" style="margin-top:12px">Prezentace dojela</h3>
      <div class="txt">Ukázkový průchod je u konce. Vzniklé záznamy poznáte podle slova
        <strong>UKÁZKA</strong> v názvu — až je nebudete potřebovat, smažte je.<br><br>
        Chcete ji pustit znovu? Spustí se od začátku se stejným tempem
        (<strong>${demoPauzaPlatna(engine.demoPauzaVolba)} s</strong> mezi kroky) a vytvoří <strong>další</strong> ukázkové záznamy.</div>
      <div class="btns"><span class="sp"></span>
        <button class="b ghost" data-a="close">Zavřít</button>
        <button class="b main" data-a="demoznovu">Spustit znovu</button></div>`;
    card.classList.remove('hidden');
    card.style.left = Math.round(Math.max(8, (innerWidth - (card.offsetWidth || 440)) / 2)) + 'px';
    card.style.top = '110px';
  }

  function pauseTour() {
    // Skrytí průvodce uživatel chápe jako konec, ne jako pauzu s automatickým
    // pokračováním — prezentace se proto ukončí, ne uspí.
    demoUkonci();
    if (state.active) { state.active.paused = true; saveState(); }
    hideAll();
  }

  function startScenario(id) {
    const sc = DATA.scenarios.find((scenario) => scenario.id === id);
    if (!sc || !sc.available || !sc.steps.length) return;
    if (!scenarSplnen(sc)) return;   // zamčený scénář (viz vyzaduje)
    // Ukázková data jsou jen pro jeden scénář. Kdyby prezentace přežila přechod
    // jinam, klikala by naslepo v postupu, na který nebyla připravená.
    demoUkonci();
    state.active = { scenarioId: id, step: 0, stepId: sc.steps[0].id, paused: false };
    saveState();
    resume();
  }

  // Má krok konkrétní adresu? Kroky s url ["*"] (úvod, závěr) nesmí být cílem
  // auto-obnovení — jinak by odbočka mimo cestu skočila na „Hotovo!" a scénář
  // se falešně dokončil (kritický nález review).
  function hasSpecificUrl(step) {
    return (step.url || ['*']).some((p) => p && p !== '*');
  }

  function resume(fromUser) {
    hideAll();
    if (verejnaStranka()) return;   // odhlášení uprostřed scénáře postup nemaže
    if (!state.enabled || !state.active || state.active.paused) return;
    const sc = activeScenario();
    if (!sc || !sc.steps.length) { state.active = null; saveState(); return; }
    const i = state.active.step;
    if (i >= sc.steps.length) { finish(); return; }
    engine.scenario = sc; engine.steps = sc.steps;
    if (stepMatchesUrl(sc.steps[i])) { showStep(preskocHotove(sc, i)); return; }
    // auto-obnovení: najdi nejbližší KONKRÉTNÍ krok odpovídající aktuální adrese.
    // Přeskok se NEUKLÁDÁ — je jen zobrazovací; uložený zůstává poslední potvrzený
    // krok, takže návrat na původní stránku pokračuje tam, kde uživatel skončil.
    const jump = { idx: i, title: sc.steps[i].title || sc.steps[i].id };
    // Přeskok znamená, že jsme jinde, než kam postup došel — typicky u JINÉHO,
    // skutečného klienta nebo zakázky. Prezentace se tady musí zastavit;
    // jinak by automaticky klikala a ukládala do cizích ostrých dat.
    const skok = (j) => { demoUkonci(); showStep(j, jump); };
    for (let j = i + 1; j < sc.steps.length; j++) {
      if (hasSpecificUrl(sc.steps[j]) && stepMatchesUrl(sc.steps[j])) {
        skok(j);
        return;
      }
    }
    for (let j = i - 1; j >= 0; j--) {
      if (hasSpecificUrl(sc.steps[j]) && stepMatchesUrl(sc.steps[j])) {
        skok(j);
        return;
      }
    }
    // žádný krok tu nedává smysl — spíme; na výslovné přání ukážeme kam jít
    if (fromUser) showWaitCard(sc.steps[i]);
  }

  // ---------------- kliknutí (postup dál) ----------------
  function advanceFromClick(step) {
    const prevIdx = engine.idx;
    const ni = prevIdx + 1;
    if (ni >= engine.steps.length) { finish(); return; }   // viz poznámka v next()
    if (cvBezi() && prevIdx >= engine.cv.doIdx) { cvKonec(true); return; }   // konec cvičení
    // uložit hned (kdyby klik navigoval pryč), pak posunout
    state.active.step = ni;
    saveState();
    setTimeout(() => {
      if (!engine.step || engine.step !== step) return; // už se posunulo / odešli jsme
      if (stepMatchesUrl(engine.steps[ni])) { showStep(ni); return; }
      // další krok je na jiné adrese — čekáme na navigaci. Když nepřijde
      // (formulář neprošel validací a stránka zůstala), vrátíme krok zpět,
      // jinak by průvodce beze slova zmizel se stavem o krok napřed.
      hideAll();
      setTimeout(() => {
        if (!state.active || state.active.step !== ni || engine.step) return;
        state.active.step = prevIdx;
        saveState();
        showStep(prevIdx);
      }, 2400);
    }, 150);
  }

  window.addEventListener('click', (e) => {
    const path = e.composedPath();
    // FAB menu se zavře klikem kamkoli mimo něj
    if (!fmenu.classList.contains('hidden') && !path.includes(fmenu) && !path.includes(fab)) closeFabMenu();
    const step = engine.step;
    if (!step || !tourVisible()) return;
    if (path.includes(host)) return; // klik v našem UI
    const a = step.advance || {};
    let sels = [];
    if (a.click) sels = sels.concat(a.click);
    // kroky s pasivním postupem (modal se zavře / prvek se objeví / auto-vyplnění)
    // klikem NEposouvat — postup řídí watcher, klik je jen akce na stránce
    const passive = !!(a.hidden || a.visible || (a.auto && (a.filled || a.filledAny)));
    if (!passive) {
      if (step.then) sels = sels.concat(step.then.target);
      else if (step.kind === 'click') sels = sels.concat(Array.isArray(step.target) ? step.target : [step.target]);
    }
    if (!sels.length) return;
    // zamčený krok (nevyplněná pole) klik neposune
    if (isGated(step) && !gateSatisfied(step)) return;
    const t = e.target;
    for (const s of sels) {
      try {
        if (t.closest && t.closest(s)) { advanceFromClick(step); return; }
      } catch (err) { /* neplatný selektor */ }
    }
    // Ve cvičení si počítáme kliknutí mimo očekávané místo. Nejde o chybu
    // uživatele v pravém slova smyslu — jen o vodítko, kde tápal.
    if (cvBezi() && t.closest && t.closest('a, button, input, select, textarea, [role="button"]')) {
      engine.cv.chyby++;
    }
  }, true);

  // akce v kartě
  let actionLockAt = 0;
  card.addEventListener('click', (e) => {
    const b = e.target.closest('[data-a]');
    if (!b) return;
    const act = b.dataset.a;
    if (act === 'next' || act === 'skip' || act === 'prev' || act === 'demonext') {
      // ochrana proti dvojkliku — druhý klik by přeskočil krok bez přečtení
      // (250 ms: blokuje dvojklik, nebrzdí záměrné rychlé proklikávání)
      const now = Date.now();
      if (now - actionLockAt < 250) return;
      actionLockAt = now;
    }
    if (act === 'demoznovu') { hideAll(); demoStart(); return; }
    if (act === 'cvnapoveda') {
      if (!cvBezi()) return;
      engine.cv.napoved++;
      engine.cv.napovedaTed = true;
      buildCard(); renderSpotlight(); positionCard(); positionCard();
      return;
    }
    if (act === 'cvzavri') { cvKonec(false); return; }
    if (act === 'cvznovu') { const id = b.dataset.cv; hideAll(); cvStart(id); return; }
    if (act === 'cvmenu') { hideAll(); engine.cvSeznam = true; openWelcome(); return; }
    // ---- režim správce ----
    if (act === 'edit') { engine.editorOpen = !engine.editorOpen; buildCard(); positionCard(); return; }
    if (act === 'editZavrit') { engine.editorOpen = false; buildCard(); positionCard(); return; }
    if (act === 'editUlozit') { editorUlozit(); return; }
    if (act === 'editCil') {
      vyberStart((el) => {
        const sel = navrhniSelektor(el);
        const p = plnyKrok();
        buildCard();
        const s = card.querySelector('[data-estav]');
        if (!sel) {
          if (s) s.textContent = 'Prvek nemá stabilní adresu — zkuste jiný (nejlépe s id, name nebo placeholder).';
          positionCard();
          return;
        }
        engine.step.target = [sel];
        if (p && p.st) p.st.target = [sel];
        clearHoles();
        renderSpotlight();
        positionCard();
        if (s) s.innerHTML = '<span class="ok">' + ik('hotovo') + 'Nový cíl kroku:</span> ' + escHtml(sel);
      }, 'Klikněte na prvek, na který má tento krok ukazovat.');
      return;
    }
    if (act === 'editNovy') {
      vyberStart((el) => {
        const sel = navrhniSelektor(el);
        const p = plnyKrok();
        if (!sel || !p) {
          buildCard(); positionCard();
          const s = card.querySelector('[data-estav]');
          if (s) s.textContent = 'Prvek nemá stabilní adresu — nový krok nevznikl. Zkuste jiný prvek.';
          return;
        }
        const novy = {
          id: 'u' + Date.now().toString(36),
          kind: 'note',
          url: [currentPath().split('?')[0] + '*'],
          title: 'Nový krok',
          text: 'Popište, co tu má uživatel udělat — text upravíte v editoru.',
          target: [sel],
          label: '',
          next: 'Další →'
        };
        const i = p.sc.steps.findIndex((k) => k.id === engine.step.id);
        p.sc.steps.splice(i + 1, 0, novy);
        editorPrekresli(novy.id);
      }, 'Klikněte na prvek, na který má NOVÝ krok ukazovat.');
      return;
    }
    if (act === 'close') pauseTour();
    else if (act === 'next') { if (!b.disabled) next(); }
    else if (act === 'skip') skip();
    else if (act === 'prev') prev();
    else if (act === 'backjump') backToSavedStep();
    else if (act === 'help') { engine.helpOpen = engine.helpOpen ? false : 'help'; buildCard(); positionCard(); }
    else if (act === 'sosask') { engine.helpOpen = 'sos'; engine.sosVysledek = ''; buildCard(); positionCard(); }
    else if (act === 'sosno') { engine.helpOpen = 'help'; buildCard(); positionCard(); }
    else if (act === 'sosyes') sendSupport();
    else if (act === 'demoauto') {
      if (!demoBezi()) return;
      state.demo.auto = state.demo.auto === false;
      engine.demoCeka = '';
      saveState();
      buildCard(); positionCard();
      demoNaplanuj();
    } else if (act === 'demonext') { engine.demoCeka = ''; buildCard(); positionCard(); demoProved(); }
    else if (act === 'demostop') demoStop();
    else if (act === 'demominus' || act === 'demoplus') {
      if (!demoBezi()) return;
      const krok = act === 'demoplus' ? 5 : -5;
      state.demo.pauza = demoPauzaPlatna(demoPauzaPlatna(state.demo.pauza) + krok);
      engine.demoPauzaVolba = state.demo.pauza;   // zapamatovat pro příště
      saveState();
      buildCard(); positionCard();
      demoNaplanuj();
    } else if (act === 'demohlas') {
      if (!demoBezi()) return;
      state.demo.hlas = !state.demo.hlas;
      engine.demoHlasVolba = state.demo.hlas;
      if (!state.demo.hlas) demoTicho(); else { engine._demoReceno = ''; }
      saveState();
      buildCard(); positionCard();
      demoNaplanuj();
    }
    else if (act === 'copydiag') copyDiag();
    else if (act === 'tisk') printScenario(engine.scenario || activeScenario());
    else if (act === 'hlasit') hlasitRozbite();
    else if (act === 'celytext') { engine.celyText = !engine.celyText; buildCard(); positionCard(); }
    else if (act === 'more') { const m = card.querySelector('.more'); if (m) m.classList.toggle('hidden'); positionCard(); }
    else if (act === 'video') {
      const v = card.querySelector('.vid');
      if (!v) return;
      if (v.classList.contains('hidden')) {
        v.innerHTML = `<video controls autoplay src="${engine.step.video}"></video>
          <div class="vid-err hidden">Video se nepodařilo načíst. Zkuste to prosím později.</div>`;
        // bez ošetření zůstane při 404 jen černý přehrávač bez vysvětlení
        const el = v.querySelector('video');
        el.addEventListener('error', () => {
          el.classList.add('hidden');
          const msg = v.querySelector('.vid-err');
          if (msg) msg.classList.remove('hidden');
          positionCard();
        }, { once: true });
        v.classList.remove('hidden');
      } else {
        v.innerHTML = '';
        v.classList.add('hidden');
      }
      positionCard();
    }
  });

  // přizpůsobení pauzy délce textu
  card.addEventListener('change', (e) => {
    const chk = e.target.closest('[data-a="demodle"]');
    if (!chk || !demoBezi()) return;
    state.demo.dleTextu = !!chk.checked;
    saveState();
    buildCard(); positionCard();
    demoNaplanuj();
  });

  // živý náhled úprav v režimu správce (text, barva, štítek, šířka)
  let editTimer = null;
  card.addEventListener('input', (e) => {
    const pole = e.target.closest && e.target.closest('[data-e]');
    if (!pole || !SPRAVA || !engine.step) return;
    clearTimeout(editTimer);
    const co = pole.dataset.e;
    editTimer = setTimeout(() => editorPouzijPole(co, pole), 350);
  });
  card.addEventListener('change', (e) => {
    if (!SPRAVA) return;
    const pole = e.target.closest && e.target.closest('[data-e]');
    if (pole && engine.step) { clearTimeout(editTimer); editorPouzijPole(pole.dataset.e, pole); return; }
    const videa = e.target.closest && e.target.closest('[data-evidea]');
    if (videa) {
      // vypínač videí pro uživatele — FORMAT.md §1, pole `videa`
      zajistiPlny().videa = !!videa.checked;
      DATA.videa = !!videa.checked;
      videa.blur();   // jinak by kurzor v editoru zablokoval přestavbu karty
      buildCard(); positionCard();
      return;
    }
    const krok = e.target.closest && e.target.closest('[data-ekrok]');
    if (krok) editorVynechani(krok.dataset.ekrok, !krok.checked);
  });

  // ---------------- uvítací menu (rozcestník) ----------------
  let welcomeReturnFocus = null;

  function openWelcome() {
    const focused = root.activeElement;
    welcomeReturnFocus = focused && !fmenu.contains(focused) ? focused : fab;
    closeFabMenu();
    const rows = DATA.scenarios.map((sc, i) => {
      const odemceno = scenarSplnen(sc);
      const usable = sc.available && sc.steps.length && odemceno;
      let badge;
      if (sc.available && sc.steps.length && !odemceno) {
        badge = '<span class="badge lock">' + ik('zamek') + 'Nejdřív vystavte fakturu</span>';
      } else if (!usable) badge = '<span class="badge soon">Připravujeme</span>';
      else if (state.active && state.active.scenarioId === sc.id) badge = `<span class="badge cont">Pokračovat ${state.active.step + 1}/${sc.steps.length}</span>`;
      else if (state.done[sc.id]) badge = '<span class="badge done">' + ik('hotovo') + 'Dokončeno</span>';
      else badge = '<span class="badge go">Spustit</span>';
      // Rozdělaný scénář se dosud dal jen dokončit. Kdo postup zapomněl,
      // neměl jak se vrátit na začátek — proto tlačítko vedle. Je zvlášť,
      // ne uvnitř řádku: tlačítko v tlačítku není platné HTML a klávesnice
      // by se na něj nedostala.
      const rozdelany = usable && state.active && state.active.scenarioId === sc.id;
      const znovu = usable && (rozdelany || state.done[sc.id]);
      // odhad času na projití celého scénáře — ať uživatel ví, do čeho jde
      const minuty = usable ? ` <span class="min">${ik('cas')}asi ${odhadMinut(sc)} min</span>` : '';
      return `<div class="scen-radek">
        <button class="scen-item ${usable ? '' : 'dis'}" data-sc="${usable ? sc.id : ''}" ${usable ? '' : 'disabled'}>
          <span class="num">${i + 1}</span>
          <span class="st"><span class="t">${sc.title}</span><span class="d">${
            (sc.available && sc.steps.length && !odemceno && sc.vyzadujeText) ? escHtml(sc.vyzadujeText) : sc.desc}${minuty}</span></span>
          ${badge}</button>
        ${znovu ? `<button class="scen-znovu" data-scznovu="${escHtml(sc.id)}"
          title="Spustit ${escHtml(sc.title)} znovu od prvního kroku">${ik('obnovit')}Od začátku</button>` : ''}
      </div>`;
    }).join('');
    // Dokud není vyplněné zákaznické číslo Inter Cars a vybraný obchodní
    // specialista, ukáže se místo rozcestníku scénářů úvodní dotaz. Podle
    // čísla hotline pozná, s kým mluví; zbytek si dohledá sama.
    const chcemeKontakt = !hasIcNumber() || !specialistaZvolen();
    // Prezentace se nabízí až po vyplnění zákaznického čísla — dřív ne, ať
    // nový uživatel nespustí omylem něco, co mu do ostrých dat uloží záznamy.
    const cvTitulky = { vysledky: 'Moje výsledky', cizi: 'Výsledky učně', nacist: 'Načíst kód', kod: 'Kód k předání' };
    const titulek = engine.demoAsk ? 'Spustit prezentaci?'
      : (engine.uvitani ? 'Vítejte v IC Office'
        : (engine.cvSeznam ? (cvTitulky[engine.cvPohled] || 'Cvičení — procvičte si to sám')
          : `Vítejte v IC Office — Tutoriál ${UI_VERSION}`));
    // Panel má vlastní texty (rozcestník, seznam cvičení, výsledky) — sazba
    // se na ně musí pustit stejně jako na obsah kroků.
    welcome.innerHTML = typografie(`
      <div class="whead"><h2 id="icop2-welcome-title">${titulek}</h2><button class="x" data-a="close" aria-label="Zavřít nabídku průvodce">${ik('zavrit')}</button></div>
      ${engine.uvitani ? uvitaniHtml() : engine.demoAsk ? demoAskHtml() : (engine.cvSeznam ? cvPohledHtml() : (chcemeKontakt ? onboardingHtml() : `<div class="wsub">Vyberte situaci, kterou právě řešíte — nebo rovnou najděte konkrétní krok.
        <span class="lg"><span class="vz" aria-hidden="true"></span>vínový rámeček = povinný krok, <span class="vz yellow" aria-hidden="true"></span>žlutý rámeček = doporučení.</span></div>
      <div class="wsearch">
        <input id="w-hledat" type="search" autocomplete="off" spellcheck="false"
               placeholder="Co potřebujete udělat? Např. faktura, podpis, STK — nebo kód kroku OS-Z04">
        <div class="wres"></div>
      </div>
      <div class="wlist">${rows}</div>
      <div class="wcv"><button type="button" class="dstart cv" data-a="cvseznam">Cvičení — procvičit si to sám
        <span>Krátké úkoly bez nápovědy, 2–5 minut. Průvodce změří čas a zapíše, kdy jste potřebovali napovědět</span></button></div>
      <div class="wdemo">${demoBezi()
        ? `<button type="button" class="dstart bezi" data-a="demostop">Ukončit prezentaci
             <span>Prezentace právě běží — tímto ji zastavíte</span></button>`
        : `<button type="button" class="dstart" data-a="demoask">Spustit prezentaci
             <span>Průvodce si projde postup sám a u každého kroku vysvětlí, co dělá a proč</span></button>`}</div>`))}`);
    // Rozcestník je samostatná obrazovka, ne vrstva nad rozpracovaným krokem.
    // Dokud je otevřený, karta kroku ani vysvícení pod ním nesvítí — jinak
    // uživatel čte dvě věci naráz („vyplňte zákaznické číslo“ přes „Krok 3
    // z 31“) a není jasné, co po něm průvodce vlastně chce.
    zaOknem(true);
    welcome.classList.remove('hidden');
    wback.classList.remove('hidden');
    // Uvítací video: bez hlášky by při špatné adrese zůstal jen černý
    // přehrávač. A tlačítko Pokračovat se musí odemykat i podle specialisty.
    if (engine.uvitani) {
      const v = welcome.querySelector('.wvideo video');
      if (v) v.addEventListener('error', () => {
        v.classList.add('hidden');
        const err = welcome.querySelector('.wvideo .vid-err');
        if (err) err.classList.remove('hidden');
      }, { once: true });
    }
    onboardingOdemkni();
    requestAnimationFrame(() => (welcome.querySelector('.wform input') || welcome.querySelector('.scen-item:not([disabled])') || welcome.querySelector('[data-a="close"]') || welcome).focus());
  }

  // „Pokračovat →" v úvodním dotazu se odemkne, až je vyplněné zákaznické
  // číslo a (pokud obsah nějaké vede) vybraný obchodní specialista.
  function onboardingOdemkni() {
    const btn = welcome.querySelector('[data-a="contactSave"]');
    if (!btn) return;
    const pole = welcome.querySelector('#ob-ic');
    const cislo = !!(pole && pole.value.trim());
    const spec = !specialisteSeznam().length || !!welcome.querySelector('.spvol.on');
    btn.disabled = !cislo || !spec;
  }

  // Schová kartu kroku i vysvícení po dobu, co je otevřený rozcestník.
  // Vlastní třída, ne `mimo` — to si řídí schování při odrolování a dva
  // majitelé jedné třídy by se přebíjeli.
  function zaOknem(ano) {
    for (const el of [spot, labelsLayer, card, beak]) el.classList.toggle('zaoknem', ano);
  }

  function closeWelcome() {
    engine.demoAsk = false;
    engine.cvSeznam = false;
    engine.cvPohled = '';
    // schované okno (display:none) přehrávání NEzastaví — uvítací video by
    // hrálo dál naslepo
    const wv = welcome.querySelector('video');
    if (wv) { try { wv.pause(); } catch (e) { /* */ } }
    engine.uvitani = false;
    const wasOpen = !welcome.classList.contains('hidden');
    welcome.classList.add('hidden');
    wback.classList.add('hidden');
    zaOknem(false);
    // Po zavření se karta i rámečky musí usadit znovu — stránka se mezitím
    // mohla posunout a měřit se dá až po odkrytí.
    if (wasOpen && engine.step) { renderSpotlight(); positionCard(); }
    if (wasOpen) {
      const target = welcomeReturnFocus && welcomeReturnFocus.isConnected ? welcomeReturnFocus : fab;
      requestAnimationFrame(() => target.focus());
    }
  }

  welcome.addEventListener('click', (e) => {
    if (e.target.closest('[data-a="close"]')) { engine.demoAsk = false; closeWelcome(); return; }
    const dsc = e.target.closest('[data-demosc]');
    if (dsc) { engine.demoVyber = dsc.dataset.demosc; openWelcome(); return; }
    if (e.target.closest('[data-a="cvseznam"]')) { engine.cvSeznam = true; engine.cvPohled = ''; openWelcome(); return; }
    if (e.target.closest('[data-a="cvvysledky"]')) { engine.cvPohled = 'vysledky'; openWelcome(); return; }
    if (e.target.closest('[data-a="cvnacist"]')) { engine.cvPohled = 'nacist'; openWelcome(); return; }
    if (e.target.closest('[data-a="cvzadani"]')) { engine.cvPohled = 'zadani'; openWelcome(); return; }
    if (e.target.closest('[data-a="cvzadanikod"]')) {
      const ids = [...welcome.querySelectorAll('[data-zadani]:checked')].map((x) => x.dataset.zadani);
      if (!ids.length) return;
      const od = welcome.querySelector('#cv-od');
      cvUkazKod(kodZapis('plan', { od: od ? od.value.trim().slice(0, 80) : '', cviceni: ids }), 'Kód zadání pro učně');
      return;
    }
    if (e.target.closest('[data-a="cvplanpryc"]')) { state.plan = null; saveState(); openWelcome(); return; }
    if (e.target.closest('[data-a="cvodeslat"]')) {
      const c = state.contact || {};
      const data = { kdo: c.jmeno || c.icZakaznik || '', vysledky: {} };
      for (const [id, v] of Object.entries(state.cvHotova || {})) {
        data.vysledky[id] = { n: v.napoved | 0, s: v.sekundy | 0, c: v.chyby | 0 };
      }
      cvUkazKod(kodZapis('vysledky', data), 'Kód s vašimi výsledky');
      return;
    }
    if (e.target.closest('[data-a="cvkodkopie"]')) {
      const pole = welcome.querySelector('#cv-kod-ven');
      const stav = welcome.querySelector('[data-kodstav]');
      if (pole) {
        pole.select();
        let ok = false;
        try { ok = document.execCommand('copy'); } catch (err) { ok = false; }
        if (stav) stav.innerHTML = ok ? '<span class="ok">' + ik('hotovo') + 'Zkopírováno — pošlete to druhé straně.</span>'
          : 'Kopírování se nepovedlo — označte text a zkopírujte ho ručně (Ctrl+C).';
      }
      return;
    }
    if (e.target.closest('[data-a="cvkodnacti"]')) {
      const pole = welcome.querySelector('#cv-kod');
      const stav = welcome.querySelector('[data-kodstav]');
      const obj = kodCti(pole ? pole.value : '');
      if (!obj) { if (stav) stav.textContent = 'Tomu kódu nerozumím. Zkontrolujte, jestli je zkopírovaný celý.'; return; }
      if (obj.t === 'vysledky') {
        const h = {};
        for (const [id, v] of Object.entries((obj.d || {}).vysledky || {})) {
          h[id] = { napoved: v.n | 0, sekundy: v.s | 0, chyby: v.c | 0 };
        }
        engine.cvCizi = h;
        engine.cvCiziKdo = (obj.d || {}).kdo || '';
        engine.cvPohled = 'cizi';
        openWelcome();
        return;
      }
      if (obj.t === 'plan') {
        const ids = ((obj.d || {}).cviceni || []).filter((id) => CVICENI.some((cv) => cv.id === id));
        if (!ids.length) { if (stav) stav.textContent = 'V zadání nejsou žádná cvičení, která bych znal.'; return; }
        state.plan = { od: (obj.d || {}).od || '', cviceni: ids };
        saveState();
        engine.cvPohled = '';
        openWelcome();
        return;
      }
      if (stav) stav.textContent = 'Tenhle kód je jiného druhu, než průvodce umí načíst.';
      return;
    }
    if (e.target.closest('[data-a="cvzpet"]')) {
      if (engine.cvPohled) { engine.cvPohled = ''; openWelcome(); return; }
      engine.cvSeznam = false; openWelcome(); return;
    }
    const cvit = e.target.closest('[data-cvstart]');
    if (cvit && cvit.dataset.cvstart) { engine.cvSeznam = false; cvStart(cvit.dataset.cvstart); return; }
    if (e.target.closest('[data-a="demostop"]')) { demoStop(); openWelcome(); return; }
    if (e.target.closest('[data-a="demoask"]')) { engine.demoAsk = true; openWelcome(); return; }
    if (e.target.closest('[data-a="demoback"]')) { engine.demoAsk = false; openWelcome(); return; }
    if (e.target.closest('[data-a="demogo"]')) { engine.demoAsk = false; closeWelcome(); demoStart(); return; }
    // volba obchodního specialisty v úvodním dotazu — jeden z nabídky
    const sv = e.target.closest('.spvol');
    if (sv) {
      welcome.querySelectorAll('.spvol').forEach((el) => el.classList.toggle('on', el === sv));
      onboardingOdemkni();
      return;
    }
    if (e.target.closest('[data-a="uvitanidal"]')) {
      // dál na rozcestník; video zastaví closeWelcome uvnitř openWelcome? Ne —
      // okno zůstává otevřené, jen se překresluje. Zastavit ručně.
      const wv = welcome.querySelector('video');
      if (wv) { try { wv.pause(); } catch (err) { /* */ } }
      engine.uvitani = false;
      openWelcome();
      return;
    }
    if (e.target.closest('[data-a="contactSave"]')) {
      const pole = welcome.querySelector('#ob-ic');
      const cislo = pole ? pole.value.trim().toUpperCase().slice(0, 40) : '';
      if (!cislo) return;                       // tlačítko je stejně zamčené
      const vybrany = welcome.querySelector('.spvol.on');
      if (specialisteSeznam().length && !vybrany) return;
      state.contact = Object.assign({}, state.contact, {
        icZakaznik: cislo,
        // „Zatím nevím" se ukládá jako „—": dotaz je zodpovězený, jen bez
        // konkrétního jména — pomoc pak ukazuje všechny specialisty.
        specialista: vybrany ? (vybrany.dataset.spec || '') : ''
      });
      state.contactAsked = true;
      saveState();
      doplnUdajeZNastaveni();   // telefon a e-mail si vezmeme z IC Office
      // Uvítací video se pouští hned po dotazu — klik na Pokračovat je gesto
      // uživatele, takže smí hrát i se zvukem. Bez nastavené adresy se jde
      // rovnou na rozcestník scénářů.
      engine.uvitani = !!uvitaciVideoUrl();
      openWelcome();
      return;
    }
    const hit = e.target.closest('[data-jump]');
    if (hit) { jumpToStep(hit.dataset.jump, Number(hit.dataset.i)); return; }
    const zn = e.target.closest('[data-scznovu]');
    if (zn) {
      closeWelcome();
      startScenario(zn.dataset.scznovu);   // vždy od prvního kroku
      return;
    }
    const item = e.target.closest('.scen-item');
    if (!item || !item.dataset.sc) return;
    const id = item.dataset.sc;
    closeWelcome();
    if (state.active && state.active.scenarioId === id) {
      state.active.paused = false;
      saveState();
      resume();
    } else {
      startScenario(id);
    }
  });
  function renderVysledky(dotaz) {
    const box = welcome.querySelector('.wres');
    const list = welcome.querySelector('.wlist');
    if (!box) return;
    const q = String(dotaz || '').trim();
    if (!q) { box.innerHTML = ''; if (list) list.classList.remove('hidden'); return; }
    if (list) list.classList.add('hidden');
    const nalezy = najdiKrok(q);
    if (!nalezy.length) {
      box.innerHTML = '<div class="nic">Nic odpovídajícího jsme nenašli. Zkuste jiné slovo — třeba „faktura“, „vozidlo“ nebo „sklad“.</div>';
      return;
    }
    box.innerHTML = nalezy.map((r) => `<button type="button" class="hit" data-jump="${escHtml(r.scId)}" data-i="${r.i}">
      <span class="kod">${escHtml(r.kod)}</span>
      <span class="txt2"><span class="t">${escHtml(r.titulek)}</span>
      <span class="s">${escHtml(r.scTitulek)} · krok ${r.i + 1}</span></span></button>`).join('');
  }

  // volba pauzy a hlasu před spuštěním prezentace
  welcome.addEventListener('input', (e) => {
    if (e.target && e.target.id === 'demo-pauza') {
      engine.demoPauzaVolba = demoPauzaPlatna(e.target.value);
      const cas = welcome.querySelector('#demo-pauza-cas');
      if (cas) cas.textContent = engine.demoPauzaVolba;
    }
  });
  welcome.addEventListener('change', (e) => {
    if (e.target && e.target.id === 'demo-hlas') engine.demoHlasVolba = !!e.target.checked;
  });

  welcome.addEventListener('input', (e) => {
    // „Pokračovat“ se odemkne, až je zákaznické číslo vyplněné (a vybraný
    // specialista — to hlídá onboardingOdemkni)
    if (e.target && e.target.id === 'ob-ic') { onboardingOdemkni(); return; }
    if (e.target && e.target.id === 'w-hledat') renderVysledky(e.target.value);
  });
  welcome.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || !e.target) return;
    if (e.target.id === 'ob-ic') {
      e.preventDefault();
      const btn = welcome.querySelector('[data-a="contactSave"]');
      if (btn && !btn.disabled) btn.click();
    } else if (e.target.id === 'w-hledat') {
      // Enter skočí na první nález — hotline zadá kód a je tam
      e.preventDefault();
      const prvni = welcome.querySelector('.wres .hit');
      if (prvni) prvni.click();
    }
  });

  wback.addEventListener('click', closeWelcome);

  // ---------------- FAB ----------------
  function positionFab() {
    if (drag) return; // repozice nesmí přepsat tlačítko pod kurzorem během tažení
    const f = state.fab;
    // Tlačítko nese název, takže je širší než vysoké — rozměr se měří, ne
    // předpokládá (skryté tlačítko hlásí 0, pak platí odhad).
    const w = fab.offsetWidth || 150;
    const h = fab.offsetHeight || 44;
    // Výchozí pozice je NAD tlačítkem v1 (to sedí na right:24 / bottom:24,
    // 56 px). Obě verze se dají provozovat vedle sebe, takže se nesmí
    // překrývat — jinak je jedno tlačítko nedosažitelné bez tažení.
    let x = f ? f.x : innerWidth - w - 20;
    let y = f ? f.y : innerHeight - h - 100;
    x = Math.min(Math.max(4, x), innerWidth - w - 4);
    y = Math.min(Math.max(4, y), innerHeight - h - 4);
    fab.style.left = x + 'px';
    fab.style.top = y + 'px';
  }

  function openFabMenu() {
    const sc = activeScenario();
    let rows = `
      <button class="row" role="menuitemcheckbox" aria-checked="${state.enabled}" data-a="toggle">${state.enabled ? 'Průvodce je zapnutý' : 'Průvodce je vypnutý'}<span class="sw ${state.enabled ? 'on' : ''}" aria-hidden="true"></span></button>`;
    if (state.enabled && sc && sc.steps.length && state.active.step < sc.steps.length) {
      rows += `<button class="row" role="menuitem" data-a="cont">Pokračovat: ${sc.title}</button>`;
    }
    if (state.enabled) {
      rows += '<button class="row" role="menuitem" data-a="menu">Otevřít nabídku průvodce</button>';
    }
    // Prezentace musí jít vypnout i tehdy, když se karta kroku nezobrazuje
    // (jsme na stránce mimo scénář) — jinak by se nedala zastavit, jen počkat,
    // až se sama probudí.
    if (demoBezi()) {
      rows += '<button class="row" role="menuitem" data-a="demostop">Ukončit prezentaci</button>';
    }
    fmenu.innerHTML = rows;
    fmenu.classList.remove('hidden');
    fab.setAttribute('aria-expanded', 'true');
    const fr = fab.getBoundingClientRect();
    const mw = 280;
    const mh = fmenu.offsetHeight || 140;
    let left = fr.right - mw;
    let top = fr.top - mh - 10;
    if (top < 8) top = fr.bottom + 10;
    left = Math.min(Math.max(8, left), innerWidth - mw - 8);
    fmenu.style.left = left + 'px';
    fmenu.style.top = top + 'px';
  }

  function closeFabMenu() {
    fmenu.classList.add('hidden');
    fab.setAttribute('aria-expanded', 'false');
  }

  fmenu.addEventListener('click', (e) => {
    const b = e.target.closest('[data-a]');
    if (!b) return;
    const act = b.dataset.a;
    if (act === 'toggle') {
      state.enabled = !state.enabled;
      saveState();
      applyEnabled();
      openFabMenu(); // hned ukázat nový stav
    } else if (act === 'cont') {
      closeFabMenu();
      if (state.active) { state.active.paused = false; saveState(); resume(true); }
    } else if (act === 'menu') {
      openWelcome();
    } else if (act === 'demostop') {
      demoStop();
    }
  });

  // FAB drag & klik
  let drag = null;
  fab.addEventListener('pointerdown', (e) => {
    drag = { sx: e.clientX, sy: e.clientY, ox: fab.offsetLeft, oy: fab.offsetTop, moved: false };
    fab.setPointerCapture(e.pointerId);
  });
  fab.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
    if (Math.abs(dx) + Math.abs(dy) > 5) drag.moved = true;
    if (drag.moved) {
      fab.style.left = Math.min(Math.max(4, drag.ox + dx), innerWidth - fab.offsetWidth - 4) + 'px';
      fab.style.top = Math.min(Math.max(4, drag.oy + dy), innerHeight - fab.offsetHeight - 4) + 'px';
    }
  });
  fab.addEventListener('pointerup', () => {
    if (!drag) return;
    if (drag.moved) {
      state.fab = { x: fab.offsetLeft, y: fab.offsetTop };
      saveState();
    } else {
      if (fmenu.classList.contains('hidden')) openFabMenu(); else closeFabMenu();
    }
    drag = null;
  });
  // přerušené tažení (dotyk/gesto/pero) nesmí nechat viset „mrtvý" drag stav
  fab.addEventListener('pointercancel', () => { drag = null; });
  fab.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      if (fmenu.classList.contains('hidden')) {
        openFabMenu();
        requestAnimationFrame(() => fmenu.querySelector('button')?.focus());
      } else {
        closeFabMenu();
      }
    } else if (e.key === 'Escape') {
      closeFabMenu();
    }
  });

  root.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (!welcome.classList.contains('hidden')) {
      e.preventDefault();
      closeWelcome();
    } else if (!fmenu.classList.contains('hidden')) {
      e.preventDefault();
      closeFabMenu();
      fab.focus();
    }
  });

  function applyEnabled() {
    // Veřejná část webu = průvodce se neukazuje vůbec, ani plovoucí tlačítko.
    // Není to vypnutí (state.enabled se nemění) — na první stránce po
    // přihlášení naskočí sám a s ním i uvítací okno.
    const verejna = verejnaStranka();
    fab.classList.toggle('hidden', verejna);
    fab.classList.toggle('off', !state.enabled);
    if (verejna || !state.enabled) { hideAll(); closeWelcome(); closeFabMenu(); }
    else resume();
  }

  // ---------------- health-check (převzato z v1) ----------------
  // v2 stojí na ~40 CSS selektorech cizího webu. Když IC Office změní markup,
  // průvodce dosud jen tiše ukázal kartu bez zvýraznění. Health-check proto
  // hlídá, co se na aktuální stránce nenašlo, a hlásí to v popupu doplňku.
  //
  // Kontrolují se JEN cíle, které mají existovat i bez akce uživatele:
  //   – vynechává se `then` (rozbalené menu / modal vzniká až po kliknutí),
  //   – vynechávají se extras s `when: "visible"` (dynamické řádky),
  //   – vynechávají se kroky s `noHealth: true` (cíl závisí na existujících
  //     datech — např. řádek zakázky u klienta, který ještě žádnou nemá).
  function healthTargets(step) {
    if (step.kind === 'info' || step.noHealth) return [];
    const out = [];
    if (step.target) out.push({ slot: 'target', spec: step.target, label: step.label || '' });
    (step.extras || []).forEach((ex, i) => {
      if (!ex.target || ex.when === 'visible') return;
      out.push({ slot: 'extras' + i, spec: ex.target, label: ex.label || '' });
    });
    return out;
  }

  function selectorExists(spec) {
    const sels = Array.isArray(spec) ? spec : [spec];
    return sels.some((s) => {
      try { return !!document.querySelector(s); } catch (e) { return false; }
    });
  }

  // Do hlášení ukládáme adresu BEZ parametrů dotazu — ty můžou nést id klienta
  // či zakázky a do diagnostiky nepatří (viz PRIVACY.md).
  const healthPath = () => currentPath().split('?')[0];

  function updateHealth(mutator) {
    try {
      chrome.storage.local.get([HEALTH_KEY], (r) => {
        const prev = (r && r[HEALTH_KEY] && r[HEALTH_KEY].items) || {};
        const items = Object.assign({}, prev);
        mutator(items);
        const keys = Object.keys(items);
        if (keys.length > HEALTH_MAX) {
          keys.sort((a, b) => (items[a].at || 0) - (items[b].at || 0));
          for (const k of keys.slice(0, keys.length - HEALTH_MAX)) delete items[k];
        }
        try {
          chrome.storage.local.set({ [HEALTH_KEY]: { v: 1, writer: INSTANCE, updatedAt: Date.now(), items } });
        } catch (e) { /* */ }
      });
    } catch (e) { /* mimo rozšíření */ }
  }

  // Zápis z živého kroku — nejsilnější signál: krok byl zobrazený a cíl se
  // ~6 s nenašel. Takový nález se v popupu ukáže hned (confirmed).
  function recordMiss(sc, step, slot) {
    if (!sc || !step) return;
    updateHealth((items) => {
      const key = sc.id + '/' + step.id + '/' + slot;
      const e = items[key] || {};
      items[key] = {
        scenario: sc.title, step: step.title || step.id, label: step.label || '',
        path: healthPath(), unverified: !!step.unverified,
        misses: (e.misses || 0) + 1, confirmed: true, at: Date.now()
      };
    });
  }

  // Pasivní přehled celé stránky. Hlásí se až od 2. nálezu, aby jednorázový
  // překreslený DOM nedělal falešné poplachy.
  function runHealthCheck() {
    // Na přihlašovací stránce z aplikace neexistuje nic. Hlásit odtud
    // „nenalezeno" by popup zavalilo nálezy, které není co opravovat.
    if (verejnaStranka()) return;
    const path = healthPath();
    const seen = [];
    for (const sc of DATA.scenarios) {
      if (!sc.available) continue;
      for (const step of sc.steps) {
        if (!stepMatchesUrl(step)) continue;
        for (const t of healthTargets(step)) {
          seen.push({
            key: sc.id + '/' + step.id + '/' + t.slot,
            ok: selectorExists(t.spec),
            scenario: sc.title, step: step.title || step.id,
            label: t.label, unverified: !!step.unverified
          });
        }
      }
    }
    if (!seen.length) return;
    updateHealth((items) => {
      const now = Date.now();
      for (const s of seen) {
        if (s.ok) { delete items[s.key]; continue; }   // co funguje, nedržíme
        const e = items[s.key] || {};
        items[s.key] = {
          scenario: s.scenario, step: s.step, label: s.label, path,
          unverified: s.unverified, misses: (e.misses || 0) + 1,
          confirmed: !!e.confirmed, at: now
        };
      }
    });
  }

  let healthTimer = null;
  function scheduleHealthCheck(delay) {
    clearTimeout(healthTimer);
    healthTimer = setTimeout(runHealthCheck, delay);
  }

  // ---------------- repozice ----------------
  let rafPending = false;
  function scheduleRepos() {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(() => {
      rafPending = false;
      if (engine.step) { renderSpotlight(); positionCard(); }
      positionFab();
    });
  }
  window.addEventListener('scroll', scheduleRepos, { capture: true, passive: true });
  window.addEventListener('resize', scheduleRepos);
  // Mutace DOM se na stránce zakázky sypou po desítkách za sekundu (select2,
  // datepickery, dynamické řádky). Každá repozice čte getBoundingClientRect
  // i offsetWidth = vynucený reflow, proto navíc k rAF ještě debounce.
  // Scroll a resize zůstávají bez prodlevy — tam je svižnost znát.
  let moTimer = null;
  const mo = new MutationObserver(() => {
    if (moTimer) return;
    moTimer = setTimeout(() => { moTimer = null; scheduleRepos(); }, 120);
  });
  mo.observe(document.documentElement, { childList: true, subtree: true });

  // navigace bez načtení stránky (SPA / history API)
  const onNav = () => { if (state.enabled) resume(); scheduleHealthCheck(1500); };
  window.addEventListener('popstate', onNav);
  window.addEventListener('hashchange', onNav);

  // ---------------- zprávy z popupu + synchronizace storage ----------------
  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg || msg.ns !== 'icop2') return;
      // Na přihlašovací stránce nemá průvodce co ukázat. Popup na to musí
      // dostat odpověď — jinak by se zavřel a uživateli by se nic nestalo.
      if ((msg.action === 'open-menu' || msg.action === 'goto') && verejnaStranka()) {
        sendResponse({ ok: false, duvod: 'neprihlasen' });
        return false;
      }
      if (msg.action === 'open-menu') {
        // výslovné otevření průvodce z popupu ho i zapne — jinak by výběr
        // scénáře při vypnutém průvodci tiše nic neudělal
        if (!state.enabled) { state.enabled = true; saveState(); applyEnabled(); }
        openWelcome();
        sendResponse({ ok: true });
      } else if (msg.action === 'goto') {
        // hotline / specialista zadá kód kroku v okně doplňku a průvodce
        // na aktuální kartě skočí přesně tam
        const nalez = najdiKrok(msg.kod || '')[0];
        if (nalez && jumpToStep(nalez.scId, nalez.i)) sendResponse({ ok: true, kod: nalez.kod, titulek: nalez.titulek });
        else sendResponse({ ok: false });
      } else if (msg.action === 'ping') sendResponse({ ok: true });
      return false;
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      // Kontakt má vlastní klíč v local — změnu z okna doplňku převezmeme zvlášť.
      if (changes[KONTAKT_KEY] && area === 'local') {
        const nk = changes[KONTAKT_KEY].newValue;
        state.contact = (nk && typeof nk === 'object') ? normalizeState({ contact: nk }).contact : null;
        lastSavedJson = JSON.stringify(state);
      }
      // zapnutí/vypnutí režimu správce z okna doplňku se projeví hned
      if (changes[SPRAVA_KEY] && area === 'local') {
        SPRAVA = !!changes[SPRAVA_KEY].newValue;
        if (!SPRAVA) { engine.editorOpen = false; if (vyber) vyberKonec(); }
        if (engine.step) { buildCard(); positionCard(); }
      }
      if (changes[STRUCNE_KEY] && area === 'local') {
        STRUCNE = !!changes[STRUCNE_KEY].newValue;
        if (engine.step) { buildCard(); positionCard(); }
      }
      if (!changes[STORE_KEY] || (area !== 'local' && area !== 'sync')) return;
      const nv = changes[STORE_KEY].newValue || {};
      if (nv.writer && nv.writer === INSTANCE) return;   // naše vlastní uložení
      // Synchronizovaný záznam kontakt NEOBSAHUJE — ten žije v local. Kdyby ho
      // applyState vynuloval, nejbližší uložení by ho smazalo i odtamtud;
      // uživateli by průvodce zničehonic zapomněl zákaznické číslo.
      const kontakt = state.contact;
      applyState(nv);
      if (!nv.contact && kontakt) state.contact = kontakt;
      lastSavedJson = JSON.stringify(state);
      closeFabMenu();
      applyEnabled();
    });
  } catch (e) { /* mimo rozšíření */ }

  // ---------------- debug export (jen pro testovací harness; v izolovaném světě
  // content skriptu na něj stránka nedosáhne) ----------------
  window.__icop2Debug = {
    engine, state, resume, next, prev, startScenario, openWelcome, showStep, applyEnabled,
    saveState, normalizeState, runHealthCheck, healthTargets, doplnUdajeZNastaveni,
    demoStart, demoStop, demoProved, demoPole, demoBezi, verejnaStranka,
    obsahVada, pouzijObsah, obsahZdroj: () => OBSAH_ZDROJ, obsahFormat: OBSAH_FORMAT,
    typografie, textKroku, stitekHtml, pctKroku, hlasKod, strucnyText, buildCard, najdiKrok,
    stateSchemaVersion: STATE_SCHEMA_VERSION, uiVersion: UI_VERSION, instance: INSTANCE
  };

  // ---------------- start ----------------
  // Načtení stavu: přednost má sync (postup napříč počítači). Když je prázdný
  // a v local něco je, jde o první spuštění po přechodu na sync — přeneseme to.
  function loadState(hotovo) {
    let done = false;
    const dokonci = (raw) => {
      if (done) return;
      done = true;
      const stav = raw || {};
      // Kontakt se přibere z local. Když tam ještě není a ve starém
      // synchronizovaném stavu byl, převezme se odtud — a při nejbližším
      // uložení ze sync zmizí (viz saveState).
      try {
        chrome.storage.local.get([KONTAKT_KEY], (r) => {
          const mistni = r && r[KONTAKT_KEY];
          if (mistni && typeof mistni === 'object') stav.contact = mistni;
          hotovo(stav);
        });
      } catch (e) { hotovo(stav); }
    };
    try {
      stateStore().get([STORE_KEY], (r) => {
        const raw = r && r[STORE_KEY];
        if (raw || stateArea === chrome.storage.local) { dokonci(raw); return; }
        try {
          chrome.storage.local.get([STORE_KEY], (l) => dokonci(l && l[STORE_KEY]));
        } catch (e) { dokonci(null); }
      });
    } catch (e) { dokonci(null); }
  }

  // Obsah z editoru se načítá PŘED stavem — stav se normalizuje proti scénářům,
  // takže musí být jasné, které scénáře vlastně platí.
  function loadObsah(hotovo) {
    let done = false;
    const dokonci = () => { if (!done) { done = true; hotovo(); } };
    try {
      chrome.storage.local.get([OBSAH_KEY], (r) => {
        const d = r && r[OBSAH_KEY];
        if (d) {
          const vada = obsahVada(d);
          if (vada) {
            // Nepoužitelný obsah nesmí uživatele nechat bez průvodce.
            engine.obsahVada = vada;
            try { console.warn('[IC Office Tutoriál] vlastní obsah se nepoužil:', vada); } catch (e) { /* */ }
          } else {
            // Úplný obsah (i s kroky vynechanými správcem) si drží editor;
            // průvodce běží nad obsahem bez vynechaných kroků.
            OBSAH_PLNY = d;
            pouzijObsah(bezVynechanych(d), 'vlastní');
          }
        }
        dokonci();
      });
    } catch (e) { dokonci(); }
  }

  // Aktualizace obsahu ze serveru běží NA POZADÍ a projeví se až při dalším
  // načtení stránky. Přepnout obsah uprostřed rozpracovaného kroku by
  // uživateli zmizel postup pod rukama.
  function obnovObsahNaPozadi() {
    const url = OBSAH_ZABUDOVANY.obsahUrl;
    if (!url) return;
    try {
      chrome.runtime.sendMessage({ ns: 'icop2', action: 'obsah', url }, () => {
        if (chrome.runtime.lastError) { /* service worker spí nebo chybí oprávnění */ }
      });
    } catch (e) { /* mimo rozšíření */ }
  }

  try {
    loadObsah(() => loadState((raw) => {
      applyState(raw);
      lastSavedJson = JSON.stringify(state);
      positionFab();
      applyEnabled();
      // až se stránka usadí (ajaxové dotažení tabulek, select2…)
      scheduleHealthCheck(2500);
      setTimeout(obnovObsahNaPozadi, 6000);   // nespěchá — až po startu průvodce
      // chybějící telefon / e-mail doplnit z Nastavení → Firma
      setTimeout(doplnUdajeZNastaveni, 3000);
      if (JSON.stringify(raw) !== lastSavedJson) saveState();
      // Uvítací okno se ukazuje JEDNOU (introShown). Na přihlašovací stránce
      // by se tím odbylo — proto se tam ani neotevře, ani nezapíše, a nový
      // uživatel ho uvidí až na první stránce po přihlášení.
      if (state.enabled && !state.introShown && !state.active && !verejnaStranka()) {
        state.introShown = true;
        saveState();
        openWelcome();
      }
    }));
  } catch (e) { /* */ }
})();
