// IC Office Tutoriál 2 — popup
// POZOR: v popupu NIKDY nepoužívat confirm()/alert() — zavřou okno dřív,
// než doběhne async operace (poučení z v1). Potvrzení = dvojklik.
//
// Zápisy do storage jsou read-modify-write: popup si stav VŽDY čerstvě načte,
// změní jen svá pole (enabled / reset) a hned zapíše — nikdy nepoužije snapshot
// z dřívějška, protože content skript mezitím mohl postoupit o krok.
const STORE_KEY = 'icop2:state';
// Kontakt je osobní údaj a nesmí do synchronizovaného stavu — drží se
// stranou, jen v local. Stejné rozdělení má engine.
const KONTAKT_KEY = 'icop2:kontakt';
const HEALTH_KEY = 'icop2:health';
const STATE_SCHEMA_VERSION = 2;
// značka zapisovatele — ať popup nereaguje na vlastní zápis (viz engine.js)
const INSTANCE = 'p' + Math.random().toString(36).slice(2, 10);
const defaultState = () => ({
  schemaVersion: STATE_SCHEMA_VERSION,
  contentVersion: (window.ICOP2_DATA && window.ICOP2_DATA.version) || '',
  writer: '',
  enabled: true,
  introShown: false,
  active: null,
  done: {},
  fab: null,
  contactAsked: false,
  contact: null,
  demo: null
});
let state = defaultState();

const $ = (id) => document.getElementById(id);

// scénáře čteme přímo z tours.js (načteno v popup.html) — žádné duplikáty
const SCENARIOS = (window.ICOP2_DATA && window.ICOP2_DATA.scenarios) || [];
const scenarioById = (id) => SCENARIOS.find((s) => s.id === id) || null;

function normalizeState(raw) {
  const source = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const st = defaultState();
  st.enabled = source.enabled !== false;
  st.writer = typeof source.writer === 'string' ? source.writer : '';
  st.introShown = !!source.introShown;
  if (source.done && typeof source.done === 'object' && !Array.isArray(source.done)) {
    for (const [id, done] of Object.entries(source.done)) if (done === true) st.done[id] = true;
  }
  if (source.fab && Number.isFinite(source.fab.x) && Number.isFinite(source.fab.y)) {
    st.fab = { x: source.fab.x, y: source.fab.y };
  }
  st.contactAsked = !!source.contactAsked;
  // Stav prezentace popup nijak nevykládá, jen ho nesmí při zápisu zahodit —
  // read-modify-write bez tohohle řádku ukončí běžící prezentaci v kartě.
  if (source.demo && typeof source.demo === 'object') st.demo = source.demo;
  if (source.contact && typeof source.contact === 'object') {
    const str = (v) => (typeof v === 'string' ? v.trim().slice(0, 120) : '');
    const c = {
      icZakaznik: str(source.contact.icZakaznik), jmeno: str(source.contact.jmeno),
      tel: str(source.contact.tel), email: str(source.contact.email),
      // zvolený obchodní specialista (vybírá se v úvodním dotazu na stránce)
      specialista: str(source.contact.specialista)
    };
    if (c.icZakaznik || c.jmeno || c.tel || c.email || c.specialista) st.contact = c;
  }
  if (source.active && typeof source.active.scenarioId === 'string') {
    const sc = scenarioById(source.active.scenarioId);
    if (sc && sc.available && sc.steps.length) {
      let idx = Number.isInteger(source.active.step) ? source.active.step : 0;
      if (source.active.stepId) {
        const byId = sc.steps.findIndex((step) => step.id === source.active.stepId);
        if (byId >= 0) idx = byId;
      } else if (source.schemaVersion !== STATE_SCHEMA_VERSION && (sc.id === 'novy-zakaznik-osobne' || sc.id === 'novy-zakaznik-telefon')) {
        const f01 = sc.steps.findIndex((step) => step.id === 'f01');
        if (f01 >= 0 && idx > f01) {
          const wantedId = idx === f01 + 1 ? 'f03' : (idx === f01 + 2 ? 'f04' : sc.steps[sc.steps.length - 1].id);
          const migrated = sc.steps.findIndex((step) => step.id === wantedId);
          if (migrated >= 0) idx = migrated;
        }
      }
      idx = Math.min(Math.max(idx, 0), sc.steps.length - 1);
      st.active = { scenarioId: sc.id, step: idx, stepId: sc.steps[idx].id, paused: !!source.active.paused };
    }
  }
  return st;
}

// hlášení health-checku (nenalezené selektory) — plní content skript
let health = null;

const esc = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// Hlásíme až od 2. nálezu, aby jednorázově překreslený DOM nedělal poplach.
// Nález ze živého kroku (confirmed) se ukáže hned a řadí se nahoru.
function renderHealth() {
  const box = $('health');
  const items = (health && health.items) || {};
  const list = Object.values(items).filter((it) => it.confirmed || (it.misses || 0) >= 2);
  if (!list.length) { box.innerHTML = ''; return; }
  list.sort((a, b) => (b.confirmed ? 1 : 0) - (a.confirmed ? 1 : 0) || (b.misses || 0) - (a.misses || 0));
  const rows = list.slice(0, 12).map((it) => `<li>${esc(it.scenario)} → <strong>${esc(it.step)}</strong>${
    it.label ? ' (' + esc(it.label) + ')' : ''}${
    it.confirmed ? '<span class="tag">nenalezeno</span>' : ''}${
    it.unverified ? '<span class="tag soft">neověřeno</span>' : ''}</li>`).join('');
  box.innerHTML = `<div class="hbox">
    <div class="ht"><span class="at-i at-i-varovani" aria-hidden="true"></span>Kontrola prvků — ${list.length} ${list.length === 1 ? 'nález' : (list.length < 5 ? 'nálezy' : 'nálezů')}</div>
    <div class="hd">Průvodce na stránkách IC Office nenašel prvky, na které míří. Nejspíš se změnil web —
      selektory v <code>tours.js</code> je potřeba aktualizovat.</div>
    <ul>${rows}</ul>
  </div>`;
}

function render() {
  const version = chrome.runtime.getManifest().version;
  $('version').textContent = version;
  // odznak vedle názvu drží generaci odvozenou z verze, ne napevno psané „2.0“
  $('brand').textContent = version.split('.')[0];
  $('toggleSw').classList.toggle('on', state.enabled);
  $('toggleTitle').textContent = state.enabled ? 'Průvodce je zapnutý' : 'Průvodce je vypnutý';
  $('toggleRow').setAttribute('aria-pressed', String(state.enabled));

  const box = $('progress');
  box.innerHTML = '';
  if (state.active) {
    const sc = scenarioById(state.active.scenarioId);
    const title = sc ? sc.title : 'Rozpracovaný scénář';
    const total = sc && sc.steps.length ? sc.steps.length : null;
    const stepNo = Math.min(state.active.step + 1, total || state.active.step + 1);
    // stejný vzorec jako v kartě na stránce, ať popup neukazuje jiné číslo
    const pct = total ? Math.round((stepNo / total) * 100) : 0;
    box.innerHTML = `<div class="pitem">
      <div class="pt">${esc(title)}</div>
      <div class="pd"><span>Krok ${stepNo}${total ? ' z ' + total : ''}${state.active.paused ? ' · pozastaveno' : ''}</span><span class="ppct">${pct} %</span></div>
      <div class="pbar"><div style="width:${Math.min(Math.max(pct, 0), 100)}%"></div></div></div>`;
  }
  for (const [id, done] of Object.entries(state.done || {})) {
    if (!done) continue;
    const sc = scenarioById(id);
    box.innerHTML += `<div class="pitem"><div class="pt">${esc(sc ? sc.title : id)}</div><div class="pd hotovo">Dokončeno</div></div>`;
  }
  renderHealth();
  if (typeof fillContact === 'function') fillContact();
}

// Stav MUSÍ číst i zapisovat tam, kde ho má engine — ten dává přednost `sync`
// (postup napříč počítači) a na `local` padá, až když sync není. Popup dřív
// pracoval napevno s `local`: ukazoval starý snímek a jeho read-modify-write
// pak tímhle snímkem přepsal skutečný, novější stav v sync.
// Health-check zůstává v `local` — je to diagnostika jednoho počítače.
function stateStore() {
  try {
    return (chrome.storage && chrome.storage.sync) ? chrome.storage.sync : chrome.storage.local;
  } catch (e) {
    return chrome.storage.local;
  }
}

function load(cb) {
  stateStore().get([STORE_KEY], (r) => {
    state = normalizeState(r && r[STORE_KEY] ? r[STORE_KEY] : {});
    chrome.storage.local.get([HEALTH_KEY, KONTAKT_KEY], (h) => {
      health = (h && h[HEALTH_KEY]) || null;
      // Kontakt z local má přednost. Když tam ještě není a ve starém
      // synchronizovaném stavu zbyl, použije se odtud — engine ho při
      // nejbližším uložení přesune a ze sync smaže.
      const mistni = h && h[KONTAKT_KEY];
      if (mistni && typeof mistni === 'object') state.contact = normalizeState({ contact: mistni }).contact;
      cb && cb();
    });
  });
}

// read-modify-write: čerstvě načíst → upravit jen daná pole → uložit
function mutate(fn, cb) {
  const store = stateStore();
  // Stav je od v2.54.0 ROZDĚLENÝ: postup v sync, kontakt v local. Číst se proto
  // musí OBOJÍ. Když se přečte jen sync, `st.contact` vyjde prázdný — a zápis,
  // který o kontaktu neví, ho v local přepíše nulou. Stalo se to: po jakékoli
  // akci v popupu (přepínač, skok na krok) průvodce zapomněl zákaznické číslo
  // a ptal se na něj znovu.
  store.get([STORE_KEY], (r) => {
    chrome.storage.local.get([KONTAKT_KEY], (l) => {
    let st = normalizeState(r && r[STORE_KEY] ? r[STORE_KEY] : {});
    const mistni = l && l[KONTAKT_KEY];
    if (mistni && typeof mistni === 'object') st.contact = normalizeState({ contact: mistni }).contact;
    fn(st);
    st = normalizeState(st);
    st.writer = INSTANCE;
    // Kontakt se ukládá zvlášť do local a ze synchronizovaného záznamu se
    // odstraní — i kdyby tam zbyl po starší verzi.
    const kontakt = st.contact || null;
    const proSync = Object.assign({}, st);
    delete proSync.contact;
    try {
      chrome.storage.local.set(kontakt ? { [KONTAKT_KEY]: kontakt } : { [KONTAKT_KEY]: null });
    } catch (e) { /* bez kontaktu se popup obejde */ }
    store.set({ [STORE_KEY]: proSync }, () => {
      // kvóta / vypnutý sync → nepřijít o změnu, dopsat do local (jako engine)
      if (chrome.runtime.lastError && store !== chrome.storage.local) {
        try { chrome.storage.local.set({ [STORE_KEY]: proSync }); } catch (e) { /* */ }
      }
      state = st;
      cb && cb();
    });
    });
  });
}

$('toggleRow').addEventListener('click', () => {
  mutate((st) => { st.enabled = !st.enabled; }, render);
});

$('openMenu').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs && tabs[0];
    if (!tab) return;
    chrome.tabs.sendMessage(tab.id, { ns: 'icop2', action: 'open-menu' }, (res) => {
      if (chrome.runtime.lastError) {
        $('status').classList.add('err');
        // na ic-office tabu otevřeném před instalací/aktualizací doplňku
        // content skript neběží — pomůže obnovení stránky, ne jiná adresa
        if (tab.url && tab.url.indexOf('https://ic-office.eu') === 0) {
          $('status').textContent = 'Obnovte stránku (F5) a zkuste to znovu';
        } else {
          $('status').textContent = 'Otevřete nejdřív stránku ic-office.eu';
        }
      } else if (res && res.duvod === 'neprihlasen') {
        // průvodce se na přihlašovací stránce záměrně neukazuje
        $('status').classList.add('err');
        $('status').textContent = 'Nejdřív se přihlaste — průvodce se pak spustí sám';
      } else {
        window.close();
      }
    });
  });
});

// smazání postupu — potvrzení dvojklikem (žádné confirm() v popupu!)
let resetArmed = false;
$('reset').addEventListener('click', () => {
  if (!resetArmed) {
    resetArmed = true;
    $('reset').textContent = 'Opravdu smazat? Klikněte znovu';
    $('reset').classList.add('warn');
    setTimeout(() => {
      resetArmed = false;
      $('reset').textContent = 'Smazat postup (2× klikněte)';
      $('reset').classList.remove('warn');
    }, 3000);
    return;
  }
  resetArmed = false;
  // spolu s postupem smazat i nasbíraná hlášení health-checku — po opravě
  // selektorů by jinak stará hlášení strašila dál
  try { chrome.storage.local.remove(HEALTH_KEY); } catch (e) { /* */ }
  health = null;
  mutate((st) => {
    st.active = null;
    st.done = {};
    st.introShown = false;
    st.demo = null;   // se smazaným postupem musí skončit i prezentace
  }, () => {
    $('reset').textContent = 'Smazat postup (2× klikněte)';
    $('reset').classList.remove('warn');
    $('status').classList.remove('err');
    $('status').textContent = '✓ Postup smazán';
    render();
  });
});

// ---- kontakt pro hotline ----
// Ukládá se lokálně po krátké prodlevě od psaní; nikam se sám neodesílá.
const cPole = { icZakaznik: $('cIc'), jmeno: $('cJmeno'), tel: $('cTel'), email: $('cEmail') };
let contactTimer = null;

function fillContact() {
  const c = state.contact || {};
  for (const k of Object.keys(cPole)) {
    if (document.activeElement !== cPole[k]) cPole[k].value = c[k] || '';
  }
}

for (const k of Object.keys(cPole)) {
  cPole[k].addEventListener('input', () => {
    clearTimeout(contactTimer);
    $('cSaved').textContent = '';
    contactTimer = setTimeout(() => {
      const c = {};
      for (const k of Object.keys(cPole)) c[k] = cPole[k].value.trim().slice(0, 120);
      const neco = Object.values(c).some(Boolean);
      // slévá se s uloženým kontaktem — popup nezná pole `specialista`
      // (vybírá se v průvodci na stránce) a přepisem by ho smazal
      mutate((st) => {
        const spolu = Object.assign({}, st.contact, c);
        st.contact = Object.values(spolu).some(Boolean) ? spolu : null;
        if (neco) st.contactAsked = true;
      }, () => {
        $('cSaved').textContent = '✓ Uloženo';
        setTimeout(() => { $('cSaved').textContent = ''; }, 2500);
      });
    }, 600);
  });
}

// ---- režim správce ----
// Zapíná interaktivní úpravy kroků přímo na stránce (tlačítko ✎ v kartě
// průvodce). Drží se v local — je to vlastnost tohoto počítače, ne účtu.
const SPRAVA_KEY = 'icop2:sprava';

function renderSprava(on) {
  $('spravaSw').classList.toggle('on', !!on);
  $('spravaTitle').textContent = on ? 'Režim správce je zapnutý' : 'Režim správce je vypnutý';
  $('spravaRow').setAttribute('aria-pressed', String(!!on));
}
chrome.storage.local.get([SPRAVA_KEY], (r) => renderSprava(r && r[SPRAVA_KEY]));
$('spravaRow').addEventListener('click', () => {
  chrome.storage.local.get([SPRAVA_KEY], (r) => {
    const on = !(r && r[SPRAVA_KEY]);
    chrome.storage.local.set({ [SPRAVA_KEY]: on }, () => renderSprava(on));
  });
});

// ---- stručné texty pro zkušené ----
// Karta kroku ukáže místo textu jen jeho tučná slova (viz engine.js,
// strucnyText). Stejně jako režim správce je to vlastnost počítače, drží se v local.
const STRUCNE_KEY = 'icop2:strucne';

function renderStrucne(on) {
  $('strucneSw').classList.toggle('on', !!on);
  $('strucneTitle').textContent = on ? 'Stručné texty jsou zapnuté' : 'Stručné texty jsou vypnuté';
  $('strucneRow').setAttribute('aria-pressed', String(!!on));
}
chrome.storage.local.get([STRUCNE_KEY], (r) => renderStrucne(r && r[STRUCNE_KEY]));
$('strucneRow').addEventListener('click', () => {
  chrome.storage.local.get([STRUCNE_KEY], (r) => {
    const on = !(r && r[STRUCNE_KEY]);
    chrome.storage.local.set({ [STRUCNE_KEY]: on }, () => renderStrucne(on));
  });
});

// ---- skok na krok podle kódu (hotline / IC Office specialista) ----
function skokNaKod() {
  const kod = $('gKod').value.trim();
  const stav = $('gStav');
  stav.classList.remove('err');
  if (!kod) { stav.textContent = ''; return; }
  stav.textContent = 'Hledám…';
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs && tabs[0];
    if (!tab) return;
    chrome.tabs.sendMessage(tab.id, { ns: 'icop2', action: 'goto', kod }, (res) => {
      if (chrome.runtime.lastError) {
        stav.classList.add('err');
        stav.textContent = tab.url && tab.url.indexOf('https://ic-office.eu') === 0
          ? 'Obnovte stránku (F5) a zkuste to znovu'
          : 'Otevřete nejdřív stránku ic-office.eu';
      } else if (res && res.duvod === 'neprihlasen') {
        stav.classList.add('err');
        stav.textContent = 'Nejdřív se přihlaste do IC Office';
      } else if (res && res.ok) {
        stav.textContent = '✓ ' + res.kod + ' — ' + res.titulek;
        setTimeout(() => window.close(), 900);
      } else {
        stav.classList.add('err');
        stav.textContent = 'Kód ' + kod.toUpperCase() + ' neznáme';
      }
    });
  });
}
$('gJdi').addEventListener('click', skokNaKod);
$('gKod').addEventListener('keydown', (e) => { if (e.key === 'Enter') skokNaKod(); });

// ---------------------------------------------------------------- obsah
// Obsah může přijít z editoru (viz FORMAT.md). Kontrola je stejná jako
// v enginu — popup nesmí uložit něco, co by průvodce stejně odmítl.
const OBSAH_KEY = 'icop2:obsah';
const OBSAH_FORMAT = 1;

function obsahVada(d) {
  if (!d || typeof d !== 'object') return 'není to objekt s obsahem';
  if (d.format !== OBSAH_FORMAT) return `formát ${JSON.stringify(d.format)} — doplněk umí ${OBSAH_FORMAT}`;
  if (!Array.isArray(d.scenarios) || !d.scenarios.length) return 'chybí scénáře';
  const kody = new Set();
  for (const sc of d.scenarios) {
    if (!sc || !sc.id) return 'scénář bez id';
    if (!/^[A-Z]{2}$/.test(sc.code || '')) return `scénář ${sc.id} nemá dvoupísmennou zkratku`;
    if (kody.has(sc.code)) return `zkratka ${sc.code} je dvakrát`;
    kody.add(sc.code);
    if (!Array.isArray(sc.steps)) return `scénář ${sc.id} nemá kroky`;
  }
  return null;
}

function obsahHlaska(text, ok) {
  const el = $('oHlaska');
  el.classList.toggle('err', !ok);
  el.textContent = text;
}

function renderObsah() {
  chrome.storage.local.get([OBSAH_KEY], (r) => {
    const d = r && r[OBSAH_KEY];
    const vlastni = d && !obsahVada(d);
    $('oStav').textContent = vlastni
      ? `Používá se vlastní obsah z editoru (verze ${d.version || '?'}, ${d.scenarios.length} scénářů).`
      : (d ? 'Uložený vlastní obsah je nepoužitelný — jede zabudovaný. Načtěte ho znovu.'
           : 'Používá se obsah zabudovaný v doplňku.');
    $('oZpet').disabled = !d;
  });
}

$('oSoubor').addEventListener('change', (e) => {
  const f = e.target.files && e.target.files[0];
  if (!f) return;
  const r = new FileReader();
  r.onerror = () => obsahHlaska('Soubor se nepodařilo přečíst.', false);
  r.onload = () => {
    let d;
    try { d = JSON.parse(String(r.result)); } catch (err) { obsahHlaska('To není platný JSON.', false); return; }
    const vada = obsahVada(d);
    if (vada) { obsahHlaska('Obsah se nepoužil — ' + vada + '.', false); return; }
    chrome.storage.local.set({ [OBSAH_KEY]: d }, () => {
      obsahHlaska(`✓ Načteno (${d.scenarios.length} scénářů). Obnovte stránku IC Office.`, true);
      renderObsah();
    });
  };
  r.readAsText(f);
  e.target.value = '';
});

$('oExport').addEventListener('click', () => {
  chrome.storage.local.get([OBSAH_KEY], (r) => {
    const d = (r && r[OBSAH_KEY]) || window.ICOP2_DATA;
    if (!d) { obsahHlaska('Není co uložit.', false); return; }
    const kopie = Object.assign({ format: OBSAH_FORMAT }, d);
    const url = URL.createObjectURL(new Blob([JSON.stringify(kopie, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `ic-office-tutorial-obsah-${kopie.version || 'x'}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    obsahHlaska('✓ Uloženo do Stažených souborů.', true);
  });
});

$('oZpet').addEventListener('click', () => {
  chrome.storage.local.remove(OBSAH_KEY, () => {
    obsahHlaska('✓ Vrácen zabudovaný obsah. Obnovte stránku IC Office.', true);
    renderObsah();
  });
});

// změny z content skriptu (postup kroků, hlášení health-checku) promítat živě
chrome.storage.onChanged.addListener((changes, area) => {
  let dirty = false;
  // stav sledovat v obou oblastech (engine preferuje sync, na local padá jen
  // když sync není), health-check je vždy jen v local
  if (changes[STORE_KEY] && (area === 'local' || area === 'sync')) {
    const nv = changes[STORE_KEY].newValue || {};
    if (nv.writer !== INSTANCE) { state = normalizeState(nv); dirty = true; }   // ne vlastní zápis
  }
  if (changes[KONTAKT_KEY] && area === 'local') {
    const nv = changes[KONTAKT_KEY].newValue;
    state.contact = nv ? normalizeState({ contact: nv }).contact : null;
    dirty = true;
  }
  if (changes[HEALTH_KEY] && area === 'local') { health = changes[HEALTH_KEY].newValue || null; dirty = true; }
  if (dirty) render();
});

load(render);
