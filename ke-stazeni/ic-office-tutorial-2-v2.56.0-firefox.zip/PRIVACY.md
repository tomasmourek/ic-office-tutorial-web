# Ochrana soukromí — IC Office Tutoriál 2

Aktualizováno: 28. 7. 2026

## Jaká data doplněk ukládá

Doplněk používá tři klíče a **záleží na tom, kam který ukládá** — proto je to tu rozepsané.

### `icop2:state` — nastavení a postup (synchronizované)

Ukládá se do `chrome.storage.sync`, takže **se přenáší mezi počítači**, kde jste přihlášení stejným účtem Chrome. Díky tomu můžete pokračovat tam, kde jste skončili, i na jiném stroji. Obsahuje:

- zapnutí nebo vypnutí průvodce,
- aktivní scénář a poslední potvrzený krok,
- dokončené scénáře a výsledky cvičení (čas a počet nápověd),
- polohu plovoucího tlačítka a nastavení prezentace.

**Osobní údaje tu nejsou.** Od verze 2.54.0 se z tohoto klíče odstraňují i tehdy, když v něm zbyly po starší verzi doplňku.

### `icop2:kontakt` — váš kontakt (jen v tomto počítači)

Ukládá se do `chrome.storage.local` a **nesynchronizuje se**. Obsahuje zákaznické číslo Inter Cars, jméno, telefon, e-mail a jméno vybraného obchodního specialisty IC Office — tedy údaje, které jste vyplnili pro případ, že budete chtít pomoc od hotline.

Do verze 2.53.x byl kontakt součástí synchronizovaného stavu. Při prvním spuštění novější verze se automaticky přesune do místního úložiště a ze synchronizovaného se smaže.

### `icop2:health` — kontrola prvků (jen v tomto počítači)

Od verze 2.4.0 klíč s výsledky **kontroly prvků**. Ukládá se do `chrome.storage.local` — je to diagnostika jednoho počítače. Obsahuje pouze to, na který krok průvodce míří a zda svůj cíl na stránce našel:

- název scénáře a kroku (texty z doplňku, ne ze stránky),
- adresa stránky bez parametrů dotazu — tedy např. `/record/add-contract`,
- počet neúspěšných pokusů a čas posledního.

Obsah formulářů IC Office, údaje zákazníků, VIN, SPZ ani fakturační údaje doplněk neukládá. Při zobrazeném kroku pouze ověřuje, zda jsou označená pole vyplněná, aby mohl odemknout pokračování. Kontrola prvků nečte hodnoty polí — jen zjišťuje, jestli prvek na stránce existuje.

## Prezentace (ukázkový režim)

Od verze 2.19.0 umí průvodce **předvést scénář sám** — pomalu vypisuje ukázkové
údaje a kliká za vás. Je to jediné místo, kde doplněk do IC Office **zapisuje**;
ve všech ostatních režimech jen ukazuje, kam kliknout.

- Spustí se **jedině vaším potvrzením** ve varovném okně, které předem říká,
  co vznikne. Sama od sebe se nespustí nikdy — běží jen v té kartě, kde jste ji
  potvrdili, a do jiných karet ani na jiný počítač se nepřenáší.
- Běží **ve vaší přihlášené relaci na ic-office.eu**, takže vytvořené záznamy
  jsou vaše a zůstávají ve vašem účtu. Nikam se neodesílají.
- Zapisuje **jen vymyšlená ukázková data** ze souboru `src/content/tours.js`
  (klient „Tomáš Mourek (UKÁZKA)"). Žádné údaje vašich skutečných klientů nečte
  ani nepoužívá. Co si vyplníte sami, prezentace nepřepisuje.
- Vytvořené záznamy mají v názvu **UKÁZKA**, abyste je poznali a mohli smazat.
- Zakázkový list **podepíše křížkem**. Fakturu **nevystaví** — okno fakturace
  jen ukáže.
- Telefon a e-mail ukázkového klienta jsou **služební kontakt IC Office**, takže
  případná automatická SMS nebo e-mail o stavu zakázky přijde jemu, ne cizímu
  člověku.
- Volitelné **předčítání kroku nahlas** používá hlas zabudovaný v prohlížeči.
  Text se nikam neodesílá a funguje i bez internetu.
- Kdykoli ji zastavíte tlačítkem **Konec** — v kartě průvodce, v jeho nabídce
  i v rozcestníku. Skrytí průvodce (**×**) ji ukončí taky.

## Pomoc od hotline

Panel **Pomoc** zobrazuje kód kroku a kontakty a umí připravit text pro hotlinku (kód kroku, název scénáře a kroku, adresa stránky bez parametrů dotazu, verze doplňku, řetězec prohlížeče). Tento text se buď zkopíruje do schránky, nebo předvyplní do vašeho poštovního klienta.

Součástí je i **kontakt na vás**. Při prvním spuštění se průvodce zeptá na **zákaznické číslo Inter Cars** a na volbu **obchodního specialisty** (ze seznamu v obsahu doplňku; volba „Zatím nevím" je v pořádku). Obojí zůstává jen ve vašem prohlížeči.

**Jméno firmy, telefon a e-mail si průvodce doplní sám** z vašeho nastavení v IC Office (Nastavení → Firma). Načte je vaší přihlášenou relací ze stejného webu, na kterém běží; **žádné údaje neopouštějí IC Office**. Doplní jen prázdná pole — co si vyplníte ručně, nepřepisuje. Když se načtení nepovede, prostě zůstanou prázdná a doplníte je v okně doplňku.

Kontakt slouží jen k tomu, aby hotline věděla, s kým mluví a komu zavolat zpět. Ukládá se lokálně v `chrome.storage.local`, **nesynchronizuje se** a nikam se neodesílá bez vašeho potvrzení.

**Údaje o vašich klientech se neodesílají nikdy** — doplněk je nečte ani neukládá.

Odeslání žádosti vždy potvrzujete tlačítkem **Ano, potřebuji pomoc**. Okno před tím vypíše, co konkrétně odejde, a **jmenuje službu, která přenos zajišťuje**, pokud to není přímo IC Office.

### Kudy žádost jde dnes

V této verzi je nastavená přeposílací služba **Web3Forms** (`api.web3forms.com`). Je to služba **třetí strany**: přijme požadavek a udělá z něj e-mail pro hotline. Znamená to, že **vaše zákaznické číslo, jméno, telefon a e-mail projdou jejími servery** — proto na to okno s potvrzením upozorňuje.

Adresa je uvedená v `host_permissions` v manifestu, takže je vidět v oprávněních doplňku ještě před instalací.

Až vznikne služba na straně IC Office, adresa se vymění a údaje už mimo IC Office neputují. Když není nastavená žádná adresa, doplněk **sám neodešle nic** — otevře váš poštovní klient s předvyplněným textem a odeslání je na vás.

Odesílají se pouze: kód kroku, název scénáře a kroku, pořadí kroku, adresa stránky bez parametrů, verze doplňku a váš kontakt. Nic z toho, co je ve formulářích IC Office.

## Síťová komunikace

Doplněk neposílá **žádnou analytiku** a sám od sebe nekomunikuje nikam. Content skript (nápověda na stránce) sahá jedině na samotné IC Office, a to jediným dotazem na vaši stránku Nastavení → Firma kvůli doplnění telefonu a e-mailu. Že nesahá nikam jinam (žádná cizí adresa, žádný `XMLHttpRequest` ani `sendBeacon`), hlídá automatická kontrola při každém sestavení.

Jediný přenos mimo IC Office nastane tehdy, když **sami potvrdíte žádost o pomoc** — ta jde dnes přes Web3Forms, jak je popsáno výše. Bez vašeho kliknutí se neodešle nic.

Service worker komunikuje výhradně při odeslání potvrzené žádosti o pomoc na nastavený koncový bod. Dokud koncový bod nastavený není, neprovádí žádný požadavek.

Pokud uživatel výslovně klikne v nápovědě na **Video**, prohlížeč načte příslušné MP4 ze stejného webu `https://ic-office.eu`. Na tato videa se vztahují pravidla provozovatele IC Office.

## Oprávnění

- `storage` — uložení nastavení a postupu v místním profilu Chrome,
- `https://ic-office.eu/*` — zobrazení interaktivní nápovědy na stránkách IC Office a doplnění telefonu a e-mailu z vašeho nastavení,
- `https://api.web3forms.com/*` — odeslání potvrzené žádosti o pomoc, pokud je tato cesta zapnutá (viz níže).

### Odesílání přes api.web3forms.com

Doplněk sám e-mail odeslat neumí, potřebuje k tomu službu, která požadavek přijme a e-mail z něj pošle. **Tato cesta je v současné verzi zapnutá.**

Po vašem potvrzení tlačítkem **Ano** odejde vaše **zákaznické číslo Inter Cars, jméno, telefon a e-mail** spolu s kódem kroku, názvem scénáře, adresou stránky (bez parametrů) a verzí doplňku. Tyto údaje projdou serverem provozovatele služby web3forms, který z nich vytvoří e-mail pro hotline. **Údaje o vašich klientech se neodesílají.** Bez stisknutí tlačítka **Ano** neodejde nic.

Cílem je nahradit tuto cestu službou provozovanou přímo IC Office; pak se oprávnění z doplňku odebere a data nikam mimo IC Office neputují.

## Smazání dat

Postup i výsledky kontroly prvků smaže v popupu doplňku tlačítko **Smazat postup**. Odinstalováním doplňku Chrome odstraní také jeho místní úložiště.
